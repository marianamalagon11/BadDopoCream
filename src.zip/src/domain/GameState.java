package domain;

import java.util.List;

/**
 * Snapshot del estado completo de una partida de Bad DOPO Cream.
 * Se usa para salvar y abrir partidas desde archivo.
 */
public class GameState {

    //datos basicos de la partida
    private int levelNumber;
    private Level level;
    private int numberOfPlayers;

    //jugadores
    private Player player1;
    private Player player2;

    // logica del juego
    private boolean bananasPhase;
    private boolean grapesPhase;
    private boolean pineapplesPhase;
    private int bananasCollected;
    private int pineapplesCollected;
    private int totalBananas;
    private int totalPineapples;

    //estado de GameManager
    private int remainingTimeSeconds;
    private int collectedFruits;
    private int totalFruits;
    private boolean gameOver;
    private boolean victory;

    /**
     * Crea un GameState a partir de los objetos actuales del juego.
     */
    public GameState(int levelNumber,
                     Level level,
                     int numberOfPlayers,
                     Player player1,
                     Player player2,
                     boolean bananasPhase,
                     boolean grapesPhase,
                     boolean pineapplesPhase,
                     int bananasCollected,
                     int pineapplesCollected,
                     int totalBananas,
                     int totalPineapples,
                     int remainingTimeSeconds,
                     int collectedFruits,
                     int totalFruits,
                     boolean gameOver,
                     boolean victory) {

        this.levelNumber = levelNumber;
        this.level = level;
        this.numberOfPlayers = numberOfPlayers;
        this.player1 = player1;
        this.player2 = player2;
        this.bananasPhase = bananasPhase;
        this.grapesPhase = grapesPhase;
        this.pineapplesPhase = pineapplesPhase;
        this.bananasCollected = bananasCollected;
        this.pineapplesCollected = pineapplesCollected;
        this.totalBananas = totalBananas;
        this.totalPineapples = totalPineapples;
        this.remainingTimeSeconds = remainingTimeSeconds;
        this.collectedFruits = collectedFruits;
        this.totalFruits = totalFruits;
        this.gameOver = gameOver;
        this.victory = victory;
    }
    /**
     * Returns the level instance stored in this snapshot.
     * @return Level object containing map, fruits, enemies, and obstacles.
     */
    public Level getLevel() {
        return level;
    }
    /**
     * Returns whether the game ended in victory.
     * @return True if players won by collecting all fruits, false otherwise.
     */
    public boolean isVictory() {
        return victory;
    }
}
