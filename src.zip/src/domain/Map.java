package domain;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents the 2D grid of the game map, allowing placement and removal of blocks.
 * Provides validation for grid boundaries and cell occupancy.
 * Laura Castillo,Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Map {

    private Block[][] grid;
    private int width;
    private int height;
    private List<BaldosaCaliente> baldosasCalientes;

    /**
     * Constructs a Map with the specified number of columns and rows.
     * @param width  Number of columns.
     * @param height Number of rows.
     */
    public Map(int width, int height) {
        this.width = width;
        this.height = height;
        this.grid = new Block[width][height];
        this.baldosasCalientes = new ArrayList<>();
    }

    /**
     * Returns the block at the specified coordinates in the grid.
     * @param x Column (zero-based).
     * @param y Row (zero-based).
     * @return The Block located at the cell, or null if empty or out of bounds.
     */
    public Block getBlock(int x, int y) {
        if (!isValidPosition(x, y)) {
            return null;
        }
        return grid[x][y];
    }

    /**
     * Places a block in the specified cell, validating boundaries.
     * @param x     Column in grid.
     * @param y     Row in grid.
     * @param block Block instance to place.
     * @throws BadIceCreamException If the cell is outside valid grid bounds.
     */
    public void setBlock(int x, int y, Block block) throws BadIceCreamException {
        if (!isValidPosition(x, y)) {
            throw new BadIceCreamException(BadIceCreamException.MAP_INDEX_ERROR);
        }
        grid[x][y] = block;
    }

    /**
     * Checks if the coordinates are inside the map boundary.
     * @param x X coordinate.
     * @param y Y coordinate.
     * @return True if position is valid.
     */
    public boolean isValidPosition(int x, int y) {
        return x >= 0 && x < width && y >= 0 && y < height;
    }

    /**
     * Checks if a given Position is inside the map boundaries.
     * @param pos Position object.
     * @return True if position is valid.
     */
    public boolean isValidPosition(Position pos) {
        return isValidPosition(pos.getX(), pos.getY());
    }

    /**
     * Adds an ice block to the grid at the specified position, if valid and empty.
     * Allows ice placement over campfires and hot tiles (ice goes "on top").
     * @param pos Target position.
     * @throws BadIceCreamException If the cell is occupied by non-special block or out of bounds.
     */
    public void addIceBlock(Position pos) throws BadIceCreamException {
        if (!isValidPosition(pos)) {
            throw new BadIceCreamException(BadIceCreamException.MAP_INDEX_ERROR);
        }

        Block existing = getBlock(pos.getX(), pos.getY());

        // Si hay fogata, solo ponemos hielo encima
        if (existing != null && existing.isFogata()) {
            // No hacemos nada con el mapa
            return;
        }

        // Si hay baldosa caliente, permitir poner hielo encima
        if (hasBaldosaCaliente(pos)) {
            // Crear hielo sobre la baldosa
            grid[pos.getX()][pos.getY()] = new IceBlock(pos);
            return;
        }

        // Si hay otro bloque, no permitir
        if (existing != null) {
            throw new BadIceCreamException(BadIceCreamException.ICE_BLOCK_ERROR);
        }

        grid[pos.getX()][pos.getY()] = new IceBlock(pos);
    }

    /**
     * Removes any block at the specified position.
     * If there's a hot tile underneath, it remains.
     * @param pos Target position.
     * @throws BadIceCreamException If position is outside grid bounds.
     */
    public void removeBlock(Position pos) throws BadIceCreamException {
        if (!isValidPosition(pos)) {
            throw new BadIceCreamException(BadIceCreamException.MAP_INDEX_ERROR);
        }
        grid[pos.getX()][pos.getY()] = null;
    }

    /**
     * Returns map width (number of columns).
     * @return Integer width.
     */
    public int getWidth() {
        return width;
    }

    /**
     * Returns map height (number of rows).
     * @return Integer height.
     */
    public int getHeight() {
        return height;
    }

    /**
     * Returns the number of columns in the map.
     * Alias for getWidth() for compatibility.
     * @return Number of columns.
     */
    public int getCols() {
        return width;
    }

    /**
     * Returns the number of rows in the map.
     * Alias for getHeight() for compatibility.
     * @return Number of rows.
     */
    public int getRows() {
        return height;
    }

    /**
     * Adds a campfire to the grid at the specified position.
     * @param pos Target position.
     * @throws BadIceCreamException If the cell is occupied or out of bounds.
     */
    public void addFogata(Position pos) throws BadIceCreamException {
        if (!isValidPosition(pos)) {
            throw new BadIceCreamException(BadIceCreamException.MAP_INDEX_ERROR);
        }
        if (getBlock(pos.getX(), pos.getY()) != null) {
            throw new BadIceCreamException("Cell already occupied");
        }
        grid[pos.getX()][pos.getY()] = new Fogata(pos);
    }

    /**
     * Adds a hot tile to the map at the specified position.
     * Hot tiles are stored separately and don't occupy the grid.
     * @param pos Target position.
     * @throws BadIceCreamException If position is out of bounds.
     */
    public void addBaldosaCaliente(Position pos) throws BadIceCreamException {
        if (!isValidPosition(pos)) {
            throw new BadIceCreamException(BadIceCreamException.MAP_INDEX_ERROR);
        }
        baldosasCalientes.add(new BaldosaCaliente(pos));
    }

    /**
     * Checks if there's a hot tile at the given position.
     * @param pos Position to check.
     * @return True if there's a hot tile at this position.
     */
    public boolean hasBaldosaCaliente(Position pos) {
        for (BaldosaCaliente baldosa : baldosasCalientes) {
            if (baldosa.getPosition().equals(pos)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Gets all campfires in the map.
     * @return List of Fogata blocks.
     */
    public List<Fogata> getFogatas() {
        List<Fogata> fogatas = new ArrayList<>();
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                Block block = grid[x][y];
                if (block != null && block.isFogata()) {
                    fogatas.add((Fogata) block);
                }
            }
        }
        return fogatas;
    }

    /**
     * Gets all hot tiles in the map.
     * @return List of BaldosaCaliente blocks.
     */
    public List<BaldosaCaliente> getBaldosasCalientes() {
        return new ArrayList<>(baldosasCalientes);
    }
}
