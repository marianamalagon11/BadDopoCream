package domain;

import java.util.List;

/**
 * AI profile focused on avoiding enemies.
 * Prioritizes moving away from threats while collecting fruits opportunistically.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class FearfulMachine extends Machine {

    private static final int DANGER_RADIUS = 4;

    /**
     * Constructs a fearful machine profile.
     */
    public FearfulMachine() {
        super("fearful");
    }

    /**
     * Finds safest direction away from enemies, or towards fruit if safe.
     * @param player The player controlled by this machine.
     * @param level The current game level.
     * @return Safest direction to move.
     */
    @Override
    public Direction getNextMove(Player player, Level level) {
        Position playerPos = player.getPosition();
        Enemy nearestEnemy = findNearestEnemy(playerPos, level.getEnemies());

        if (nearestEnemy != null) {
            int distance = manhattanDistance(playerPos, nearestEnemy.getPosition());

            // si hay peligro cerca, huyee
            if (distance <= DANGER_RADIUS) {
                return getDirectionAwayFrom(playerPos, nearestEnemy.getPosition(), level.getMap());
            }
        }

        // si está seguro, buscar frutas
        Fruit nearestFruit = findNearestFruit(playerPos, level.getFruits());
        if (nearestFruit != null) {
            return getDirectionTowards(playerPos, nearestFruit.getPosition(), level.getMap());
        }

        return getRandomDirection();
    }

    /**
     * Creates ice barriers when enemies are nearby for protection.
     * @param player The player controlled by this machine.
     * @param level The current game level.
     * @return True if should create defensive ice, false otherwise.
     */
    @Override
    public boolean shouldPerformAction(Player player, Level level) {
        Position playerPos = player.getPosition();
        Enemy nearestEnemy = findNearestEnemy(playerPos, level.getEnemies());

        if (nearestEnemy != null) {
            int distance = manhattanDistance(playerPos, nearestEnemy.getPosition());

            // crear hielo defensivo si enemigo esta cerca
            if (distance <= DANGER_RADIUS + 1) {
                Position next = playerPos.getNextPosition(player.getDirection());
                Block block = level.getMap().getBlock(next.getX(), next.getY());

                // crear hielo si no hay nada
                if (block == null) {
                    Direction enemyDir = getDirectionTowards(playerPos, nearestEnemy.getPosition(), level.getMap());
                    return player.getDirection() == enemyDir;
                }
            }
        }

        return false;
    }

    /**
     * Finds the nearest enemy to a position.
     * @param pos Current position.
     * @param enemies List of all enemies in level.
     * @return Nearest enemy or null if none.
     */
    private Enemy findNearestEnemy(Position pos, List<Enemy> enemies) {
        Enemy nearest = null;
        int minDistance = Integer.MAX_VALUE;

        for (Enemy e : enemies) {
            int distance = manhattanDistance(pos, e.getPosition());
            if (distance < minDistance) {
                minDistance = distance;
                nearest = e;
            }
        }

        return nearest;
    }

    /**
     * Finds the nearest uncollected fruit to a position.
     * @param pos Current position.
     * @param fruits List of all fruits in level.
     * @return Nearest fruit or null if none available.
     */
    private Fruit findNearestFruit(Position pos, List<Fruit> fruits) {
        Fruit nearest = null;
        int minDistance = Integer.MAX_VALUE;

        for (Fruit f : fruits) {
            if (!f.isCollected()) {
                int distance = manhattanDistance(pos, f.getPosition());
                if (distance < minDistance) {
                    minDistance = distance;
                    nearest = f;
                }
            }
        }

        return nearest;
    }

    /**
     * Calculates Manhattan distance between two positions.
     * @param a First position.
     * @param b Second position.
     * @return Manhattan distance.
     */
    private int manhattanDistance(Position a, Position b) {
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY());
    }

    /**
     * Returns direction that moves away from target position.
     * @param from Current position.
     * @param dangerPos Position to avoid.
     * @param map Game map for collision checking.
     * @return Best direction to flee.
     */
    private Direction getDirectionAwayFrom(Position from, Position dangerPos, Map map) {
        int dx = from.getX() - dangerPos.getX();
        int dy = from.getY() - dangerPos.getY();

        // huir en la direccion opuesta
        if (Math.abs(dx) > Math.abs(dy)) {
            Direction dir = dx > 0 ? Direction.RIGHT : Direction.LEFT;
            if (canMove(from, dir, map)) return dir;
        } else if (Math.abs(dy) > 0) {
            Direction dir = dy > 0 ? Direction.DOWN : Direction.UP;
            if (canMove(from, dir, map)) return dir;
        }

        // intentar el otro eje
        if (Math.abs(dy) > 0) {
            Direction dir = dy > 0 ? Direction.DOWN : Direction.UP;
            if (canMove(from, dir, map)) return dir;
        } else if (Math.abs(dx) > 0) {
            Direction dir = dx > 0 ? Direction.RIGHT : Direction.LEFT;
            if (canMove(from, dir, map)) return dir;
        }

        return getRandomDirection();
    }

    /**
     * Returns direction that moves closer to target position.
     * @param from Current position.
     * @param to Target position.
     * @param map Game map for collision checking.
     * @return Best direction to move.
     */
    private Direction getDirectionTowards(Position from, Position to, Map map) {
        int dx = to.getX() - from.getX();
        int dy = to.getY() - from.getY();

        if (Math.abs(dx) > Math.abs(dy)) {
            Direction dir = dx > 0 ? Direction.RIGHT : Direction.LEFT;
            if (canMove(from, dir, map)) return dir;
        } else if (Math.abs(dy) > 0) {
            Direction dir = dy > 0 ? Direction.DOWN : Direction.UP;
            if (canMove(from, dir, map)) return dir;
        }

        if (Math.abs(dy) > 0) {
            Direction dir = dy > 0 ? Direction.DOWN : Direction.UP;
            if (canMove(from, dir, map)) return dir;
        } else if (Math.abs(dx) > 0) {
            Direction dir = dx > 0 ? Direction.RIGHT : Direction.LEFT;
            if (canMove(from, dir, map)) return dir;
        }

        return getRandomDirection();
    }

    /**
     * Checks if movement in direction is valid.
     * @param pos Current position.
     * @param dir Direction to check.
     * @param map Game map.
     * @return True if can move, false otherwise.
     */
    private boolean canMove(Position pos, Direction dir, Map map) {
        Position next = pos.getNextPosition(dir);
        if (!map.isValidPosition(next)) return false;
        Block block = map.getBlock(next.getX(), next.getY());
        return block == null;
    }

    /**
     * Returns a random valid direction.
     * @return Random direction.
     */
    private Direction getRandomDirection() {
        Direction[] dirs = {Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT};
        return dirs[(int)(Math.random() * 4)];
    }
}
