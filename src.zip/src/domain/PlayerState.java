package domain;

/**
 * Enumerates the possible animation states for a player.
 * Laura Castillo,Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public enum PlayerState {
    NORMAL,        //se mueve normal
    HAPPY,         // gana
    DEAD,          // muere
    BLOWING,       // crea hielo
    ANGRY          // rompe hielo
}
