package domain;

/**
 * Campfire block that kills players on contact.
 * Can be temporarily extinguished by placing ice on it, but reignites after 10 seconds.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Fogata extends Block {

    private boolean isLit;
    private long extinguishedTime;
    private static final long REIGNITE_DURATION = 10000; // 10 segundos para q se prenda

    /**
     * Constructs a Fogata at the specified position.
     * @param position Grid coordinates of the campfire.
     */
    public Fogata(Position position) {
        super(position, false); // No es rompible normalmente
        this.isLit = true;
        this.extinguishedTime = 0;
    }

    /**
     * Checks if the campfire is currently lit.
     * @return True if lit (dangerous), false if extinguished.
     */
    public boolean isLit() {
        updateFireState();
        return isLit;
    }

    /**
     * Extinguishes the campfire temporarily.
     */
    public void extinguish() {
        if (isLit) {
            this.isLit = false;
            this.extinguishedTime = System.currentTimeMillis();
        }
    }

    /**
     * Forces the campfire to reignite immediately.
     */
    public void reignite() {
        this.isLit = true;
        this.extinguishedTime = 0;
    }

    /**
     * Updates the fire state based on elapsed time since extinguishing.
     * Automatically reignites after 10 seconds.
     */
    private void updateFireState() {
        if (!isLit && extinguishedTime > 0) {
            long currentTime = System.currentTimeMillis();
            long elapsed = currentTime - extinguishedTime;

            if (elapsed >= REIGNITE_DURATION) {
                reignite();
            }
        }
    }

    /**
     * Checks if a player is killed by this campfire.
     * @param playerPosition Position of the player.
     * @return True if player is on lit campfire.
     */
    public boolean killsPlayer(Position playerPosition) {
        updateFireState();
        return isLit && this.position.equals(playerPosition);
    }

    /**
     * Gets time remaining until campfire reignites.
     * @return Milliseconds until reignition, or 0 if already lit.
     */
    public long getTimeUntilReignite() {
        if (isLit) {
            return 0;
        }

        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - extinguishedTime;
        return Math.max(0, REIGNITE_DURATION - elapsed);
    }

    /**
     * Returns the image path based on fire state.
     * @return Path to campfire sprite.
     */
    @Override
    public String getImagePath() {
        updateFireState();
        if (isLit) {
            return "resources/fogata.gif";
        } else {
            return "resources/fogataApagada.png";
        }
    }

    /**
     * Behavior when block is broken (extinguishes fire).
     */
    @Override
    public void onBreak() {
        extinguish();
    }

    /**
     * Indicates this is not an ice block.
     * @return False.
     */
    @Override
    public boolean isIce() {
        return false;
    }

    /**
     * Indicates this is a campfire.
     * @return True.
     */
    public boolean isFogata() {
        return true;
    }
}
