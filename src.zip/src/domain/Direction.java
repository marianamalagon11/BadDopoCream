package domain;

/**
 * Enumeration of possible movement directions in the game.
 * Each direction includes delta x and y values.
 * Laura Castillo,Mariana Malagon
 * PROYECTO FINAL DOPO
 */

public enum Direction {
    UP(0, -1),
    DOWN(0, 1),
    LEFT(-1, 0),
    RIGHT(1, 0),
    NONE(0, 0);

    private final int dx;
    private final int dy;

    /**
     * Constructs a direction with specified delta values.
     * @param dx Delta x for grid movement.
     * @param dy Delta y for grid movement.
     */
    Direction(int dx, int dy) {
        this.dx = dx;
        this.dy = dy;
    }

    /**
     * Returns the delta x associated with this direction.
     * @return change in x-axis as integer.
     */
    public int getDx() {
        return dx;
    }

    /**
     * Returns the delta y associated with this direction.
     * @return change in y-axis as integer.
     */
    public int getDy() {
        return dy;
    }
}
