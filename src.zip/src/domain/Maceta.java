package domain;

/**
 * Flowerpot enemy that chases players but cannot break ice blocks.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Maceta extends Enemy {

    /**
     * Constructs a Maceta enemy at the given position.
     * @param position Initial position.
     */
    public Maceta(Position position) {
        super(position, false, 5); // No rompe hielo
        this.direction = Direction.RIGHT;
    }

    /**
     * Movement behavior (not used, override update instead).
     */
    @Override
    protected void moveEnemy() {
        // No se usa en esta implementación
    }

    /**
     * Updates the enemy behavior (chases nearest player).
     * @param players Array of players to chase.
     * @param map Game map for pathfinding.
     */
    @Override
    public void update(Player[] players, Map map) {
        tickCounter++;
        if (tickCounter < speedTicks) {
            return;
        }
        tickCounter = 0;

        Player nearestPlayer = findNearestPlayer(players);
        if (nearestPlayer != null) {
            chasePlayer(nearestPlayer, map);
        }
    }

    /**
     * Finds the nearest player to this enemy.
     * @param players Array of players.
     * @return Nearest player or null.
     */
    private Player findNearestPlayer(Player[] players) {
        Player nearest = null;
        int minDistance = Integer.MAX_VALUE;

        for (Player player : players) {
            if (player != null) {
                int distance = manhattanDistance(this.position, player.getPosition());
                if (distance < minDistance) {
                    minDistance = distance;
                    nearest = player;
                }
            }
        }

        return nearest;
    }

    /**
     * Moves towards the player without breaking blocks.
     * @param player Target player.
     * @param map Game map.
     */
    private void chasePlayer(Player player, Map map) {
        Position playerPos = player.getPosition();
        Direction bestDirection = getBestDirectionTowards(playerPos, map);

        if (bestDirection != null) {
            this.direction = bestDirection;
            Position nextPos = position.getNextPosition(bestDirection);

            Block block = map.getBlock(nextPos.getX(), nextPos.getY());
            if (block == null && map.isValidPosition(nextPos)) {
                this.position = nextPos;
            }
        }
    }

    /**
     * Gets the best direction to move towards target position.
     * @param target Target position.
     * @param map Game map.
     * @return Best direction or null.
     */
    private Direction getBestDirectionTowards(Position target, Map map) {
        int dx = target.getX() - position.getX();
        int dy = target.getY() - position.getY();

        Direction[] priorities;

        if (Math.abs(dx) > Math.abs(dy)) {
            if (dx > 0) {
                priorities = new Direction[]{Direction.RIGHT, Direction.DOWN, Direction.UP, Direction.LEFT};
            } else {
                priorities = new Direction[]{Direction.LEFT, Direction.DOWN, Direction.UP, Direction.RIGHT};
            }
        } else {
            if (dy > 0) {
                priorities = new Direction[]{Direction.DOWN, Direction.RIGHT, Direction.LEFT, Direction.UP};
            } else {
                priorities = new Direction[]{Direction.UP, Direction.RIGHT, Direction.LEFT, Direction.DOWN};
            }
        }

        for (Direction dir : priorities) {
            Position nextPos = position.getNextPosition(dir);
            if (map.isValidPosition(nextPos)) {
                Block block = map.getBlock(nextPos.getX(), nextPos.getY());
                if (block == null) {
                    return dir;
                }
            }
        }

        return null;
    }

    /**
     * Calculates Manhattan distance between two positions.
     * @param a First position.
     * @param b Second position.
     * @return Distance.
     */
    private int manhattanDistance(Position a, Position b) {
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY());
    }

    /**
     * Returns the image path based on current direction.
     * @return Path to sprite.
     */
    @Override
    public String getImagePath() {
        switch (direction) {
            case UP:
                return "resources/maceta_up.front.gif";
            case DOWN:
                return "resources/maceta_front.gif";
            case LEFT:
                return "resources/maceta_left.gif";
            case RIGHT:
                return "resources/maceta_right.gif";
            default:
                return "resources/maceta_front.gif";
        }
    }

    /**
     * Indicates this is a Maceta enemy.
     * @return true.
     */
    @Override
    public boolean isMaceta() {
        return true;
    }
}
