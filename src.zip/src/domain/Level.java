package domain;

import java.util.List;

/**
 * Abstract base class representing a playable game level.
 * Encapsulates the map and the objects (fruits, enemies).
 * Subclasses must implement the level-specific setup logic.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Level {

    protected int levelNumber;
    protected Map map;
    protected List<Fruit> fruits;
    protected List<Enemy> enemies;
    // para ver si fue modificado
    protected boolean customConfigured = false;

    /**
     * Constructs a level with number, map, fruit list and enemy list.
     * @param levelNumber Level identifier (number).
     * @param map         Map for this level.
     * @param fruits      List of fruits to collect.
     * @param enemies     List of enemies present.
     */
    public Level(int levelNumber, Map map, List<Fruit> fruits, List<Enemy> enemies) {
        this.levelNumber = levelNumber;
        this.map = map;
        this.fruits = fruits;
        this.enemies = enemies;
    }
    /**
     * Returns the level identifier number.
     * @return Level number (1, 2, 3, etc.).
     */
    public int getLevelNumber() {
        return levelNumber;
    }
    /**
     * Returns the map instance for this level.
     * @return Map object containing grid layout, blocks, and obstacles.
     */
    public Map getMap() {
        return map;
    }
    /**
     * Returns the list of fruits in this level.
     * @return Mutable list of Fruit objects to collect.
     */
    public List<Fruit> getFruits() {
        return fruits;
    }
    /**
     * Returns the list of enemies in this level.
     * @return Mutable list of Enemy objects to avoid.
     */
    public List<Enemy> getEnemies() {
        return enemies;
    }
    /**
     * Returns whether this level uses a custom configuration.
     * Custom-configured levels may have different fruit/enemy counts or placement.
     * @return True if level was customized, false if using default setup.
     */
    public boolean isCustomConfigured() {
        return customConfigured;
    }
    /**
     * Sets whether this level uses a custom configuration.
     * @param customConfigured True to mark as custom, false for default.
     */
    public void setCustomConfigured(boolean customConfigured) {
        this.customConfigured = customConfigured;
    }

    /**
     * Updates all dynamic elements in the level.
     * Called each game tick to update fruits and enemies.
     * @param players Array of players for enemy AI.
     */
    public void update(Player[] players) {
        // Actualizar frutas
        for (Fruit fruit : fruits) {
            if (!fruit.isCollected()) {
                // teletransportación de la cereza cd 20
                if (fruit.isCherry()) {
                    Cherry cherry = (Cherry) fruit;
                    if (cherry.shouldTeleport()) {
                        try {
                            cherry.teleport(map);
                        } catch (BadIceCreamException e) {
                            System.err.println("Error teleporting cherry: " + e.getMessage());
                        }
                    }
                }

                // Resto de frutas
                fruit.update();
            }
        }

        // Actualizar enemigos
        for (Enemy enemy : enemies) {
            enemy.update(players, map);
        }
    }
}
