package domain;

/**
 * Stationary grape fruit worth 50 points.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Grape extends Fruit {

    /**
     * Creates a grape at the given position.
     * @param position the fruit's coordinates.
     */
    public Grape(Position position) {
        super(position, 50);
    }

    /**
     * Returns the image path for grape.
     * @return path to grape image file.
     */
    @Override
    public String getImagePath() {
        return "resources/grape.gif";
    }

    /**
     * No update logic—grapes stay still.
     */
    @Override
    public void update() {}

    /**
     * Indicates that this fruit is a grape.
     * @return always true for Grape instances.
     */
    @Override
    public boolean isGrape() {
        return true;
    }
}
