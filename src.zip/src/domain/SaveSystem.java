package domain;

import java.io.*;
import java.util.*;

/**
 * Utility class that handles saving and loading level layouts to/from text files.
 * Provides functionality to persist and restore complete level data including
 * map layout (ice blocks, obstacles), fruits, and enemies.
 * Useful for custom level creation, game saving, and level editing.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class SaveSystem {
    /**
     * Saves the level layout (map, fruits and enemies) to a text file.
     *
     * @param level Level instance to save.
     * @param file  Destination file.
     * @throws IOException if an error occurs while writing the file.
     */
    public static void saveLevel(Level level, File file) throws IOException {
        PrintWriter pw = new PrintWriter(new FileWriter(file));

        Map map = level.getMap();
        int w = map.getWidth();
        int h = map.getHeight();

        pw.println(w + " " + h);

        for (int y = 0; y < h; y++) {
            StringBuilder row = new StringBuilder();
            for (int x = 0; x < w; x++) {
                Block b = map.getBlock(x, y);
                if (b instanceof IceBlock) {
                    row.append('I');
                } else if (b instanceof Fogata) {
                    row.append('F');
                } else if (map.hasBaldosaCaliente(new Position(x, y))) {
                    row.append('H');
                } else {
                    row.append('.');
                }
            }
            pw.println(row.toString());
        }

        pw.println("FRUITS:");
        for (Fruit f : level.getFruits()) {
            pw.println(f.getClass().getSimpleName() + " " +
                    f.getPosition().getX() + " " + f.getPosition().getY());
        }

        pw.println("ENEMIES:");
        for (Enemy e : level.getEnemies()) {
            pw.println(e.getClass().getSimpleName() + " " +
                    e.getPosition().getX() + " " + e.getPosition().getY());
        }

        pw.close();
    }

    /**
     * Loads the level layout (map, fruits and enemies) from a text file.
     *
     * @param file Source file with level data.
     * @return Reconstructed Level instance.
     * @throws Exception if the file format is invalid or an error occurs.
     */
    public static Level openLevel(File file) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(file));

        String[] dims = br.readLine().split(" ");
        int w = Integer.parseInt(dims[0]);
        int h = Integer.parseInt(dims[1]);

        Map map = new Map(w, h);

        for (int y = 0; y < h; y++) {
            String row = br.readLine();
            for (int x = 0; x < w; x++) {
                char c = row.charAt(x);
                Position pos = new Position(x, y);
                switch (c) {
                    case 'I':
                        map.setBlock(x, y, new IceBlock(pos));
                        break;
                    case 'F':
                        map.setBlock(x, y, new Fogata(pos));
                        break;
                    case 'H':
                        map.addBaldosaCaliente(pos);
                        break;
                    case '.':
                    default:
                        break;
                }
            }
        }

        List<Fruit> fruits = new ArrayList<>();
        List<Enemy> enemies = new ArrayList<>();

        String line;
        while ((line = br.readLine()) != null) {
            if (line.equals("FRUITS:")) {
                while ((line = br.readLine()) != null && !line.equals("ENEMIES:")) {
                    if (line.trim().isEmpty()) continue;
                    String[] p = line.trim().split("\\s+");
                    if (p.length < 3) continue;

                    String type = p[0];
                    int x = Integer.parseInt(p[1]);
                    int y = Integer.parseInt(p[2]);

                    Fruit fruit = createFruit(type, new Position(x, y));
                    if (fruit != null) {
                        fruits.add(fruit);
                    }
                }
            }

            if (line != null && line.equals("ENEMIES:")) {
                while ((line = br.readLine()) != null) {
                    if (line.trim().isEmpty()) continue;
                    String[] p = line.trim().split("\\s+");
                    if (p.length < 3) continue;

                    String type = p[0];
                    int x = Integer.parseInt(p[1]);
                    int y = Integer.parseInt(p[2]);

                    try {
                        Enemy enemy = EnemyFactory.createEnemy(type, new Position(x, y));
                        enemies.add(enemy);
                    } catch (BadIceCreamException e) {
                        System.err.println("Error creating enemy: " + e.getMessage());
                    }
                }
            }
        }

        br.close();
        return new Level(999, map, fruits, enemies);
    }

    /**
     * Helper method that creates a Fruit instance given its type name and position.
     *
     * @param type Fruit type name (class simple name).
     * @param pos  Fruit grid position.
     * @return Concrete Fruit instance or null if type is unknown.
     */
    private static Fruit createFruit(String type, Position pos) {
        switch (type.toLowerCase()) {
            case "banana":
                return new Banana(pos);
            case "grape":
                return new Grape(pos);
            case "cherry":
                return new Cherry(pos);
            case "pineapple":
                return new Pineapple(pos);
            case "cactus":
                return new Cactus(pos);
            default:
                System.err.println("Unknown fruit type: " + type);
                return null;
        }
    }
}
