package domain;


/**
 * Stationary banana fruit worth 100 points.
 * Laura Castillo,Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Banana extends Fruit {

    /**
     * Creates a banana at the given position.
     * @param position grid coordinates.
     */
    public Banana(Position position) {
        super(position, 100);
    }

    /**
     * Returns the image path for banana.
     * @return path to banana image file.
     */
    @Override
    public String getImagePath() {
        return "resources/banana.gif";
    }

    /**
     * No update logic—bananas stay still.
     */
    @Override
    public void update() { }

    /**
     * Indicates that this fruit is a banana.
     * @return always true for Banana instances.
     */
    @Override
    public boolean isBanana() {
        return true;
    }
}
