package domain;

/**
 * Represents a position in the 2D map grid with x and y coordinates.
 * Laura Castillo,Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Position {
    private int x;
    private int y;

    /**
     * Constructs a Position with specific grid coordinates.
     * @param x the x (column) coordinate.
     * @param y the y (row) coordinate.
     */
    public Position(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Returns the x coordinate (column).
     * @return integer x value.
     */
    public int getX() {
        return x;
    }

    /**
     * Returns the y coordinate (row).
     * @return integer y value.
     */
    public int getY() {
        return y;
    }

    /**
     * Sets the x coordinate.
     * @param x the value to set.
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * Sets the y coordinate.
     * @param y the value to set.
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * Moves the current position by the deltas defined in the direction.
     * @param direction the movement direction.
     */
    public void move(Direction direction) {
        this.x += direction.getDx();
        this.y += direction.getDy();
    }

    /**
     * Returns a new Position moved in the supplied direction.
     * Does not mutate the original.
     * @param direction the movement direction.
     * @return a new Position object.
     */
    public Position getNextPosition(Direction direction) {
        return new Position(x + direction.getDx(), y + direction.getDy());
    }

    /**
     * Determines if this position is equal to another object.
     * @param obj the object to compare.
     * @return true if same coordinates, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Position other = (Position) obj;
        return x == other.x && y == other.y;
    }


    /**
     * Returns a string representing the position in (x, y) format.
     * @return String representation of the position.
     */
    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }
}
