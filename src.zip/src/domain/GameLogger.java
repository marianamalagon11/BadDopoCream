package domain;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Logger system for tracking errors and events in the game.
 * Writes logs to a file for programmer debugging.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class GameLogger {

    private static GameLogger instance;
    private PrintWriter writer;
    private String logFilePath;
    private DateTimeFormatter dateFormatter;

    /**
     * Private constructor for singleton pattern.
     */
    private GameLogger() {
        dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        initializeLogFile();
    }

    /**
     * Gets the singleton instance of the logger.
     * @return The GameLogger instance.
     */
    public static synchronized GameLogger getInstance() {
        if (instance == null) {
            instance = new GameLogger();
        }
        return instance;
    }

    /**
     * Initializes the log file with timestamp in name.
     */
    private void initializeLogFile() {
        try {
            // crear carpeta logs por si no existe
            File logsDir = new File("logs");
            if (!logsDir.exists()) {
                logsDir.mkdir();
            }

            // crear archivo de log con timestamp
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            logFilePath = "logs/game_log_" + timestamp + ".txt";

            writer = new PrintWriter(new FileWriter(logFilePath, true));
            logInfo("Game Started");

        } catch (IOException e) {
            System.err.println("ERROR: Could not create log file: " + e.getMessage());
        }
    }

    /**
     * Logs an error message.
     * @param message Error description.
     */
    public void logError(String message) {
        writeLog("ERROR", message);
        System.err.println("[ERROR] " + message);
    }

    /**
     * Logs an error with exception details.
     * @param message Error description.
     * @param e Exception thrown.
     */
    public void logError(String message, Exception e) {
        writeLog("ERROR", message + " - Exception: " + e.getClass().getName() + ": " + e.getMessage());

        // escribir stack trace
        if (writer != null) {
            e.printStackTrace(writer);
            writer.flush();
        }

        System.err.println("[ERROR] " + message);
        e.printStackTrace();
    }

    /**
     * Logs a warning message.
     * @param message Warning description.
     */
    public void logWarning(String message) {
        writeLog("WARNING", message);
        System.out.println("[WARNING] " + message);
    }

    /**
     * Logs an informational message.
     * @param message Info description.
     */
    public void logInfo(String message) {
        writeLog("INFO", message);
        System.out.println("[INFO] " + message);
    }

    /**
     * Logs a debug message (only in development).
     * @param message Debug description.
     */
    public void logDebug(String message) {
        writeLog("DEBUG", message);
        // solo imprimir en consola si está en modo debug
        if (System.getProperty("debug") != null) {
            System.out.println("[DEBUG] " + message);
        }
    }

    /**
     * Logs game event (player movement, fruit collection, etc).
     * @param event Event description.
     */
    public void logGameEvent(String event) {
        writeLog("GAME_EVENT", event);
    }

    /**
     * Writes a log entry to file.
     * @param level Log level (ERROR, WARNING, INFO, DEBUG).
     * @param message Log message.
     */
    private synchronized void writeLog(String level, String message) {
        if (writer != null) {
            String timestamp = LocalDateTime.now().format(dateFormatter);
            String logEntry = String.format("[%s] [%s] %s", timestamp, level, message);
            writer.println(logEntry);
            writer.flush();
        }
    }

    /**
     * Closes the log file.
     */
    public void close() {
        if (writer != null) {
            logInfo("Game Ended");
            writer.close();
        }
    }

    /**
     * Gets the path of the current log file.
     * @return Log file path.
     */
    public String getLogFilePath() {
        return logFilePath;
    }
}
