package domain;

import java.util.ArrayList;
import java.util.List;

/**
 * Helper class that applies LevelConfig objects to existing Level instances.
 * Uses predefined position slots so the visual layout of each map stays coherent.
 * All fruits/enemies/obstacles are placed on fixed coordinates instead of random ones.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class LevelConfigHelper {

    /**
     * Reconfigures level 1 using the values from LevelConfig.
     * each fruit type has up to 10 slots, each enemy up to 8, and each obstacle up to 6.
     * the idea is to reuse the classic layout but still let the player pick how many things appear.
     */
    public static void configureLevel1(Level level, LevelConfig config,
                                       Position p1Start, Position p2Start) {

        List<Fruit> fruits = new ArrayList<>();
        List<Enemy> enemies = new ArrayList<>();
        Map map = level.getMap();

        // 10 slots por fruta
        Position[] bananaSlots = {
                new Position(1, 1), new Position(3, 1), new Position(5, 1), new Position(7, 1), new Position(9, 1),
                new Position(11, 1), new Position(2, 5), new Position(12, 5), new Position(2, 11), new Position(12, 11)
        };

        Position[] grapeSlots = {
                new Position(2, 2), new Position(4, 2), new Position(6, 2), new Position(8, 2), new Position(10, 2),
                new Position(3, 6), new Position(11, 6), new Position(3, 10), new Position(11, 10), new Position(7, 7)
        };

        Position[] cherrySlots = {
                new Position(1, 3), new Position(13, 3), new Position(1, 4), new Position(13, 4), new Position(1, 9),
                new Position(13, 9), new Position(1, 10), new Position(13, 10), new Position(7, 2), new Position(7, 11)
        };

        Position[] pineappleSlots = {
                new Position(4, 4), new Position(10, 4), new Position(4, 6), new Position(10, 6), new Position(4, 8),
                new Position(10, 8), new Position(4, 10), new Position(10, 10), new Position(6, 7), new Position(8, 7)
        };

        Position[] cactusSlots = {
                new Position(3, 5), new Position(11, 5), new Position(3, 9), new Position(11, 9), new Position(5, 7),
                new Position(9, 7), new Position(6, 3), new Position(8, 3), new Position(6, 11), new Position(8, 11)
        };

        // 8 slots por enemigo
        Position[] trollSlots = {
                new Position(1, 1), new Position(13, 1), new Position(1, 13), new Position(13, 13),
                new Position(3, 3), new Position(11, 3), new Position(3, 11), new Position(11, 11)
        };

        Position[] macetaSlots = {
                new Position(2, 3), new Position(12, 3), new Position(2, 10), new Position(12, 10),
                new Position(5, 5), new Position(9, 5), new Position(5, 9), new Position(9, 9)
        };

        Position[] calamarSlots = {
                new Position(4, 3), new Position(10, 3), new Position(4, 11), new Position(10, 11),
                new Position(6, 4), new Position(8, 4), new Position(6, 10), new Position(8, 10)
        };

        Position[] narvalSlots = {
                new Position(2, 2), new Position(12, 2), new Position(2, 12), new Position(12, 12),
                new Position(4, 5), new Position(10, 5), new Position(4, 9), new Position(10, 9)
        };

        // 6 slots para fogatas y 6 para baldosas
        Position[] fogataSlots = {
                new Position(2, 7), new Position(12, 7), new Position(7, 3),
                new Position(7, 11), new Position(4, 7), new Position(10, 7)
        };

        Position[] baldosaSlots = {
                new Position(3, 7), new Position(11, 7), new Position(7, 4),
                new Position(7, 10), new Position(5, 7), new Position(9, 7)
        };

        java.util.function.Predicate<Position> freeCell = pos ->
                map.isValidPosition(pos)
                        && !pos.equals(p1Start)
                        && !pos.equals(p2Start);

        // frutas (máx 10 por tipo)
        addFruits(config.bananas, bananaSlots, fruits, freeCell, Banana::new);
        addFruits(config.grapes,  grapeSlots,  fruits, freeCell, Grape::new);
        addFruits(config.cherries, cherrySlots, fruits, freeCell, Cherry::new);
        addFruits(config.pineapples, pineappleSlots, fruits, freeCell, Pineapple::new);
        addFruits(config.cactus, cactusSlots, fruits, freeCell, Cactus::new);

        // enemigos (máx 8 por tipo)
        int trollsToAdd = Math.min(config.trolls, trollSlots.length);
        for (int i = 0; i < trollsToAdd; i++) {
            if (freeCell.test(trollSlots[i])) {
                enemies.add(new Troll(trollSlots[i], 5));
            }
        }

        int macetasToAdd = Math.min(config.macetas, macetaSlots.length);
        for (int i = 0; i < macetasToAdd; i++) {
            if (freeCell.test(macetaSlots[i])) {
                enemies.add(new Maceta(macetaSlots[i]));
            }
        }

        int calamaresToAdd = Math.min(config.calamares, calamarSlots.length);
        for (int i = 0; i < calamaresToAdd; i++) {
            if (freeCell.test(calamarSlots[i])) {
                enemies.add(new Calamar(calamarSlots[i]));
            }
        }

        int narvalesToAdd = Math.min(config.narvales, narvalSlots.length);
        for (int i = 0; i < narvalesToAdd; i++) {
            if (freeCell.test(narvalSlots[i])) {
                enemies.add(new Narval(narvalSlots[i]));
            }
        }

        // OBSTÁCULOS NIVEL 1: hasta 6 fogatas y 6 baldosas, según lo que pida el jugador
        try {
            int fogatasToAdd = Math.min(config.fogatas, fogataSlots.length);
            for (int i = 0; i < fogatasToAdd; i++) {
                Position p = fogataSlots[i];
                if (map.isValidPosition(p)) {
                    map.addFogata(p);
                }
            }

            int baldosasToAdd = Math.min(config.baldosasCalientes, baldosaSlots.length);
            for (int i = 0; i < baldosasToAdd; i++) {
                Position p = baldosaSlots[i];
                if (map.isValidPosition(p)) {
                    map.addBaldosaCaliente(p);
                }
            }
        } catch (BadIceCreamException ignored) { }

        replaceFruitsAndEnemies(level, fruits, enemies);
    }


    /**
     * Reconfigures level 2 with up to 10 fruits per type, 8 enemies per type and 6 obstacles.
     * layout tries to respect the big ice square in the middle and the corridors on the sides.
     */
    public static void configureLevel2(Level level, LevelConfig config,
                                       Position p1Start, Position p2Start) {

        List<Fruit> fruits = new ArrayList<>();
        List<Enemy> enemies = new ArrayList<>();
        Map map = level.getMap();

        // fruit slots
        Position[] bananaSlots = {
                new Position(1, 1), new Position(13, 1), new Position(1, 12), new Position(13, 12), new Position(0, 6),
                new Position(14, 6), new Position(7, 1), new Position(7, 12), new Position(2, 3), new Position(12, 3)
        };

        Position[] grapeSlots = {
                new Position(2, 2), new Position(12, 2), new Position(2, 11), new Position(12, 11), new Position(3, 5),
                new Position(11, 5), new Position(3, 8), new Position(11, 8), new Position(5, 2), new Position(9, 2)
        };

        Position[] cherrySlots = {
                new Position(3, 10), new Position(11, 10), new Position(3, 3), new Position(11, 3), new Position(4, 6),
                new Position(10, 6), new Position(4, 7), new Position(10, 7), new Position(1, 5), new Position(13, 5)
        };

        Position[] pineappleSlots = {
                new Position(4, 4), new Position(10, 4), new Position(4, 9), new Position(10, 9), new Position(5, 6),
                new Position(9, 6), new Position(5, 7), new Position(9, 7), new Position(6, 5), new Position(8, 5)
        };

        Position[] cactusSlots = {
                new Position(6, 4), new Position(8, 4), new Position(6, 9), new Position(8, 9), new Position(5, 3),
                new Position(9, 3), new Position(5, 10), new Position(9, 10), new Position(7, 4), new Position(7, 9)
        };

        // enemy slots
        Position[] trollSlots = {
                new Position(2, 2), new Position(12, 2), new Position(2, 11), new Position(12, 11),
                new Position(1, 3), new Position(13, 3), new Position(1, 10), new Position(13, 10)
        };

        Position[] macetaSlots = {
                new Position(7, 3), new Position(4, 10), new Position(10, 10), new Position(4, 3),
                new Position(10, 3), new Position(3, 6), new Position(11, 6), new Position(7, 9)
        };

        Position[] calamarSlots = {
                new Position(7, 5), new Position(3, 4), new Position(11, 4), new Position(3, 9),
                new Position(11, 9), new Position(5, 5), new Position(9, 5), new Position(7, 2)
        };

        Position[] narvalSlots = {
                new Position(7, 8), new Position(3, 7), new Position(11, 7), new Position(2, 6),
                new Position(12, 6), new Position(5, 8), new Position(9, 8), new Position(7, 11)
        };

        // obstacle slots
        Position[] fogataSlots = {
                new Position(1, 7), new Position(13, 7), new Position(0, 3),
                new Position(14, 3), new Position(0, 10), new Position(14, 10)
        };

        Position[] baldosaSlots = {
                new Position(4, 8), new Position(10, 8), new Position(6, 6),
                new Position(8, 6), new Position(6, 7), new Position(8, 7)
        };

        java.util.function.Predicate<Position> freeCell = pos ->
                map.isValidPosition(pos)
                        && !pos.equals(p1Start)
                        && !pos.equals(p2Start);

        // fruits
        addFruits(config.bananas, bananaSlots, fruits, freeCell, Banana::new);
        addFruits(config.grapes, grapeSlots, fruits, freeCell, Grape::new);
        addFruits(config.cherries, cherrySlots, fruits, freeCell, Cherry::new);
        addFruits(config.pineapples, pineappleSlots, fruits, freeCell, Pineapple::new);
        addFruits(config.cactus, cactusSlots, fruits, freeCell, Cactus::new);

        // enemies
        int trollsToAdd = Math.min(config.trolls, trollSlots.length);
        for (int i = 0; i < trollsToAdd; i++) {
            if (freeCell.test(trollSlots[i])) {
                enemies.add(new Troll(trollSlots[i], 5));
            }
        }

        int macetasToAdd = Math.min(config.macetas, macetaSlots.length);
        for (int i = 0; i < macetasToAdd; i++) {
            if (freeCell.test(macetaSlots[i])) {
                enemies.add(new Maceta(macetaSlots[i]));
            }
        }

        int calamaresToAdd = Math.min(config.calamares, calamarSlots.length);
        for (int i = 0; i < calamaresToAdd; i++) {
            if (freeCell.test(calamarSlots[i])) {
                enemies.add(new Calamar(calamarSlots[i]));
            }
        }

        int narvalesToAdd = Math.min(config.narvales, narvalSlots.length);
        for (int i = 0; i < narvalesToAdd; i++) {
            if (freeCell.test(narvalSlots[i])) {
                enemies.add(new Narval(narvalSlots[i]));
            }
        }

        // obstacles
        try {
            int fogatasToAdd = Math.min(config.fogatas, fogataSlots.length);
            for (int i = 0; i < fogatasToAdd; i++) {
                Position p = fogataSlots[i];
                if (map.isValidPosition(p)) {
                    map.addFogata(p);
                }
            }

            int baldosasToAdd = Math.min(config.baldosasCalientes, baldosaSlots.length);
            for (int i = 0; i < baldosasToAdd; i++) {
                Position p = baldosaSlots[i];
                if (map.isValidPosition(p)) {
                    map.addBaldosaCaliente(p);
                }
            }
        } catch (BadIceCreamException ignored) {
        }

        replaceFruitsAndEnemies(level, fruits, enemies);
    }

    /**
     * Reconfigures level 3 with the same rule: 10 fruit slots, 8 enemy slots, 6 obstacle slots.
     * this level is more open so many slots hug the side columns and the igloo area.
     */
    public static void configureLevel3(Level level, LevelConfig config,
                                       Position p1Start, Position p2Start) {

        List<Fruit> fruits = new ArrayList<>();
        List<Enemy> enemies = new ArrayList<>();
        Map map = level.getMap();

        // fruits
        Position[] bananaSlots = {
                new Position(2, 2), new Position(12, 2), new Position(2, 3), new Position(12, 3), new Position(2, 4),
                new Position(12, 4), new Position(2, 10), new Position(12, 10), new Position(2, 11), new Position(12, 11)
        };

        Position[] grapeSlots = {
                new Position(1, 2), new Position(13, 2), new Position(1, 11), new Position(13, 11), new Position(0, 5),
                new Position(14, 5), new Position(0, 9), new Position(14, 9), new Position(3, 7), new Position(11, 7)
        };

        Position[] cherrySlots = {
                new Position(0, 4), new Position(14, 4), new Position(0, 6), new Position(14, 6), new Position(0, 8),
                new Position(14, 8), new Position(0, 10), new Position(14, 10), new Position(5, 2), new Position(9, 2)
        };

        Position[] pineappleSlots = {
                new Position(4, 4), new Position(10, 4), new Position(4, 10), new Position(10, 10), new Position(5, 3),
                new Position(9, 3), new Position(5, 11), new Position(9, 11), new Position(6, 5), new Position(8, 5)
        };

        Position[] cactusSlots = {
                new Position(4, 3), new Position(10, 3), new Position(4, 6), new Position(10, 6), new Position(6, 11),
                new Position(8, 11), new Position(3, 5), new Position(11, 5), new Position(3, 9), new Position(11, 9)
        };

        // enemies
        Position[] trollSlots = {
                new Position(1, 1), new Position(13, 1), new Position(1, 12), new Position(13, 12),
                new Position(1, 5), new Position(13, 5), new Position(1, 9), new Position(13, 9)
        };

        Position[] macetaSlots = {
                new Position(1, 11), new Position(13, 11), new Position(1, 2), new Position(13, 2),
                new Position(3, 4), new Position(11, 4), new Position(3, 10), new Position(11, 10)
        };

        Position[] calamarSlots = {
                new Position(7, 2), new Position(5, 2), new Position(9, 2), new Position(7, 3),
                new Position(7, 4), new Position(5, 4), new Position(9, 4), new Position(7, 5)
        };

        Position[] narvalSlots = {
                new Position(7, 11), new Position(5, 11), new Position(9, 11), new Position(7, 10),
                new Position(7, 9), new Position(5, 9), new Position(9, 9), new Position(7, 8)
        };

        // obstacles
        Position[] fogataSlots = {
                new Position(10, 8), new Position(4, 8), new Position(7, 1),
                new Position(7, 12), new Position(2, 7), new Position(12, 7)
        };

        Position[] baldosaSlots = {
                new Position(4, 8), new Position(10, 8), new Position(6, 8),
                new Position(8, 8), new Position(6, 7), new Position(8, 7)
        };

        java.util.function.Predicate<Position> freeCell = pos ->
                map.isValidPosition(pos)
                        && !pos.equals(p1Start)
                        && !pos.equals(p2Start);

        // fruits
        addFruits(config.bananas, bananaSlots, fruits, freeCell, Banana::new);
        addFruits(config.grapes, grapeSlots, fruits, freeCell, Grape::new);
        addFruits(config.cherries, cherrySlots, fruits, freeCell, Cherry::new);
        addFruits(config.pineapples, pineappleSlots, fruits, freeCell, Pineapple::new);
        addFruits(config.cactus, cactusSlots, fruits, freeCell, Cactus::new);

        // enemies
        int trollsToAdd = Math.min(config.trolls, trollSlots.length);
        for (int i = 0; i < trollsToAdd; i++) {
            if (freeCell.test(trollSlots[i])) {
                enemies.add(new Troll(trollSlots[i], 5));
            }
        }

        int macetasToAdd = Math.min(config.macetas, macetaSlots.length);
        for (int i = 0; i < macetasToAdd; i++) {
            if (freeCell.test(macetaSlots[i])) {
                enemies.add(new Maceta(macetaSlots[i]));
            }
        }

        int calamaresToAdd = Math.min(config.calamares, calamarSlots.length);
        for (int i = 0; i < calamaresToAdd; i++) {
            if (freeCell.test(calamarSlots[i])) {
                enemies.add(new Calamar(calamarSlots[i]));
            }
        }

        int narvalesToAdd = Math.min(config.narvales, narvalSlots.length);
        for (int i = 0; i < narvalesToAdd; i++) {
            if (freeCell.test(narvalSlots[i])) {
                enemies.add(new Narval(narvalSlots[i]));
            }
        }

        // obstacles
        try {
            int fogatasToAdd = Math.min(config.fogatas, fogataSlots.length);
            for (int i = 0; i < fogatasToAdd; i++) {
                Position p = fogataSlots[i];
                if (map.isValidPosition(p)) {
                    map.addFogata(p);
                }
            }

            int baldosasToAdd = Math.min(config.baldosasCalientes, baldosaSlots.length);
            for (int i = 0; i < baldosasToAdd; i++) {
                Position p = baldosaSlots[i];
                if (map.isValidPosition(p)) {
                    map.addBaldosaCaliente(p);
                }
            }
        } catch (BadIceCreamException ignored) {
        }

        replaceFruitsAndEnemies(level, fruits, enemies);
    }

    /**
     * Generic helper that adds up to slots.length fruits of a given type.
     * it just walks the slot array in order and skips cells that are not free.
     */
    private static void addFruits(int desired,
                                  Position[] slots,
                                  List<Fruit> target,
                                  java.util.function.Predicate<Position> freeCell,
                                  java.util.function.Function<Position, Fruit> factory) {
        int toAdd = Math.min(desired, slots.length);
        for (int i = 0; i < toAdd; i++) {
            if (freeCell.test(slots[i])) {
                target.add(factory.apply(slots[i]));
            }
        }
    }

    /**
     * Replaces the fruits and enemies list of a level with new ones.
     * also marks the level as customConfigured so the ui / logic know this is not the default map.
     */
    static void replaceFruitsAndEnemies(Level level,
                                        List<Fruit> fruits,
                                        List<Enemy> enemies) {
        level.fruits = fruits;
        level.enemies = enemies;
        level.customConfigured = true;
    }
}
