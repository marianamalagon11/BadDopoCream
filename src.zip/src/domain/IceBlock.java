package domain;


/**
 * Represents an ice block that can be created by the player and broken by player or enemies.
 * Ice blocks are visible obstacles in the game grid.
 * Laura Castillo,Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class IceBlock extends Block {

    /**
     * Constructs an ice block at the specified grid position.
     * @param position The grid position where this ice block exists.
     */
    public IceBlock(Position position) {
        super(position, true);
    }

    /**
     * Returns the image path for rendering the ice block sprite.
     * @return Path to the ice block image resource.
     */
    @Override
    public String getImagePath() {
        return "resources/ice.png";
    }

    /**
     * Handles any logic when the ice block is broken.
     * Can be used for sound effects, animations, or scoring.
     */
    @Override
    public void onBreak() {
    }

    /**
     * Indicates that this block is an ice block.
     * @return always true for IceBlock instances.
     */
    @Override
    public boolean isIce() {
        return true;
    }
}
