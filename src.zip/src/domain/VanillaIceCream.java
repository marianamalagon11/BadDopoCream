package domain;

/**
 * Vanilla ice cream playable character.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class VanillaIceCream extends Player {

    /**
     * Builds a vanilla ice cream player.
     * @param position  initial grid position.
     * @param isMachine true if controlled by the machine (AI), false if human.
     */
    public VanillaIceCream(Position position, boolean isMachine) {
        super(position, "vanilla", isMachine);
    }

    @Override
    public void move(Direction dir) throws BadIceCreamException {
        this.direction = dir;
        position = position.getNextPosition(dir);
    }

    /**
     * Returns the sprite path for vanilla ice cream according to
     * direction and whether it is machine controlled or not.
     */
    @Override
    public String getImagePath() {
        if (isMachine) {
            switch (direction) {
                case LEFT:  return "resources/vainillaM_left.png";
                case RIGHT: return "resources/vainillaM_right.png";
                case UP:    return "resources/vainillaM_up.png";
                case DOWN:
                default:    return "resources/vainillaM_front.png";
            }
        }
        switch (direction) {
            case LEFT:  return "resources/vanilla_left.png";
            case RIGHT: return "resources/vanilla_right.png";
            case UP:    return "resources/vanilla_up.png";
            case DOWN:
            default:    return "resources/vanilla_front.png";
        }
    }
}
