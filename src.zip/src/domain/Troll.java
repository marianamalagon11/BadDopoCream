package domain;

/**
 * Basic troll enemy that patrols in straight lines.
 * Changes direction clockwise when hitting obstacles.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Troll extends Enemy {

    /**
     * Constructs a Troll at the given position with speed.
     * @param position Initial position.
     * @param speedTicks Speed of movement.
     */
    public Troll(Position position, int speedTicks) {
        super(position, false, speedTicks);
        this.direction = Direction.RIGHT;
    }

    /**
     * Movement behavior for Troll (clockwise patrol).
     */
    @Override
    protected void moveEnemy() {
        Position nextPos = position.getNextPosition(direction);

        // Verificar si puede moverse
        if (isValidMove(nextPos)) {
            this.position = nextPos;
        } else {
            // Cambiar dirección en sentido horario
            direction = getClockwiseDirection(direction);
        }
    }

    /**
     * Updates the enemy behavior (patrols in clockwise pattern).
     * @param players Array of players (not used by Troll).
     * @param map Game map for collision detection.
     */
    @Override
    public void update(Player[] players, Map map) {
        // Usar el sistema de ticks del enemy padre
        tickCounter++;
        if (tickCounter < speedTicks) {
            return;
        }
        tickCounter = 0;

        Position nextPos = position.getNextPosition(direction);

        if (map.isValidPosition(nextPos)) {
            Block block = map.getBlock(nextPos.getX(), nextPos.getY());
            if (block == null && !isIgluPosition(nextPos)) {
                this.position = nextPos;
            } else {
                direction = getClockwiseDirection(direction);
            }
        } else {
            direction = getClockwiseDirection(direction);
        }
    }

    /**
     * Checks if the move is valid (basic check).
     * @param pos Next position.
     * @return True if valid.
     */
    private boolean isValidMove(Position pos) {
        return pos.getX() >= 0 && pos.getX() < 15 &&
                pos.getY() >= 0 && pos.getY() < 14;
    }

    /**
     * Returns the next direction in clockwise rotation.
     * @param current Current direction.
     * @return Next clockwise direction.
     */
    private Direction getClockwiseDirection(Direction current) {
        switch (current) {
            case RIGHT:
                return Direction.DOWN;
            case DOWN:
                return Direction.LEFT;
            case LEFT:
                return Direction.UP;
            case UP:
                return Direction.RIGHT;
            default:
                return Direction.RIGHT;
        }
    }

    /**
     * Checks if position is inside the igloo area.
     * @param pos Position to check.
     * @return True if inside igloo.
     */
    private boolean isIgluPosition(Position pos) {
        int dx = Math.abs(pos.getX() - 7);
        int dy = Math.abs(pos.getY() - 7);
        return dx <= 1 && dy <= 1;
    }

    /**
     * Returns the image path based on current direction.
     * @return Path to sprite.
     */
    @Override
    public String getImagePath() {
        switch (direction) {
            case UP:
                return "resources/troll_up.gif";
            case DOWN:
                return "resources/troll_down.gif";
            case LEFT:
                return "resources/troll_left.gif";
            case RIGHT:
                return "resources/troll_right.gif";
            default:
                return "resources/troll_right.gif";
        }
    }
}
