package domain;

/**
 * Strawberry ice cream playable character.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class StrawberryIceCream extends Player {

    /**
     * Builds a strawberry ice cream player.
     * @param position  initial grid position.
     * @param isMachine true if controlled by the machine (AI), false if human.
     */
    public StrawberryIceCream(Position position, boolean isMachine) {
        super(position, "strawberry", isMachine);
    }

    @Override
    public void move(Direction dir) throws BadIceCreamException {
        this.direction = dir;
        position = position.getNextPosition(dir);
    }

    /**
     * Returns the sprite path for strawberry ice cream according to
     * direction and whether it is machine controlled or not.
     */
    @Override
    public String getImagePath() {
        if (isMachine) {
            switch (direction) {
                case LEFT:  return "resources/straberryM_left.png";
                case RIGHT: return "resources/straberryM_right.png";
                case UP:    return "resources/straberryM_up.png";
                case DOWN:
                default:    return "resources/straberryM_front.png";
            }
        }
        switch (direction) {
            case LEFT:  return "resources/straberry_left.png";
            case RIGHT: return "resources/straberry_right.png";
            case UP:    return "resources/straberry_up.png";
            case DOWN:
            default:    return "resources/straberry_front.png";
        }
    }
}
