package domain;

/**
 * Abstract base class for machine-controlled players with AI behavior.
 * Defines the interface for different AI profiles.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public abstract class Machine {

    protected String profileType;

    /**
     * Constructs a machine with a specific profile type.
     * @param profileType The AI profile ("hungry", "fearful", "expert").
     */
    public Machine(String profileType) {
        this.profileType = profileType;
    }

    /**
     * Returns the profile type of this machine.
     * @return Profile type string.
     */
    public String getProfileType() {
        return profileType;
    }

    /**
     * Calculates and returns the next best move for this machine.
     * @param player The player controlled by this machine.
     * @param level The current game level.
     * @return The direction to move.
     */
    public abstract Direction getNextMove(Player player, Level level);

    /**
     * Evaluates if the machine should perform an action (create/break ice).
     * @param player The player controlled by this machine.
     * @param level The current game level.
     * @return True if action should be performed, false otherwise.
     */
    public abstract boolean shouldPerformAction(Player player, Level level);
}
