package domain;

import java.util.List;
import java.util.ArrayList;
/**
 * Factory class for creating fruit instances from string representations.
 * Supports multiple fruit types: Banana, Grape, Cherry, Pineapple, and Cactus.
 * Parses comma-separated values to generate fruit objects for level loading.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class FruitFactory {
    /**
     * Parses a list of string lines into fruit instances.
     * Each line should follow CSV format: "TYPE,X,Y".
     * Example: "banana,5,7" creates a Banana at position (5,7).
     * Supported types (case-insensitive): banana, grape, cherry, pineapple, cactus.
     * @param lines List of string lines, each representing one fruit in CSV format.
     * @return List of Fruit instances parsed from the lines.
     * @throws BadIceCreamException If fruit type is unknown or line format is invalid.
     */
    public static List<Fruit> fromString(List<String> lines) throws BadIceCreamException {
        List<Fruit> fruits = new ArrayList<>();

        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length < 3) continue;

            String type = parts[0];
            int x = Integer.parseInt(parts[1]);
            int y = Integer.parseInt(parts[2]);

            Position pos = new Position(x, y);

            switch (type.toLowerCase()) {
                case "banana":
                    fruits.add(new Banana(pos));
                    break;
                case "grape":
                    fruits.add(new Grape(pos));
                    break;
                case "cherry":
                    fruits.add(new Cherry(pos));
                    break;
                case "pineapple":
                    fruits.add(new Pineapple(pos));
                    break;
                case "cactus":
                    fruits.add(new Cactus(pos));
                    break;
                default:
                    throw new BadIceCreamException("Unknown fruit: " + type);
            }
        }

        return fruits;
    }
}
