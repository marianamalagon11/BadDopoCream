package domain;

/**
 * Chocolate ice cream playable character.
 * Uses chocolate_* sprites for human and chocolateM_* sprites for machine.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class ChocolateIceCream extends Player {

    /**
     * Builds a chocolate ice cream player.
     * @param position  initial grid position.
     * @param isMachine true if controlled by the machine (AI), false if human.
     */
    public ChocolateIceCream(Position position, boolean isMachine) {
        super(position, "chocolate", isMachine);
    }

    @Override
    public void move(Direction dir) throws BadIceCreamException {
        this.direction = dir;
        position = position.getNextPosition(dir);
    }

    /**
     * Returns the sprite path for chocolate ice cream according to
     * direction and whether it is machine controlled or not.
     */
    @Override
    public String getImagePath() {
        if (isMachine) {
            switch (direction) {
                case LEFT:  return "resources/chocolateM_left.png";
                case RIGHT: return "resources/chocolateM_right.png";
                case UP:    return "resources/chocolateM_up.png";
                case DOWN:
                default:    return "resources/chocolateM_front.png";
            }
        }
        switch (direction) {
            case LEFT:  return "resources/chocolate_left.png";
            case RIGHT: return "resources/chocolate_right.png";
            case UP:    return "resources/chocolate_up.png";
            case DOWN:
            default:    return "resources/chocolate_front.png";
        }
    }
}
