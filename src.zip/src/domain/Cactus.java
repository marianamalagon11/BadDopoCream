package domain;

/**
 * Cactus fruit that grows spikes every 30 seconds.
 * When spiky, eliminates players. When normal, worth 250 points.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Cactus extends Fruit {

    private boolean hasSpikes;
    private long lastSpikeChangeTime;
    private static final long SPIKE_CYCLE_DURATION = 30000; // 30 segundos

    /**
     * Constructs a Cactus at the given position.
     * @param position Initial position of the cactus.
     */
    public Cactus(Position position) {
        super(position, 250);
        this.hasSpikes = false;
        this.lastSpikeChangeTime = System.currentTimeMillis();
    }

    /**
     * Returns the image path for cactus based on spike state.
     * @return path to cactus image file.
     */
    @Override
    public String getImagePath() {
        if (hasSpikes) {
            return "resources/cactusPuas.gif";
        } else {
            return "resources/cactus.gif";
        }
    }

    /**
     * Updates the cactus spike state based on time.
     */
    @Override
    public void update() {
        updateSpikeState();
    }

    /**
     * Updates the spike state based on elapsed time.
     * Alternates between spiky and normal every 30 seconds.
     */
    public void updateSpikeState() {
        if (isCollected()) {
            return;
        }

        long currentTime = System.currentTimeMillis();
        long timePassed = currentTime - lastSpikeChangeTime;

        if (timePassed >= SPIKE_CYCLE_DURATION) {
            hasSpikes = !hasSpikes;
            lastSpikeChangeTime = currentTime;
        }
    }

    /**
     * Checks if the cactus currently has spikes.
     * @return True if spiky, false if normal.
     */
    public boolean hasSpikes() {
        return hasSpikes;
    }

    /**
     * Checks if a player collided with a spiky cactus (player dies).
     * @param playerPosition Position of the player.
     * @return True if player touched spiky cactus.
     */
    public boolean killsPlayer(Position playerPosition) {
        if (isCollected() || !hasSpikes) {
            return false;
        }
        return this.position.equals(playerPosition);
    }

    /**
     * Forces the cactus to grow spikes immediately (for testing).
     */
    public void forceSpikes() {
        this.hasSpikes = true;
        this.lastSpikeChangeTime = System.currentTimeMillis();
    }

    /**
     * Forces the cactus to remove spikes immediately (for testing).
     */
    public void removeSpikes() {
        this.hasSpikes = false;
        this.lastSpikeChangeTime = System.currentTimeMillis();
    }

    /**
     * Resets the spike cycle timer.
     */
    public void resetSpikeTimer() {
        this.lastSpikeChangeTime = System.currentTimeMillis();
    }

    /**
     * Gets time remaining until next spike state change.
     * @return Milliseconds until change.
     */
    public long getTimeUntilStateChange() {
        long currentTime = System.currentTimeMillis();
        long timePassed = currentTime - lastSpikeChangeTime;
        return Math.max(0, SPIKE_CYCLE_DURATION - timePassed);
    }

    /**
     * Indicates that this fruit is a cactus.
     * @return always true for Cactus instances.
     */
    public boolean isCactus() {
        return true;
    }

    /**
     * Override collect to only allow collection when no spikes.
     */
    @Override
    public void collect() {
        if (!hasSpikes) {
            this.collected = true;
        }
    }
}
