package domain;
import java.lang.Exception;
/**
 * Custom exception for Bad Ice Cream game logic errors.
 * Defines standard error messages for consistent error handling throughout the project.
 * Laura Castillo,Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class BadIceCreamException extends Exception {
    public static final String INVALID_MOVE = "Invalid move: cell is blocked or out of bounds.";
    public static final String ICE_BLOCK_ERROR = "Cannot create or break ice block here.";
    public static final String RESOURCE_LOAD_ERROR = "Error loading game resource";
    public static final String LEVEL_SETUP_ERROR = "Error during level setup.";
    public static final String FRUIT_COLLECTION_ERROR = "Error collecting fruit.";
    public static final String ENEMY_COLLISION_ERROR = "Player collided with enemy.";
    public static final String MAP_INDEX_ERROR = "Grid position or index out of bounds.";
    public static final String UNKNOWN_ERROR = "Unknown error occurred in Bad Ice Cream.";

    /**
     * Constructs a BadIceCreamException with the specified detail message.
     *
     * @param message the detail message.
     */
    public BadIceCreamException(String message) {
        super(message);
    }

    /**
     * Constructs a BadIceCreamException with the specified detail message and cause.
     *
     * @param message the detail message.
     * @param cause   the cause of the error.
     */
    public BadIceCreamException(String message, Throwable cause) {
        super(message, cause);
    }
}
