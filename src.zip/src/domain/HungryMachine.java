package domain;

import java.util.List;
import java.util.ArrayList;

/**
 * AI profile focused on collecting fruits.
 * Goes for nearest fruit, avoids going back and forth.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class HungryMachine extends Machine {

    private Position lastPosition = null;
    private Position twoPositionsAgo = null;
    private Direction lastDirection = Direction.RIGHT;

    /**
     * Constructs a hungry machine profile.
     */
    public HungryMachine() {
        super("hungry");
    }

    /**
     * Always moves towards the nearest fruit without oscillating.
     * @param player The player controlled by this machine.
     * @param level The current game level.
     * @return Direction towards nearest fruit.
     */
    @Override
    public Direction getNextMove(Player player, Level level) {
        Position playerPos = player.getPosition();

        // actualizar historial de posiciones
        twoPositionsAgo = lastPosition;
        lastPosition = new Position(playerPos.getX(), playerPos.getY());

        // buscar la fruta q esté más cerca
        Fruit nearest = findNearestFruit(playerPos, level.getFruits());

        if (nearest == null) {
            return getRandomValidDirection(playerPos, level.getMap());
        }

        // calcular dirección hacia la fruta
        Position fruitPos = nearest.getPosition();
        int dx = fruitPos.getX() - playerPos.getX();
        int dy = fruitPos.getY() - playerPos.getY();

        // crear lista de las posibles direcciones hacia la fruta
        List<DirectionChoice> choices = new ArrayList<>();

        // agregar dirección horizontal si hay distancia en X
        if (dx != 0) {
            Direction dirX = dx > 0 ? Direction.RIGHT : Direction.LEFT;
            choices.add(new DirectionChoice(dirX, Math.abs(dx)));
        }

        // agregar dirección vertical si hay distancia en Y
        if (dy != 0) {
            Direction dirY = dy > 0 ? Direction.DOWN : Direction.UP;
            choices.add(new DirectionChoice(dirY, Math.abs(dy)));
        }

        // ordenar por distancia (mayor primero)
        choices.sort((a, b) -> b.priority - a.priority);

        // intentar direcciones
        for (DirectionChoice choice : choices) {
            Position next = playerPos.getNextPosition(choice.dir);

            // no volver a la posición de hace 2 movimientos, para q no se quede ahí
            boolean wouldGoBack = twoPositionsAgo != null && next.equals(twoPositionsAgo);

            if (!wouldGoBack && level.getMap().isValidPosition(next)) {
                Block block = level.getMap().getBlock(next.getX(), next.getY());

                // si está libre, va
                if (block == null) {
                    lastDirection = choice.dir;
                    return choice.dir;
                }

                // si tiene hielo, va y lo romper
                if (block.isIce()) {
                    lastDirection = choice.dir;
                    return choice.dir;
                }
            }
        }

        // si las direcciones hacia la fruta causan oscilación o están bloqueadas,
        // buscar cualquier dirección que no sea volver atrás
        Direction[] allDirs = {Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT};

        for (Direction dir : allDirs) {
            Position next = playerPos.getNextPosition(dir);
            boolean wouldGoBack = twoPositionsAgo != null && next.equals(twoPositionsAgo);

            if (!wouldGoBack && level.getMap().isValidPosition(next)) {
                Block block = level.getMap().getBlock(next.getX(), next.getY());
                if (block == null) {
                    lastDirection = dir;
                    return dir;
                }
            }
        }

        // si solo puede volver atrás, que lo haga (mejor que quedarse quieto)
        for (DirectionChoice choice : choices) {
            Position next = playerPos.getNextPosition(choice.dir);
            if (level.getMap().isValidPosition(next)) {
                Block block = level.getMap().getBlock(next.getX(), next.getY());
                if (block == null || block.isIce()) {
                    lastDirection = choice.dir;
                    return choice.dir;
                }
            }
        }

        // todo bloqueado, mantener última dirección
        return lastDirection;
    }

    /**
     * Decides if should break ice.
     * @param player The player.
     * @param level The level.
     * @return True if should break ice.
     */
    @Override
    public boolean shouldPerformAction(Player player, Level level) {
        Position next = player.getPosition().getNextPosition(player.getDirection());

        if (!level.getMap().isValidPosition(next)) return false;

        Block block = level.getMap().getBlock(next.getX(), next.getY());

        // romper hielo
        return block != null && block.isIce();
    }

    /**
     * Finds the nearest uncollected fruit.
     * @param pos Current position.
     * @param fruits List of all fruits.
     * @return Nearest fruit or null.
     */
    private Fruit findNearestFruit(Position pos, List<Fruit> fruits) {
        Fruit nearest = null;
        int minDistance = Integer.MAX_VALUE;

        for (Fruit f : fruits) {
            if (!f.isCollected()) {
                int distance = manhattanDistance(pos, f.getPosition());
                if (distance < minDistance) {
                    minDistance = distance;
                    nearest = f;
                }
            }
        }

        return nearest;
    }

    /**
     * Calculates Manhattan distance.
     * @param a First position.
     * @param b Second position.
     * @return Manhattan distance.
     */
    private int manhattanDistance(Position a, Position b) {
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY());
    }

    /**
     * Returns random valid direction.
     * @param pos Current position.
     * @param map Game map.
     * @return Random valid direction.
     */
    private Direction getRandomValidDirection(Position pos, Map map) {
        Direction[] dirs = {Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT};
        List<Direction> validDirs = new ArrayList<>();

        for (Direction dir : dirs) {
            Position next = pos.getNextPosition(dir);
            if (map.isValidPosition(next)) {
                Block block = map.getBlock(next.getX(), next.getY());
                if (block == null) {
                    validDirs.add(dir);
                }
            }
        }

        if (validDirs.isEmpty()) return Direction.RIGHT;

        return validDirs.get((int)(Math.random() * validDirs.size()));
    }

    /**
     * Helper class for direction choices.
     */
    private static class DirectionChoice {
        Direction dir;
        int priority;

        DirectionChoice(Direction dir, int priority) {
            this.dir = dir;
            this.priority = priority;
        }
    }
}
