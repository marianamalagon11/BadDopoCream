package domain;

import java.util.List;

/**
 * Main game controller responsible for running logic, updates, and win/lose status.
 * Coordinates players, level, and game manager to realize gameplay.
 * Handles collisions, fruit collection, phase management, and victory conditions.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class BadIceCream {

    private Player player1;
    private Player player2;
    private int numberOfPlayers;
    private Level level;
    private GameManager gameManager;
    private boolean running;

    // variables oleadas
    private boolean bananasPhase;
    private boolean grapesPhase;
    private boolean pineapplesPhase;
    private int bananasCollected;
    private int pineapplesCollected;
    private int totalBananas;
    private int totalPineapples;

    // resultados del juego
    private boolean gameOver;
    private int winnerPlayerIndex;
    private Player winnerPlayer;
    private boolean victory;

    /**
     * Constructs the main game controller for single player mode.
     * @param player Player character instance.
     * @param level  Current game level.
     */
    public BadIceCream(Player player, Level level) {
        this(player, null, 1, level);
    }

    /**
     * Constructs the main game controller for single or multiplayer mode.
     * @param player1 Player 1 instance.
     * @param player2 Player 2 instance (can be null for single player).
     * @param numberOfPlayers Number of players (1 or 2).
     * @param level Current game level.
     */
    public BadIceCream(Player player1, Player player2, int numberOfPlayers, Level level) {
        this.player1 = player1;
        this.player2 = player2;
        this.numberOfPlayers = numberOfPlayers;
        this.level = level;
        this.gameManager = new GameManager();
        this.gameManager.setTotalFruits(level.getFruits().size());
        this.running = false;


        if (level.isCustomConfigured()) {
            // todo aparece en el inicio
            this.bananasPhase = true;
            this.grapesPhase = false;
            this.pineapplesPhase = false;
            this.bananasCollected = 0;
            this.pineapplesCollected = 0;
            this.totalBananas = 0;
            this.totalPineapples = 0;
        } else {
            this.bananasPhase = true;
            this.grapesPhase = false;
            this.pineapplesPhase = false;
            this.bananasCollected = 0;
            this.pineapplesCollected = 0;
            countFruitsByType();
        }

        // estado inicial
        this.gameOver = false;
        this.winnerPlayerIndex = 0;
        this.winnerPlayer = null;
        this.victory = false;
    }

    /**
     * Counts total bananas/cherries and pineapples in the level.
     */
    //en este sin importar nivel reutilizamos el contador por facilidad, depende de la oleada
    private void countFruitsByType() {
        totalBananas = 0;
        totalPineapples = 0;

        for (Fruit fruit : level.getFruits()) {
            if (fruit.isBanana() || fruit.isCherry()) {
                totalBananas++;
            } else if (fruit.isPineapple()) {
                totalPineapples++;
            }
        }
    }

    /**
     * Starts the game session, setting running flag to true.
     */
    public void startGame() {
        running = true;
    }

    /**
     * Handles player's movement input, with boundary and collision validation.
     * @param dir Direction requested for movement.
     * @throws BadIceCreamException If the movement is not allowed or the target cell is blocked.
     */
    public void handleInput(Direction dir) throws BadIceCreamException {
        player1.setDirection(dir);
        Position next = player1.getPosition().getNextPosition(dir);

        if (!level.getMap().isValidPosition(next)) {
            throw new BadIceCreamException(BadIceCreamException.INVALID_MOVE);
        }

        Block block = level.getMap().getBlock(next.getX(), next.getY());

        // permitir moverse sobre fogatas, asi lo maten
        if (block != null && !block.isFogata()) {
            throw new BadIceCreamException(BadIceCreamException.INVALID_MOVE);
        }

        player1.move(dir);
    }

    /**
     * Tries to create an ice block in front of the player and
     * sets the player's state to BLOWING.
     * @throws BadIceCreamException If the space is blocked or outside the grid.
     */
    public void createIceBlock() throws BadIceCreamException {
        Position inFront = player1.getPosition().getNextPosition(player1.getDirection());
        level.getMap().addIceBlock(inFront);
        player1.setState(PlayerState.BLOWING);
    }

    /**
     * Tries to break an ice block in front of the player and
     * sets the player's state to ANGRY.
     * @throws BadIceCreamException If the space is empty or cannot be broken.
     */
    public void breakIceBlock() throws BadIceCreamException {
        Position inFront = player1.getPosition().getNextPosition(player1.getDirection());
        player1.setState(PlayerState.ANGRY);
    }

    /**
     * Main update cycle: moves enemies, checks collisions and win/loss conditions.
     * Should be called in a loop at fixed intervals.
     */
    public void update() {
        try {
            // actualizar enemigos
            updateEnemies();

            // colisiones con frutas
            handleFruitCollisions();

            // actualizar frutas especiales
            updateSpecialFruits();

            // verificar obstáculos mortales
            if (checkDeadlyObstacles()) {
                return; // Juego terminó
            }

            // colisiones con enemigos
            if (checkEnemyCollisions()) {
                return; // Juego terminó
            }

            // condiciones de victoria
            checkVictoryConditions();

        } catch (Exception e) {
            System.err.println("Error in BadIceCream.update: " + e.getMessage());
        }
    }

    /**
     * Updates all enemies using the new system.
     */
    private void updateEnemies() {
        Player[] players;
        if (numberOfPlayers == 2) {
            players = new Player[]{player1, player2};
        } else {
            players = new Player[]{player1};
        }

        for (Enemy enemy : level.getEnemies()) {
            enemy.update(players, level.getMap());
        }
    }

    /**
     * Handles fruit collection for both players.
     */
    private void handleFruitCollisions() {
        // Player 1 vs fruits
        handlePlayerFruitCollision(player1, 1);

        // Player 2 vs fruits
        if (numberOfPlayers == 2 && player2 != null) {
            handlePlayerFruitCollision(player2, 2);
        }
    }

    /**
     * Handles fruit collision for a specific player.
     * @param player The player.
     * @param playerNumber Player number (1 or 2).
     */
    private void handlePlayerFruitCollision(Player player, int playerNumber) {
        Fruit fruit = CollisionDetector.checkPlayerFruitCollision(player, level.getFruits());

        if (fruit != null && !fruit.isCollected()) {
            boolean canCollect = canCollectFruit(fruit);

            if (canCollect) {
                fruit.collect();
                gameManager.collectFruit();

                // agregar puntos al jugador correcto
                if (playerNumber == 1) {
                    gameManager.addScorePlayer1(fruit.getPoints());
                } else {
                    gameManager.addScorePlayer2(fruit.getPoints());
                }

                // actualizar contadores de fase sólo en niveles que son default
                if (!level.isCustomConfigured()) {
                    updatePhaseCounters(fruit);
                }
            }
        }
    }

    /**
     * Determines if a fruit can be collected based on current phase.
     * @param fruit The fruit to check.
     * @return True if collectible, false otherwise.
     */
    private boolean canCollectFruit(Fruit fruit) {
        if (level.isCustomConfigured()) {
            // cualquier fruta se puede recoger siempre en los configurados
            return true;
        }

        if (level.getLevelNumber() == 3) {
            // Level 3: Cherries primero, luego Cactus
            if (bananasPhase && fruit.isCherry()) {
                return true;
            } else if (grapesPhase && fruit.isCactus()) {
                return true;
            }
        } else if (level.getLevelNumber() == 2) {
            // Level 2: Bananas primero, luego Piñas
            if (bananasPhase && fruit.isBanana()) {
                return true;
            } else if (pineapplesPhase && fruit.isPineapple()) {
                return true;
            }
        } else {
            // Level 1: Bananas primero, luego Uvas
            if (bananasPhase && fruit.isBanana()) {
                return true;
            } else if (grapesPhase && fruit.isGrape()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Updates phase counters when a fruit is collected.
     * @param fruit The collected fruit.
     */
    private void updatePhaseCounters(Fruit fruit) {
        if (fruit.isBanana() || fruit.isCherry()) {
            bananasCollected++;

            if (bananasCollected >= totalBananas && bananasPhase) {
                bananasPhase = false;

                if (level.getLevelNumber() == 3) {
                    grapesPhase = true;
                } else if (level.getLevelNumber() == 2) {
                    pineapplesPhase = true;
                } else {
                    grapesPhase = true;
                }
            }
        } else if (fruit.isPineapple()) {
            pineapplesCollected++;
        }
    }

    /**
     * Updates special fruits (Cherry, Cactus, Pineapple).
     */
    private void updateSpecialFruits() {
        Player[] playersForUpdate;
        if (numberOfPlayers == 2) {
            playersForUpdate = new Player[]{player1, player2};
        } else {
            playersForUpdate = new Player[]{player1};
        }

        level.update(playersForUpdate);
    }

    /**
     * Checks deadly obstacles (cactus with spikes and lit campfires).
     * @return True if game ended, false otherwise.
     */
    private boolean checkDeadlyObstacles() {
        // verificar colisión con cactus con púas
        if (checkCactusCollisions()) {
            return true;
        }

        // verificar colisión con fogatas encendidas
        if (checkCampfireCollisions()) {
            return true;
        }

        return false;
    }

    /**
     * Checks collisions with spiky cactus.
     * @return True if a player died, false otherwise.
     */
    private boolean checkCactusCollisions() {
        for (Fruit fruitCheck : level.getFruits()) {
            if (fruitCheck.isCactus() && !fruitCheck.isCollected()) {
                Cactus cactus = (Cactus) fruitCheck;

                // Player 1 vs cactus
                if (cactus.killsPlayer(player1.getPosition())) {
                    handlePlayerDeath(1, "cactus");
                    return true;
                }

                // Player 2 vs cactus
                if (player2 != null && cactus.killsPlayer(player2.getPosition())) {
                    handlePlayerDeath(2, "cactus");
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Checks collisions with lit campfires.
     * @return True if a player died, false otherwise.
     */
    private boolean checkCampfireCollisions() {
        for (Fogata fogata : level.getMap().getFogatas()) {
            // player 1 vs fogata
            if (fogata.killsPlayer(player1.getPosition())) {
                handlePlayerDeath(1, "campfire");
                return true;
            }

            // player 2 vs fogata
            if (player2 != null && fogata.killsPlayer(player2.getPosition())) {
                handlePlayerDeath(2, "campfire");
                return true;
            }
        }

        return false;
    }

    /**
     * Handles player death by obstacles.
     * @param deadPlayer Player number that died (1 or 2).
     * @param cause Cause of death (for logging).
     */
    private void handlePlayerDeath(int deadPlayer, String cause) {
        if (numberOfPlayers == 2) {
            // En modo 2 jugadores, el otro gana
            int winner = (deadPlayer == 1) ? 2 : 1;
            gameManager.setWinnerPlayer(winner);
            winnerPlayerIndex = winner;
            winnerPlayer = (winner == 1) ? player1 : player2;
        } else {
            // En modo 1 jugador, game over
            gameManager.setWinnerPlayer(0);
            winnerPlayerIndex = 0;
            winnerPlayer = null;
        }

        gameManager.setGameOver();
        gameOver = true;
        victory = false;
        running = false;
    }

    /**
     * Checks collisions with enemies.
     * @return True if game ended, false otherwise.
     */
    private boolean checkEnemyCollisions() {
        boolean p1Dead = CollisionDetector.checkPlayerEnemyCollision(player1, level.getEnemies());
        boolean p2Dead = false;

        if (numberOfPlayers == 2 && player2 != null) {
            p2Dead = CollisionDetector.checkPlayerEnemyCollision(player2, level.getEnemies());
        }

        if (p1Dead || p2Dead) {
            if (numberOfPlayers == 2) {
                if (p1Dead && !p2Dead) {
                    gameManager.setWinnerPlayer(2);
                    winnerPlayerIndex = 2;
                    winnerPlayer = player2;
                } else if (!p1Dead && p2Dead) {
                    gameManager.setWinnerPlayer(1);
                    winnerPlayerIndex = 1;
                    winnerPlayer = player1;
                } else {
                    gameManager.setWinnerPlayer(0);
                    winnerPlayerIndex = 0;
                    winnerPlayer = null;
                }
            } else {
                gameManager.setWinnerPlayer(0);
                winnerPlayerIndex = 0;
                winnerPlayer = null;
            }

            gameManager.setGameOver();
            gameOver = true;
            victory = false;
            running = false;
            return true;
        }

        return false;
    }

    /**
     * Checks victory conditions (all fruits collected or time up).
     */
    private void checkVictoryConditions() {
        // verificar si todas las frutas fueron recolectadas
        int totalCollected = 0;
        for (Fruit f : level.getFruits()) {
            if (f.isCollected()) {
                totalCollected++;
            }
        }

        if (totalCollected >= level.getFruits().size()) {
            handleAllFruitsCollected();
            return;
        }

        // verificar si el tiempo se acabó
        if (gameManager.getTimeRemaining() <= 0 && !gameOver) {
            handleTimeUp();
        }
    }

    /**
     * Handles victory when all fruits are collected.
     */
    private void handleAllFruitsCollected() {
        if (numberOfPlayers == 2) {
            gameManager.decideWinnerByScore();
            winnerPlayerIndex = gameManager.getWinnerPlayer();

            if (winnerPlayerIndex == 1) {
                winnerPlayer = player1;
            } else if (winnerPlayerIndex == 2) {
                winnerPlayer = player2;
            } else {
                winnerPlayer = null;
            }
        } else {
            gameManager.setWinnerPlayer(1);
            winnerPlayerIndex = 1;
            winnerPlayer = player1;
            gameManager.checkVictory();
        }

        gameOver = true;
        victory = true;
        running = false;
    }

    /**
     * Handles game end when time runs out.
     */
    private void handleTimeUp() {
        if (numberOfPlayers == 2) {
            gameManager.decideWinnerByScore();
            winnerPlayerIndex = gameManager.getWinnerPlayer();

            if (winnerPlayerIndex == 1) {
                winnerPlayer = player1;
            } else if (winnerPlayerIndex == 2) {
                winnerPlayer = player2;
            } else {
                winnerPlayer = null;
            }

            victory = true;
        } else {
            gameManager.setGameOver();
            winnerPlayerIndex = 0;
            winnerPlayer = null;
            victory = false;
        }

        gameOver = true;
        running = false;
    }


    /**
     * Returns the game manager instance.
     * @return GameManager instance controlling scores and time.
     */
    public GameManager getGameManager() {
        return gameManager;
    }

    /**
     * Returns whether the game has ended.
     * @return True if game is over, false otherwise.
     */
    public boolean isGameOver() {
        return gameOver;
    }

    /**
     * Returns the index of the winning player.
     * @return 1 for player 1, 2 for player 2, 0 for tie or game over.
     */
    public int getWinnerPlayerIndex() {
        return winnerPlayerIndex;
    }

    /**
     * Returns the winning player instance.
     * @return Player object of the winner, or null if tie or game over.
     */
    public Player getWinnerPlayer() {
        return winnerPlayer;
    }

    /**
     * Returns whether the game ended in victory.
     * @return True if players won, false if game over or time up.
     */
    public boolean isVictory() {
        return victory;
    }

    /**
     * Returns whether the game is in bananas collection phase.
     * @return True if collecting bananas/cherries, false otherwise.
     */
    public boolean isBananasPhase() {
        return bananasPhase;
    }

    /**
     * Returns whether the game is in grapes collection phase.
     * @return True if collecting grapes/cactus, false otherwise.
     */
    public boolean isGrapesPhase() {
        return grapesPhase;
    }

    /**
     * Returns whether the game is in grapes collection phase.
     * @return True if collecting grapes/cactus, false otherwise.
     */
    public boolean isPineapplesPhase() {
        return pineapplesPhase;
    }

    /**
     * Returns the total number of bananas in the level.
     * @return Total bananas/cherries count for phase completion.
     */
    public int getTotalBananas() {
        return totalBananas;
    }

    /**
     * Returns the current level instance.
     * @return Level object being played.
     */
    public Level getLevel() {
        return level;
    }


}
