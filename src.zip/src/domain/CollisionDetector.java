package domain;

import java.util.List;

/**
 * Provides static methods for detecting collisions between players, fruits, and enemies.
 * Laura Castillo,Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class CollisionDetector {

    /**
     * Checks for a collision between the player and any uncollected fruit.
     * @param player The player character.
     * @param fruits List of all fruits in the level.
     * @return The fruit collided with, or null if no collision.
     */
    public static Fruit checkPlayerFruitCollision(Player player, List<Fruit> fruits) {
        for (Fruit fruit : fruits) {
            if (!fruit.isCollected() && fruit.getPosition().equals(player.getPosition())) {
                return fruit;
            }
        }
        return null;
    }

    /**
     * Checks if the player is colliding with any enemy.
     * @param player  The player character.
     * @param enemies List of all enemies in the level.
     * @return True if collision occurred, false otherwise.
     */
    public static boolean checkPlayerEnemyCollision(Player player, List<Enemy> enemies) {
        for (Enemy enemy : enemies) {
            if (enemy.getPosition().equals(player.getPosition())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if there is any block present at a position in the grid.
     * @param pos The position to check.
     * @param map Game map to use for lookup.
     * @return True if the cell is occupied by a block.
     */
    public static boolean checkBlockCollision(Position pos, Map map) {
        return map.getBlock(pos.getX(), pos.getY()) != null;
    }
}
