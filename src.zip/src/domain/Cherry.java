package domain;

/**
 * Cherry fruit that teleports to random free positions every 20 seconds.
 * Worth 150 points when collected.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Cherry extends Fruit {

    private int updateCounter = 0;
    private static final int TELEPORT_INTERVAL = 200; //20 segundos

    /**
     * Constructs a Cherry at the given position.
     * @param position Initial position of the cherry.
     */
    public Cherry(Position position) {
        super(position, 150);
        this.updateCounter = 0;
    }

    /**
     * Returns the image path for cherry.
     * @return path to cherry image file.
     */
    @Override
    public String getImagePath() {
        return "resources/cherry.gif";
    }

    /**
     * Updates the cherry counter.
     */
    @Override
    public void update() {
        if (!isCollected()) {
            updateCounter++;
        }
    }

    /**
     * Checks if it's time to teleport.
     * @return True if 200 ticks have passed.
     */
    public boolean shouldTeleport() {
        return updateCounter >= TELEPORT_INTERVAL && !isCollected();
    }

    /**
     * Teleports the cherry to a new random free position on the map.
     * @param map The game map to find free positions.
     * @throws BadIceCreamException If no free position is available.
     */
    public void teleport(Map map) throws BadIceCreamException {
        Position newPosition = findRandomFreePosition(map);
        if (newPosition != null) {
            this.position = newPosition;
            this.updateCounter = 0; // Resetea counter
        } else {
            throw new BadIceCreamException("No free position available for cherry teleport");
        }
    }

    /**
     * Finds a random free position on the map.
     * @param map The game map.
     * @return A free position, or null if none available.
     */
    private Position findRandomFreePosition(Map map) {
        int rows = map.getRows();
        int cols = map.getCols();
        int maxAttempts = 100;
        int attempts = 0;

        while (attempts < maxAttempts) {
            int x = (int) (Math.random() * cols);
            int y = (int) (Math.random() * rows);
            Position pos = new Position(x, y);

            if (map.isValidPosition(pos)) {
                Block block = map.getBlock(x, y);
                if (block == null && !isIgluPosition(pos)) {
                    return pos;
                }
            }
            attempts++;
        }

        return null;
    }

    /**
     * Checks if position is inside the igloo area.
     * @param pos Position to check.
     * @return True if inside igloo.
     */
    private boolean isIgluPosition(Position pos) {
        int dx = Math.abs(pos.getX() - 7);
        int dy = Math.abs(pos.getY() - 7);
        return dx <= 1 && dy <= 1;
    }

    /**
     * Resets the teleport timer.
     */
    public void resetTeleportTimer() {
        this.updateCounter = 0;
    }

    /**
     * Indicates that this fruit is a cherry.
     * @return always true for Cherry instances.
     */
    public boolean isCherry() {
        return true;
    }
}
