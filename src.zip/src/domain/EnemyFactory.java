package domain;

import java.util.ArrayList;
import java.util.List;

/**
 * Factory class for creating enemy instances from type strings and positions.
 * Supports multiple enemy types: Troll, Maceta, Calamar, and Narval.
 * Can parse enemies from string lines for level loading.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */

public class EnemyFactory {
    /**
     * Creates a single enemy instance based on type and position.
     * Uses default constructor parameters for each enemy type.
     * @param type Enemy type as string (case-insensitive): "troll", "maceta", "calamar", "narval".
     * @param pos Initial position for the enemy.
     * @return Enemy instance of the specified type.
     * @throws BadIceCreamException If type is null or unknown.
     */
     public static Enemy createEnemy(String type, Position pos) throws BadIceCreamException {
        if (type == null) throw new BadIceCreamException("Enemy type null");

        switch (type.toLowerCase()) {
            case "troll":
                return new Troll(pos, 5);

            case "maceta":
                return new Maceta(pos);

            case "calamar":
            case "squid":
                return new Calamar(pos);

            case "narval":
            case "narwhal":
                return new Narval(pos);

            default:
                throw new BadIceCreamException("Unknown enemy type: " + type);
        }
    }
    /**
     * Parses a list of string lines into enemy instances.
     * Each line should follow format: "TYPE X Y" or "TYPE,X,Y".
     * Example: "TROLL 2 3" creates a Troll at position (2,3).
     * @param lines List of string lines, each representing one enemy.
     * @return List of Enemy instances parsed from the lines.
     * @throws BadIceCreamException If enemy type is invalid or parsing fails.
     */
    public static List<Enemy> fromStringLines(List<String> lines) throws BadIceCreamException {
        List<Enemy> enemies = new ArrayList<>();
        if (lines == null) return enemies;

        for (String line : lines) {
            if (line.trim().isEmpty()) continue;
            String[] p = line.trim().split("[,\\s]+");
            if (p.length < 3) continue;
            String type = p[0];
            int x = Integer.parseInt(p[1]);
            int y = Integer.parseInt(p[2]);
            enemies.add(createEnemy(type, new Position(x, y)));
        }
        return enemies;
    }
}
