package domain;

/**
 * Narwhal enemy that charges in straight lines when aligned with players.
 * Destroys ice blocks during charge.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Narval extends Enemy {

    private boolean isCharging;
    private Direction chargeDirection;

    /**
     * Constructs a Narval enemy at the given position.
     * @param position Initial position.
     */
    public Narval(Position position) {
        super(position, true, 4); // Rompe hielo al embestir
        this.direction = Direction.RIGHT;
        this.isCharging = false;
    }

    /**
     * Movement behavior (not used, override update instead).
     */
    @Override
    protected void moveEnemy() {
        // No se usa
    }

    /**
     * Updates the enemy behavior (patrols and charges when aligned).
     * @param players Array of players.
     * @param map Game map.
     */
    @Override
    public void update(Player[] players, Map map) {
        if (isCharging) {
            continueCharge(map);
        } else {
            tickCounter++;
            if (tickCounter < speedTicks) {
                return;
            }
            tickCounter = 0;

            Player alignedPlayer = findAlignedPlayer(players);
            if (alignedPlayer != null) {
                startCharge(alignedPlayer);
            } else {
                patrol(map);
            }
        }
    }

    /**
     * Finds a player aligned horizontally or vertically.
     * @param players Array of players.
     * @return Aligned player or null.
     */
    private Player findAlignedPlayer(Player[] players) {
        for (Player player : players) {
            if (player != null) {
                Position playerPos = player.getPosition();

                if (playerPos.getY() == this.position.getY()) {
                    return player;
                }

                if (playerPos.getX() == this.position.getX()) {
                    return player;
                }
            }
        }
        return null;
    }

    /**
     * Starts charging towards the aligned player.
     * @param player Target player.
     */
    private void startCharge(Player player) {
        Position playerPos = player.getPosition();

        if (playerPos.getY() == this.position.getY()) {
            if (playerPos.getX() > this.position.getX()) {
                chargeDirection = Direction.RIGHT;
            } else {
                chargeDirection = Direction.LEFT;
            }
        } else if (playerPos.getX() == this.position.getX()) {
            if (playerPos.getY() > this.position.getY()) {
                chargeDirection = Direction.DOWN;
            } else {
                chargeDirection = Direction.UP;
            }
        }

        this.direction = chargeDirection;
        this.isCharging = true;
    }

    /**
     * Continues charging and breaks blocks in path.
     * @param map Game map.
     */
    private void continueCharge(Map map) {
        Position nextPos = position.getNextPosition(chargeDirection);

        if (!map.isValidPosition(nextPos)) {
            isCharging = false;
            return;
        }

        Block block = map.getBlock(nextPos.getX(), nextPos.getY());

        if (block != null && block.isIce()) {
            try {
                map.removeBlock(nextPos);
            } catch (BadIceCreamException e) {
                // Ignorar
            }
            this.position = nextPos;
        } else if (block == null) {
            this.position = nextPos;
        } else {
            isCharging = false;
        }
    }

    /**
     * Patrols the map in current direction.
     * @param map Game map.
     */
    private void patrol(Map map) {
        Position nextPos = position.getNextPosition(direction);

        if (map.isValidPosition(nextPos)) {
            Block block = map.getBlock(nextPos.getX(), nextPos.getY());
            if (block == null) {
                this.position = nextPos;
            } else {
                changeDirection();
            }
        } else {
            changeDirection();
        }
    }

    /**
     * Changes patrol direction randomly.
     */
    private void changeDirection() {
        Direction[] directions = {Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT};
        this.direction = directions[(int) (Math.random() * directions.length)];
    }

    /**
     * Returns the image path based on current direction.
     * @return Path to sprite.
     */
    @Override
    public String getImagePath() {
        switch (direction) {
            case UP:
                return "resources/narval_up.gif";
            case DOWN:
                return "resources/narval_front.gif";
            case LEFT:
                return "resources/narval_left.gif";
            case RIGHT:
                return "resources/narval_right.gif";
            default:
                return "resources/narval_front.gif";
        }
    }

    /**
     * Checks if currently charging.
     * @return true if charging.
     */
    public boolean isCharging() {
        return isCharging;
    }

    /**
     * Forces charge to stop.
     */
    public void stopCharge() {
        this.isCharging = false;
    }

    /**
     * Indicates this is a Narval enemy.
     * @return true.
     */
    @Override
    public boolean isNarval() {
        return true;
    }
}
