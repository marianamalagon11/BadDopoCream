package domain;

/**
 * Manages game progress including time, fruit collection and
 * independent scores for each player, as well as winner and
 * game-over flags.
 * Laura Castillo,Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class GameManager {

    private int scorePlayer1;
    private int scorePlayer2;
    private int timeRemaining;
    private int fruitsCollected;
    private int totalFruits;
    private boolean gameOver;
    private boolean victory;
    private int winnerPlayer;

    /**
     * Builds a new GameManager with default values for a level.
     * Initial time is 180 seconds (3 minutes) and both scores are zero.
     */
    public GameManager() {
        scorePlayer1 = 0;
        scorePlayer2 = 0;
        timeRemaining = 180;
        fruitsCollected = 0;
        totalFruits = 0;
        gameOver = false;
        victory = false;
        winnerPlayer = 0;
    }

    /**
     * Adds the specified number of points to player 1 score.
     * @param points value to add to player 1 score.
     */
    public void addScorePlayer1(int points) {
        scorePlayer1 += points;
    }

    /**
     * Adds the specified number of points to player 2 score.
     * @param points value to add to player 2 score.
     */
    public void addScorePlayer2(int points) {
        scorePlayer2 += points;
    }

    /**
     * Returns the current score for player 1.
     * @return score of player 1.
     */
    public int getScorePlayer1() {
        return scorePlayer1;
    }

    /**
     * Returns the current score for player 2.
     * @return score of player 2.
     */
    public int getScorePlayer2() {
        return scorePlayer2;
    }

    /**
     * Decreases the remaining time by one second if time is still positive.
     * Time never goes below zero.
     */
    public void decreaseTime() {
        if (timeRemaining > 0) {
            timeRemaining--;
        }
    }

    /**
     * Registers that one fruit has been collected.
     * The panel decides to which player the score is assigned.
     */
    public void collectFruit() {
        fruitsCollected++;
        checkVictory();
    }

    /**
     * Checks if all fruits have been collected and, if so,
     * sets victory and game-over flags to true.
     */
    public void checkVictory() {
        if (totalFruits > 0 && fruitsCollected >= totalFruits) {
            victory = true;
            gameOver = true;
        }
    }

    /**
     * Returns true if the game is over, either by defeat or victory.
     * @return true if game is over, false otherwise.
     */
    public boolean isGameOver() {
        return gameOver;
    }

    /**
     * Returns true if the level was completed by victory condition.
     * @return true if the player(s) won, false if they lost.
     */
    public boolean isVictory() {
        return victory;
    }

    /**
     * Returns remaining time in seconds.
     * @return time remaining for the level.
     */
    public int getTimeRemaining() {
        return timeRemaining;
    }

    /**
     * Returns the number of collected fruits so far.
     * @return total collected fruits count.
     */
    public int getFruitsCollected() {
        return fruitsCollected;
    }

    /**
     * Sets the total number of fruits for the current level.
     * @param totalFruits expected number of fruits.
     */
    public void setTotalFruits(int totalFruits) {
        this.totalFruits = totalFruits;
    }

    /**
     * Marks the game as lost (time over or enemy collision).
     * Victory is set to false and gameOver to true.
     */
    public void setGameOver() {
        this.gameOver = true;
        this.victory = false;
    }

    /**
     * Returns which player is currently marked as winner.
     * 0 = no winner or tie, 1 = player 1, 2 = player 2.
     * @return winner player index.
     */
    public int getWinnerPlayer() {
        return winnerPlayer;
    }

    /**
     * Sets the winner player index used for the end-game screen.
     * 0 = nobody/tie, 1 = player 1, 2 = player 2.
     * @param winnerPlayer index of winner player.
     */
    public void setWinnerPlayer(int winnerPlayer) {
        this.winnerPlayer = winnerPlayer;
    }

    /**
     * Compares both scores and decides the winner by score.
     * 1 = player 1, 2 = player 2, 0 = tie.
     * Also marks the game as finished with victory=true.
     */
    public void decideWinnerByScore() {
        if (scorePlayer1 > scorePlayer2) {
            winnerPlayer = 1;
        } else if (scorePlayer2 > scorePlayer1) {
            winnerPlayer = 2;
        } else {
            winnerPlayer = 0;
        }
        gameOver = true;
        victory = true;
    }
}
