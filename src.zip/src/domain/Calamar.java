package domain;

/**
 * Orange Squid enemy that chases players and breaks one ice block at a time.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Calamar extends Enemy {

    private boolean isBreakingBlock;
    private long breakStartTime;
    private static final long BREAK_DURATION = 500;

    /**
     * Constructs a Calamar enemy at the given position.
     * @param position Initial position.
     */
    public Calamar(Position position) {
        super(position, true, 6);
        this.direction = Direction.RIGHT;
        this.isBreakingBlock = false;
    }

    /**
     * Movement behavior (not used, override update instead).
     */
    @Override
    protected void moveEnemy() {
        // No se usa en esta implementación
    }

    /**
     * Updates the enemy behavior (chases and breaks blocks).
     * @param players Array of players to chase.
     * @param map Game map.
     */
    @Override
    public void update(Player[] players, Map map) {
        if (isBreakingBlock) {
            long elapsed = System.currentTimeMillis() - breakStartTime;
            if (elapsed >= BREAK_DURATION) {
                isBreakingBlock = false;
            }
            return;
        }

        tickCounter++;
        if (tickCounter < speedTicks) {
            return;
        }
        tickCounter = 0;

        Player nearestPlayer = findNearestPlayer(players);
        if (nearestPlayer != null) {
            chasePlayerAndBreakBlocks(nearestPlayer, map);
        }
    }

    /**
     * Finds the nearest player to this enemy.
     * @param players Array of players.
     * @return Nearest player or null.
     */
    private Player findNearestPlayer(Player[] players) {
        Player nearest = null;
        int minDistance = Integer.MAX_VALUE;

        for (Player player : players) {
            if (player != null) {
                int distance = manhattanDistance(this.position, player.getPosition());
                if (distance < minDistance) {
                    minDistance = distance;
                    nearest = player;
                }
            }
        }

        return nearest;
    }

    /**
     * Chases player and breaks ice blocks if encountered.
     * @param player Target player.
     * @param map Game map.
     */
    private void chasePlayerAndBreakBlocks(Player player, Map map) {
        Position playerPos = player.getPosition();
        Direction bestDirection = getBestDirectionTowards(playerPos);

        if (bestDirection != null) {
            this.direction = bestDirection;
            Position nextPos = position.getNextPosition(bestDirection);

            if (map.isValidPosition(nextPos)) {
                Block block = map.getBlock(nextPos.getX(), nextPos.getY());

                if (block != null && block.isIce()) {
                    try {
                        map.removeBlock(nextPos);
                        isBreakingBlock = true;
                        breakStartTime = System.currentTimeMillis();
                    } catch (BadIceCreamException e) {
                        // Ignorar error
                    }
                } else if (block == null) {
                    this.position = nextPos;
                }
            }
        }
    }

    /**
     * Gets the best direction towards target.
     * @param target Target position.
     * @return Best direction.
     */
    private Direction getBestDirectionTowards(Position target) {
        int dx = target.getX() - position.getX();
        int dy = target.getY() - position.getY();

        if (Math.abs(dx) > Math.abs(dy)) {
            if (dx > 0) {
                return Direction.RIGHT;
            } else {
                return Direction.LEFT;
            }
        } else {
            if (dy > 0) {
                return Direction.DOWN;
            } else {
                return Direction.UP;
            }
        }
    }

    /**
     * Calculates Manhattan distance.
     * @param a First position.
     * @param b Second position.
     * @return Distance.
     */
    private int manhattanDistance(Position a, Position b) {
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY());
    }

    /**
     * Returns the image path based on current direction.
     * @return Path to sprite.
     */
    @Override
    public String getImagePath() {
        switch (direction) {
            case UP:
                return "resources/calamar_up.gif";
            case DOWN:
                return "resources/calamar_front.gif";
            case LEFT:
                return "resources/calamar_left.gif";
            case RIGHT:
                return "resources/calamar_right.gif";
            default:
                return "resources/calamar_front.gif";
        }
    }

    /**
     * Checks if currently breaking a block.
     * @return true if breaking.
     */
    public boolean isBreakingBlock() {
        return isBreakingBlock;
    }

    /**
     * Indicates this is a Calamar enemy.
     * @return true.
     */
    @Override
    public boolean isCalamar() {
        return true;
    }
}
