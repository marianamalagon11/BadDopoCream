package domain;

import java.util.List;
import java.util.ArrayList;

/**
 * AI profile with optimal decision making.
 * Balances fruit collection with enemy avoidance using weighted scoring.
 * Breaks ice blocks strategically when surrounded or stuck.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class ExpertMachine extends Machine {

    private static final int DANGER_THRESHOLD = 3;
    private int stuckCounter = 0;
    private Position lastPosition = null;
    private Direction lastDirection = Direction.RIGHT;
    private List<String> recentPositions = new ArrayList<>();
    private static final int POSITION_HISTORY_SIZE = 6;
    private boolean shouldBreakIce = false;

    /**
     * Constructs an expert machine profile.
     */
    public ExpertMachine() {
        super("expert");
    }

    /**
     * Evaluates all options and returns optimal move balancing risks and rewards.
     * @param player The player controlled by this machine.
     * @param level The current game level.
     * @return Optimal direction to move.
     */
    @Override
    public Direction getNextMove(Player player, Level level) {
        Position playerPos = player.getPosition();
        String posKey = playerPos.getX() + "," + playerPos.getY();

        // agregar posición actual al historial
        recentPositions.add(posKey);
        if (recentPositions.size() > POSITION_HISTORY_SIZE) {
            recentPositions.remove(0);
        }

        // detectar si está atascado
        if (lastPosition != null && lastPosition.equals(playerPos)) {
            stuckCounter++;
        } else {
            stuckCounter = 0;
            shouldBreakIce = false;
        }

        // detectar loop (oscilando entre 2 posiciones)
        boolean inLoop = detectLoop();

        lastPosition = new Position(playerPos.getX(), playerPos.getY());

        // si está muy atascado o en loop, verificar si debe romper hielo
        if (stuckCounter > 3 || inLoop) {
            // verificar si está rodeado de hielo
            if (isSurroundedByIce(playerPos, level.getMap())) {
                shouldBreakIce = true;
                // elegir dirección con hielo para romper
                Direction iceDir = getDirectionWithIce(playerPos, level.getMap());
                if (iceDir != null) {
                    lastDirection = iceDir;
                    return iceDir;
                }
            }

            stuckCounter = 0;
            recentPositions.clear();
            return getEscapeDirection(playerPos, level.getMap(), lastDirection);
        }

        Direction[] directions = {Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT};

        Direction bestDir = null;
        double bestScore = Double.NEGATIVE_INFINITY;

        for (Direction dir : directions) {
            Position nextPos = playerPos.getNextPosition(dir);

            if (!level.getMap().isValidPosition(nextPos)) continue;
            Block block = level.getMap().getBlock(nextPos.getX(), nextPos.getY());
            if (block != null) continue;

            double score = evaluateMove(nextPos, level);

            // "penalizar" posiciones visitadas recientemente
            String nextKey = nextPos.getX() + "," + nextPos.getY();
            if (recentPositions.contains(nextKey)) {
                score -= 50;
            }

            if (stuckCounter > 2 && dir != lastDirection) {
                score += 30;
            }

            if (score > bestScore) {
                bestScore = score;
                bestDir = dir;
            }
        }

        if (bestDir != null) {
            lastDirection = bestDir;
            return bestDir;
        }

        return getRandomValidDirection(playerPos, level.getMap());
    }

    /**
     * Detects if the machine is stuck in a loop (oscillating between positions).
     * @return True if loop detected, false otherwise.
     */
    private boolean detectLoop() {
        if (recentPositions.size() < 4) return false;

        // verificar si está oscilando entre 2 posiciones (A->B->A->B), pasó mucho
        int size = recentPositions.size();
        String last = recentPositions.get(size - 1);
        String secondLast = recentPositions.get(size - 2);

        if (size >= 4) {
            String thirdLast = recentPositions.get(size - 3);
            String fourthLast = recentPositions.get(size - 4);

            if (last.equals(thirdLast) && secondLast.equals(fourthLast) && !last.equals(secondLast)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Checks if the position is surrounded by ice blocks in all valid directions.
     * @param pos Current position.
     * @param map Game map.
     * @return True if surrounded by ice, false otherwise.
     */
    private boolean isSurroundedByIce(Position pos, Map map) {
        Direction[] dirs = {Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT};
        int iceCount = 0;
        int validDirs = 0;

        for (Direction dir : dirs) {
            Position next = pos.getNextPosition(dir);
            if (map.isValidPosition(next)) {
                validDirs++;
                Block block = map.getBlock(next.getX(), next.getY());
                if (block != null && block.isIce()) {
                    iceCount++;
                }
            }
        }

        // está rodeado si al menos 3 de 4 direcciones tienen hielo
        return iceCount >= 3 && validDirs >= 3;
    }

    /**
     * Gets a direction that has an ice block, prioritizing direction towards nearest fruit.
     * @param pos Current position.
     * @param map Game map.
     * @return Direction with ice block, or null if none.
     */
    private Direction getDirectionWithIce(Position pos, Map map) {
        Direction[] dirs = {Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT};

        for (Direction dir : dirs) {
            Position next = pos.getNextPosition(dir);
            if (map.isValidPosition(next)) {
                Block block = map.getBlock(next.getX(), next.getY());
                if (block != null && block.isIce()) {
                    return dir;
                }
            }
        }

        return null;
    }

    /**
     * Gets a direction to escape from stuck situation, trying all options systematically.
     * @param pos Current position.
     * @param map Game map.
     * @param lastDir Last direction attempted.
     * @return Direction to escape.
     */
    private Direction getEscapeDirection(Position pos, Map map, Direction lastDir) {
        // intentar cualquier dirección válida que no sea la última usada
        Direction[] allDirs = {Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT};
        List<Direction> validDirs = new ArrayList<>();

        for (Direction dir : allDirs) {
            if (dir != lastDir && canMove(pos, dir, map)) {
                validDirs.add(dir);
            }
        }

        // si no hay opciones sin la última dirección, intentar cualquiera
        if (validDirs.isEmpty()) {
            for (Direction dir : allDirs) {
                if (canMove(pos, dir, map)) {
                    validDirs.add(dir);
                }
            }
        }

        if (validDirs.isEmpty()) return Direction.RIGHT;

        // elegir dirección aleatoria de las válidas
        return validDirs.get((int)(Math.random() * validDirs.size()));
    }

    /**
     * Strategically creates or breaks ice for tactical advantage.
     * @param player The player controlled by this machine.
     * @param level The current game level.
     * @return True if action is strategically beneficial.
     */
    @Override
    public boolean shouldPerformAction(Player player, Level level) {
        // si detectamos que debe romper hielo porque está rodeado
        if (shouldBreakIce) {
            shouldBreakIce = false;
            return true;
        }

        Position next = player.getPosition().getNextPosition(player.getDirection());

        if (!level.getMap().isValidPosition(next)) return false;

        Block block = level.getMap().getBlock(next.getX(), next.getY());

        // romper hielo si bloquea camino optimo a fruta
        if (block != null && block.isIce()) {
            Fruit nearestFruit = findNearestFruit(player.getPosition(), level.getFruits());
            if (nearestFruit != null) {
                return isInDirection(player.getPosition(), nearestFruit.getPosition(), player.getDirection());
            }
            // si no hay fruta cerca, romper de todas formas si está atascado
            return stuckCounter > 2;
        }

        // crear hielo defensivo si enemigo esta cerca
        Enemy nearestEnemy = findNearestEnemy(player.getPosition(), level.getEnemies());
        if (nearestEnemy != null && block == null) {
            int distance = manhattanDistance(player.getPosition(), nearestEnemy.getPosition());
            if (distance <= DANGER_THRESHOLD) {
                int dx = nearestEnemy.getPosition().getX() - player.getPosition().getX();
                int dy = nearestEnemy.getPosition().getY() - player.getPosition().getY();

                Direction enemyDir;
                if (Math.abs(dx) > Math.abs(dy)) {
                    enemyDir = dx > 0 ? Direction.RIGHT : Direction.LEFT;
                } else {
                    enemyDir = dy > 0 ? Direction.DOWN : Direction.UP;
                }

                return player.getDirection() == enemyDir;
            }
        }

        return false;
    }

    /**
     * Evaluates a position using weighted factors: fruit proximity, enemy distance.
     * @param pos Position to evaluate.
     * @param level Current game level.
     * @return Score for the position (higher is better).
     */
    private double evaluateMove(Position pos, Level level) {
        double score = 0;

        // cercanía a frutas
        Fruit nearestFruit = findNearestFruit(pos, level.getFruits());
        if (nearestFruit != null) {
            int fruitDist = manhattanDistance(pos, nearestFruit.getPosition());
            score += 100.0 / (fruitDist + 1);
        }

        //  cercanía a enemigos
        Enemy nearestEnemy = findNearestEnemy(pos, level.getEnemies());
        if (nearestEnemy != null) {
            int enemyDist = manhattanDistance(pos, nearestEnemy.getPosition());
            if (enemyDist < DANGER_THRESHOLD) {
                score -= 200.0 / (enemyDist + 1);
            } else if (enemyDist < 5) {
                score -= 50.0 / (enemyDist + 1);
            }
        }

        return score;
    }

    /**
     * Finds the nearest uncollected fruit.
     * @param pos Current position.
     * @param fruits List of all fruits.
     * @return Nearest fruit or null.
     */
    private Fruit findNearestFruit(Position pos, List<Fruit> fruits) {
        Fruit nearest = null;
        int minDistance = Integer.MAX_VALUE;

        for (Fruit f : fruits) {
            if (!f.isCollected()) {
                int distance = manhattanDistance(pos, f.getPosition());
                if (distance < minDistance) {
                    minDistance = distance;
                    nearest = f;
                }
            }
        }

        return nearest;
    }

    /**
     * Finds the nearest enemy.
     * @param pos Current position.
     * @param enemies List of enemies.
     * @return Nearest enemy or null.
     */
    private Enemy findNearestEnemy(Position pos, List<Enemy> enemies) {
        Enemy nearest = null;
        int minDistance = Integer.MAX_VALUE;

        for (Enemy e : enemies) {
            int distance = manhattanDistance(pos, e.getPosition());
            if (distance < minDistance) {
                minDistance = distance;
                nearest = e;
            }
        }

        return nearest;
    }

    /**
     * Calculates Manhattan distance.
     * @param a First position.
     * @param b Second position.
     * @return Manhattan distance.
     */
    private int manhattanDistance(Position a, Position b) {
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY());
    }

    /**
     * Checks if can move in direction.
     * @param pos Current position.
     * @param dir Direction.
     * @param map Game map.
     * @return True if valid move.
     */
    private boolean canMove(Position pos, Direction dir, Map map) {
        Position next = pos.getNextPosition(dir);
        if (!map.isValidPosition(next)) return false;
        Block block = map.getBlock(next.getX(), next.getY());
        return block == null;
    }

    /**
     * Checks if target is in direction.
     * @param from Current position.
     * @param to Target position.
     * @param dir Direction.
     * @return True if target is in that direction.
     */
    private boolean isInDirection(Position from, Position to, Direction dir) {
        int dx = to.getX() - from.getX();
        int dy = to.getY() - from.getY();

        switch (dir) {
            case UP: return dy < 0;
            case DOWN: return dy > 0;
            case LEFT: return dx < 0;
            case RIGHT: return dx > 0;
            default: return false;
        }
    }

    /**
     * Returns a random valid direction.
     * @param pos Current position.
     * @param map Game map.
     * @return Random valid direction.
     */
    private Direction getRandomValidDirection(Position pos, Map map) {
        Direction[] dirs = {Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT};
        List<Direction> validDirs = new ArrayList<>();

        for (Direction dir : dirs) {
            if (canMove(pos, dir, map)) {
                validDirs.add(dir);
            }
        }

        if (validDirs.isEmpty()) return Direction.RIGHT;

        return validDirs.get((int)(Math.random() * validDirs.size()));
    }
}
