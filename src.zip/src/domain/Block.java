package domain;


/**
 * Abstract base class for grid blocks (wall, ice).
 * Manages shared attributes and methods.
 * Laura Castillo,Mariana Malagon
 * PROYECTO FINAL DOPO
 */

public abstract class Block {
    protected Position position;
    protected boolean breakable;

    /**
     * Constructs a Block at the specified position.
     * @param position the grid coordinates.
     * @param breakable whether the block can be broken.
     */
    public Block(Position position, boolean breakable) {
        this.position = position;
        this.breakable = breakable;
    }

    /**
     * Gets the block's position in the grid.
     * @return the Position of the block.
     */
    public Position getPosition() {
        return position;
    }

    /**
     * Indicates whether this block can be broken.
     * @return true if breakable, false otherwise.
     */
    public boolean isBreakable() {
        return breakable;
    }

    /**
     * Indicates whether this block is an ice block.
     * Default implementation returns false and is overridden by IceBlock.
     * @return true if the block is ice, false otherwise.
     */
    public boolean isIce() {
        return false;
    }

    /**
     * Indicates whether this block is a campfire.
     * @return False by default, override in Fogata class.
     */
    public boolean isFogata() {
        return false;
    }

    /**
     * Indicates whether this block is a hot tile.
     * @return False by default, override in BaldosaCaliente class.
     */
    public boolean isBaldosaCaliente() {
        return false;
    }


    /**
     * Returns the file path for the block image.
     * @return String image path.
     */
    public abstract String getImagePath();

    /**
     * Performs any behavior needed when the block is broken.
     */
    public abstract void onBreak();
}
