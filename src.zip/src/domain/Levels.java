package domain;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Level loader utility class that loads all game levels from text files.
 * Provides methods to load complete levels including map layout, fruits, enemies, and obstacles.
 * Replaces hardcoded Level1, Level2, Level3 classes with file-based level loading.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Levels {
    /**
     * Loads a complete level with all its components.
     * Reads map layout from text file, then adds fruits, enemies, and obstacles.
     * @param levelNumber Level number to load (1, 2, 3, etc.).
     * @return Complete Level instance with map, fruits, enemies, and obstacles.
     * @throws RuntimeException If the level file cannot be loaded.
     */
   public static Level load(int levelNumber) {

        int[][] matrix = loadLevelMatrix(levelNumber);
        if (matrix == null) {
            throw new RuntimeException("No se pudo cargar el archivo del nivel " + levelNumber);
        }

        Map map = buildMap(matrix);

        loadObstacles(levelNumber, map);

        List<Fruit> fruits = loadFruits(levelNumber);
        List<Enemy> enemies = loadEnemies(levelNumber);

        return new Level(levelNumber, map, fruits, enemies);
    }
    /**
     * Loads the level matrix from a text file.
     * Reads from "src/levels/levelN.txt" where N is the level number.
     * File format: space-separated integers, where 1 = ice block, 0 = empty space.
     * @param levelNumber Level number to load.
     * @return 2D integer matrix representing the level layout, or null if file not found.
     */
    private static int[][] loadLevelMatrix(int levelNumber) {
        String path = "src/levels/level" + levelNumber + ".txt";
        List<int[]> rows = new ArrayList<>();

        try {
            List<String> lines = Files.readAllLines(Paths.get(path));

            for (String line : lines) {
                if (line.trim().isEmpty()) continue;

                String[] parts = line.trim().split("\\s+");
                int[] row = new int[parts.length];
                for (int i = 0; i < parts.length; i++) {
                    row[i] = Integer.parseInt(parts[i]);
                }
                rows.add(row);
            }

            int[][] matrix = new int[rows.size()][rows.get(0).length];
            for (int i = 0; i < rows.size(); i++)
                matrix[i] = rows.get(i);

            return matrix;

        } catch (IOException e) {
            return null;
        }
    }
    /**
     * Loads the level matrix from a text file.
     * Reads from "src/levels/levelN.txt" where N is the level number.
     * File format: space-separated integers, where 1 = ice block, 0 = empty space.
     * @param levelNumber Level number to load.
     * @return 2D integer matrix representing the level layout, or null if file not found.
     */
    private static Map buildMap(int[][] matrix) {
        int height = matrix.length;
        int width  = matrix[0].length;

        Map map = new Map(width, height);

        try {
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    if (matrix[y][x] == 1) {
                        map.setBlock(x, y, new IceBlock(new Position(x, y)));
                    }
                }
            }
        } catch (BadIceCreamException ignored) {}

        return map;
    }
    /**
     * Loads all fruits for a specific level.
     * Level 1: 8 Bananas + 8 Grapes
     * Level 2: 8 Bananas + 8 Pineapples
     * Level 3: 8 Cherries + 8 Cactus
     * @param levelNumber Level number (1, 2, or 3).
     * @return List of Fruit instances placed at predefined positions.
     */
    private static List<Fruit> loadFruits(int levelNumber) {
        List<Fruit> f = new ArrayList<>();

        switch (levelNumber) {

            case 1:
                f.add(new Banana(new Position(5, 6)));
                f.add(new Banana(new Position(5, 1)));
                f.add(new Banana(new Position(9, 1)));
                f.add(new Banana(new Position(9, 6)));
                f.add(new Banana(new Position(2, 11)));
                f.add(new Banana(new Position(5, 8)));
                f.add(new Banana(new Position(9, 8)));
                f.add(new Banana(new Position(12, 11)));

                f.add(new Grape(new Position(2, 5)));
                f.add(new Grape(new Position(1, 7)));
                f.add(new Grape(new Position(2, 9)));
                f.add(new Grape(new Position(12, 5)));
                f.add(new Grape(new Position(13, 7)));
                f.add(new Grape(new Position(12, 9)));
                f.add(new Grape(new Position(4, 7)));
                f.add(new Grape(new Position(10, 7)));
                break;

            case 2:
                f.add(new Banana(new Position(1, 1)));
                f.add(new Banana(new Position(13, 1)));
                f.add(new Banana(new Position(1, 12)));
                f.add(new Banana(new Position(13, 12)));
                f.add(new Banana(new Position(0, 6)));
                f.add(new Banana(new Position(13, 6)));
                f.add(new Banana(new Position(7, 1)));
                f.add(new Banana(new Position(7, 12)));

                f.add(new Pineapple(new Position(4, 4)));
                f.add(new Pineapple(new Position(10, 4)));
                f.add(new Pineapple(new Position(4, 9)));
                f.add(new Pineapple(new Position(10, 9)));
                f.add(new Pineapple(new Position(5, 6)));
                f.add(new Pineapple(new Position(9, 6)));
                f.add(new Pineapple(new Position(5, 7)));
                f.add(new Pineapple(new Position(9, 7)));
                break;


            case 3:
                f.add(new Cherry(new Position(2, 2)));
                f.add(new Cherry(new Position(12, 2)));
                f.add(new Cherry(new Position(2, 11)));
                f.add(new Cherry(new Position(12, 11)));
                f.add(new Cherry(new Position(0, 5)));
                f.add(new Cherry(new Position(14, 5)));
                f.add(new Cherry(new Position(0, 9)));
                f.add(new Cherry(new Position(14, 9)));

                f.add(new Cactus(new Position(4, 3)));
                f.add(new Cactus(new Position(10, 3)));
                f.add(new Cactus(new Position(4, 6)));
                f.add(new Cactus(new Position(10, 6)));
                f.add(new Cactus(new Position(4, 10)));
                f.add(new Cactus(new Position(10, 10)));
                f.add(new Cactus(new Position(6, 11)));
                f.add(new Cactus(new Position(8, 11)));
                break;
        }

        return f;
    }
    /**
     * Loads all enemies for a specific level.
     * Level 1: 2 Trolls (patrol-type enemies)
     * Level 2: 2 Macetas (plant enemies)
     * Level 3: 1 Calamar (squid) + 1 Narval (narwhal)
     * @param levelNumber Level number (1, 2, or 3).
     * @return List of Enemy instances placed at predefined positions.
     */
    private static List<Enemy> loadEnemies(int levelNumber) {
        List<Enemy> e = new ArrayList<>();

        switch (levelNumber) {
            case 1:
                e.add(new Troll(new Position(1, 1), 5));
                e.add(new Troll(new Position(4, 5), 5));
                break;

            case 2:
                e.add(new Maceta(new Position(7, 3)));
                e.add(new Maceta(new Position(4, 10)));
                break;

            case 3:
                e.add(new Calamar(new Position(7, 2)));   // Calamar
                e.add(new Narval(new Position(7, 11)));   // Narval
                break;
        }
        return e;
    }
    /**
     * Loads and places obstacles (campfires and hot tiles) for a specific level.
     * Level 1: No obstacles
     * Level 2: 1 Fogata (campfire) at (1,7)
     * Level 3: 1 Baldosa Caliente (hot tile) at (10,8)
     * @param levelNumber Level number (1, 2, or 3).
     * @param map Map instance to add obstacles to.
     */
   private static void loadObstacles(int levelNumber, Map map) {

        try {

            switch (levelNumber) {

                case 2:
                    // Fogata en nivel 2
                    map.addFogata(new Position(1, 7));
                    break;

                case 3:
                    // Baldosa caliente en nivel 3
                    map.addBaldosaCaliente(new Position(10, 8));
                    break;
            }

        } catch (BadIceCreamException ignored) {}
    }
    /**
     * Returns the starting position for player 1 in a given level.
     * @param levelNumber Level number (1, 2, or 3).
     * @return Position object representing player 1's starting coordinates.
     */
    public static Position getPlayer1Start(int levelNumber) {
        switch (levelNumber) {
            case 1: return new Position(2, 2);
            case 2: return new Position(1, 1);
            case 3: return new Position(2, 1);
            default: return new Position(1, 1);
        }
    }
    /**
     * Returns the starting position for player 2 in a given level.
     * @param levelNumber Level number (1, 2, or 3).
     * @return Position object representing player 2's starting coordinates.
     */
    public static Position getPlayer2Start(int levelNumber) {
        switch (levelNumber) {
            case 1: return new Position(8, 12);
            case 2: return new Position(12, 12);
            case 3: return new Position(12, 12);
            default: return new Position(12, 12);
        }
    }
}
