package domain;

/**
 * Simple configuration object for a level.
 * Stores how many fruits, enemies and obstacles should appear.
 * Used by the GUI to customize default levels.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class LevelConfig {

    // fruits
    public int bananas;
    public int grapes;
    public int cherries;
    public int pineapples;
    public int cactus;

    // enemies
    public int trolls;
    public int calamares;
    public int macetas;
    public int narvales;

    // obstacles
    public int fogatas;
    public int baldosasCalientes;

    /**
     * Creates an empty configuration (all zeros).
     */
    public LevelConfig() {
    }

    /**
     * Always returns true so the configuration is always applied.
     * The number of elements created depends on each field value.
     * @return true.
     */
    public boolean hasCustomValues() {
        return true;
    }
}
