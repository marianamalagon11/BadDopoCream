package domain;

/**
 * Abstract base class for all enemy types.
 * Laura Castillo,Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public abstract class Enemy {

    protected Position position;
    protected Direction direction;
    protected boolean canBreakIce;
    protected int speedTicks;
    protected int tickCounter;

    /**
     * Constructs the Enemy.
     * @param position Initial position.
     * @param canBreakIce True if can break ice blocks.
     * @param speedTicks Number of update ticks between move steps.
     */
    public Enemy(Position position, boolean canBreakIce, int speedTicks) {
        this.position = position;
        this.canBreakIce = canBreakIce;
        this.direction = Direction.RIGHT;
        this.speedTicks = speedTicks;
        this.tickCounter = 0;
    }

    /**
     * Attempts to move the enemy. Only moves every speedTicks updates.
     */
    public void move() {
        tickCounter++;
        if (tickCounter < speedTicks) {
            return;
        }
        tickCounter = 0;
        moveEnemy();
    }

    /**
     * Abstract movement behavior for each enemy type.
     */
    protected abstract void moveEnemy();

    /**
     * Updates the enemy behavior with access to players and map.
     * New enemies (Maceta, Calamar, Narval) override this method.
     * @param players Array of players in the game.
     * @param map Game map for pathfinding and collision.
     */
    public void update(Player[] players, Map map) {
        move();
    }

    /**
     * Gets grid position.
     * @return Position instance.
     */
    public Position getPosition() {
        return position;
    }

    /**
     * Gets current direction.
     * @return Direction enum.
     */
    public Direction getDirection() {
        return direction;
    }

    /**
     * Sets the direction for the enemy.
     * @param direction New direction.
     */
    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    /**
     * Checks if can break ice.
     * @return True if can break ice.
     */
    public boolean canBreakIce() {
        return canBreakIce;
    }

    /**
     * Sets grid position.
     * @param position New position.
     */
    public void setPosition(Position position) {
        this.position = position;
    }

    /**
     * Gets sprite path.
     * @return Path to image.
     */
    public abstract String getImagePath();

    /**
     * Indicates whether this enemy is a Maceta.
     * @return false by default, override in Maceta class.
     */
    public boolean isMaceta() {
        return false;
    }

    /**
     * Indicates whether this enemy is a Calamar.
     * @return false by default, override in Calamar class.
     */
    public boolean isCalamar() {
        return false;
    }

    /**
     * Indicates whether this enemy is a Narval.
     * @return false by default, override in Narval class.
     */
    public boolean isNarval() {
        return false;
    }
}
