package domain;

import java.util.Random;

/**
 * Pineapple fruit that moves randomly when a player moves.
 * Worth 200 points when collected.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class Pineapple extends Fruit {

    private Random random;
    private int moveCounter;
    private static final int MOVES_PER_PLAYER_MOVE = 1; // las veces se mueve por cada movimiento del jugador

    /**
     * Constructs a Pineapple at the given position.
     * @param position Initial position of the pineapple.
     */
    public Pineapple(Position position) {
        super(position, 200);
        this.random = new Random();
        this.moveCounter = 0;
    }

    /**
     * Returns the image path for pineapple.
     * @return path to pineapple image file.
     */
    @Override
    public String getImagePath() {
        return "resources/pineapple.gif";
    }

    /**
     * Updates the pineapple (movement is handled externally).
     */
    @Override
    public void update() {
        // La lógica de movimiento se maneja externamente llamando a moveRandomly()
    }

    /**
     * Moves the pineapple in a random direction when player moves.
     * @param map The game map to check valid positions.
     * @throws BadIceCreamException If movement is invalid.
     */
    public void moveRandomly(Map map) throws BadIceCreamException {
        if (isCollected()) {
            return;
        }

        // Obtener todas las direcciones posibles
        Direction[] directions = {Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT};

        // Mezclar las direcciones para intentarlas en orden aleatorio
        shuffleArray(directions);

        // Intentar moverse en cada dirección hasta encontrar una válida
        for (Direction dir : directions) {
            Position nextPosition = position.getNextPosition(dir);

            if (map.isValidPosition(nextPosition)) {
                Block block = map.getBlock(nextPosition.getX(), nextPosition.getY());
                if (block == null && !isIgluPosition(nextPosition)) {
                    this.position = nextPosition;
                    return; // Se movió exitosamente
                }
            }
        }

        // Si no pudo moverse en ninguna dirección, se queda donde está
    }

    /**
     * Alternative method: moves randomly but only sometimes (50% chance).
     * @param map The game map to check valid positions.
     * @throws BadIceCreamException If movement is invalid.
     */
    public void moveRandomlySometimes(Map map) throws BadIceCreamException {
        if (isCollected()) {
            return;
        }

        // 50% de probabilidad de moverse
        if (random.nextBoolean()) {
            moveRandomly(map);
        }
    }

    /**
     * Shuffles an array of directions randomly.
     * @param array Array to shuffle.
     */
    private void shuffleArray(Direction[] array) {
        for (int i = array.length - 1; i > 0; i--) {
            int index = random.nextInt(i + 1);
            Direction temp = array[index];
            array[index] = array[i];
            array[i] = temp;
        }
    }

    /**
     * Checks if position is inside the igloo area.
     * @param pos Position to check.
     * @return True if inside igloo.
     */
    private boolean isIgluPosition(Position pos) {
        int dx = Math.abs(pos.getX() - 7);
        int dy = Math.abs(pos.getY() - 7);
        return dx <= 1 && dy <= 1;
    }

    /**
     * Indicates that this fruit is a pineapple.
     * @return always true for Pineapple instances.
     */
    @Override
    public boolean isPineapple() {
        return true;
    }
}
