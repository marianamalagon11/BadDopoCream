package domain;

/**
 * Hot tile that melts ice blocks placed on it instantly.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class BaldosaCaliente extends Block {

    /**
     * Constructs a BaldosaCaliente at the specified position.
     * @param position Grid coordinates of the hot tile.
     */
    public BaldosaCaliente(Position position) {
        super(position, false); // No es rompible
    }

    /**
     * Checks if this hot tile would melt ice at the given position.
     * @param icePosition Position to check.
     * @return True if positions match.
     */
    public boolean meltsIceAt(Position icePosition) {
        return this.position.equals(icePosition);
    }

    /**
     * Returns the image path for hot tile.
     * @return Path to hot tile sprite.
     */
    @Override
    public String getImagePath() {
        return "resources/baldosaCaliente.png";
    }

    /**
     * No special behavior when "broken" (can't be broken).
     */
    @Override
    public void onBreak() {
        // Las baldosas calientes no se rompen
    }

    /**
     * Indicates this is not an ice block.
     * @return False.
     */
    @Override
    public boolean isIce() {
        return false;
    }

    /**
     * Indicates this is a hot tile.
     * @return True.
     */
    public boolean isBaldosaCaliente() {
        return true;
    }
}
