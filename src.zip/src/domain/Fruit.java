package domain;

/**
 * Abstract class for collectible fruits in the game.
 * Points and basic logic are shared.
 * Laura Castillo,Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public abstract class Fruit {
    protected Position position;
    protected boolean collected;
    protected int points;

    /**
     * Constructs a Fruit at a position worth a certain point value.
     * @param position where the fruit is located.
     * @param points   the value earned when collected.
     */
    public Fruit(Position position, int points) {
        this.position = position;
        this.points = points;
        this.collected = false;
    }

    /**
     * Gets the fruit's grid position.
     * @return Position object.
     */
    public Position getPosition() {
        return position;
    }

    /**
     * Returns true if this fruit has already been collected.
     * @return boolean indicating collection status.
     */
    public boolean isCollected() {
        return collected;
    }

    /**
     * Returns the score value of the fruit.
     * @return integer points earned.
     */
    public int getPoints() {
        return points;
    }

    /**
     * Flags the fruit as collected.
     */
    public void collect() {
        this.collected = true;
    }

    /**
     * Indicates whether this fruit is a banana.
     * Default implementation returns false and is overridden by Banana.
     * @return true if this fruit is a banana, false otherwise.
     */
    public boolean isBanana() {
        return false;
    }

    /**
     * Indicates whether this fruit is a grape.
     * Default implementation returns false and is overridden by Grape.
     * @return true if this fruit is a grape, false otherwise.
     */
    public boolean isGrape() {
        return false;
    }

    /**
     * Returns the file path for the fruit sprite.
     * @return String path to fruit image.
     */
    public abstract String getImagePath();

    /**
     * Updates the fruit (e.g., for motion/behavior).
     */
    public abstract void update();

    /**
     * Indicates whether this fruit is a cherry.
     * Default implementation returns false and is overridden by Cherry.
     * @return true if this fruit is a cherry, false otherwise.
     */
    public boolean isCherry() {
        return false;
    }

    /**
     * Indicates whether this fruit is a pineapple.
     * Default implementation returns false and is overridden by Pineapple.
     * @return true if this fruit is a pineapple, false otherwise.
     */
    public boolean isPineapple() {
        return false;
    }

    /**
     * Indicates whether this fruit is a cactus.
     * Default implementation returns false and is overridden by Cactus.
     * @return true if this fruit is a cactus, false otherwise.
     */
    public boolean isCactus() {
        return false;
    }

}

