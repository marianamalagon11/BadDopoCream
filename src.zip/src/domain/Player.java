package domain;

/**
 * Base abstract class for an ice cream player character in the game grid.
 * Stores position, direction, lives, flavor, state and whether it is human or AI.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public abstract class Player {

    protected Position position;
    protected Direction direction;
    protected int lives;
    protected int speed;
    protected String flavor;
    protected PlayerState state;
    protected boolean isMachine;
    protected Machine machineProfile;
    protected String name;

    /**
     * Creates a player at a given position with a given flavor and control type.
     * @param position initial grid position
     * @param flavor   ice cream flavor ("vanilla", "strawberry", "chocolate")
     * @param isMachine true if controlled by AI, false if human
     */
    public Player(Position position, String flavor, boolean isMachine) {
        this.position = position;
        this.flavor = flavor;
        this.direction = Direction.DOWN;
        this.lives = 3;
        this.speed = 1;
        this.state = PlayerState.NORMAL;
        this.isMachine = isMachine;
        this.machineProfile = null;
        this.name = "Player"; // Valor por defecto
    }

    /**
     * Sets the player's name.
     * @param name the name chosen by the user
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the player's name.
     * @return the player's name
     */
    public String getName() {
        return name;
    }


    /**
     * @return current position on the grid
     */
    public Position getPosition() {
        return position;
    }

    /**
     * @return current movement direction
     */
    public Direction getDirection() {
        return direction;
    }

    /**
     * @return remaining lives
     */
    public int getLives() {
        return lives;
    }

    /**
     * @return flavor string of this player
     */
    public String getFlavor() {
        return flavor;
    }

    /**
     * @return true if this player is AI-controlled
     */
    public boolean isMachine() {
        return isMachine;
    }

    /**
     * @return current state (NORMAL, BLOWING, ANGRY, DEAD, etc.)
     */
    public PlayerState getState() {
        return state;
    }

    /**
     * Sets the current state of the player.
     * @param state new state to set
     */
    public void setState(PlayerState state) {
        this.state = state;
    }

    /**
     * Sets the facing direction without moving.
     * @param direction new direction
     */
    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    /**
     * Moves the player one cell in the given direction.
     * @param direction direction to move
     * @throws BadIceCreamException if the move is not allowed by Position
     */
    public void move(Direction direction) throws BadIceCreamException {
        this.direction = direction;
        position.move(direction);
    }

    /**
     * Reduces lives by one and sets state to DEAD if lives reach zero.
     */
    public void loseLife() {
        lives--;
        if (lives <= 0) {
            state = PlayerState.DEAD;
        }
    }

    /**
     * @return true if lives > 0
     */
    public boolean isAlive() {
        return lives > 0;
    }

    /**
     * Sets the machine profile for AI-controlled players.
     * @param profile Machine profile instance.
     */
    public void setMachineProfile(Machine profile) {
        this.machineProfile = profile;
    }

    /**
     * Gets the machine profile.
     * @return Machine profile or null if human player.
     */
    public Machine getMachineProfile() {
        return machineProfile;
    }

    /**
     * @return path to the current sprite image for this player
     */
    public abstract String getImagePath();

    /**
     * Sets the player's position directly.
     * @param position new position
     */
    public void setPosition(Position position) {
        this.position = position;
    }
}
