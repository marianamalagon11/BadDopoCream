package presentation;

import javax.swing.*;
import java.awt.*;

/**
 * Panel that shows the visual configuration for a selected level.
 * Displays the default map title image, a level description image
 * (one per level) and buttons to play or open the advanced map editor.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class LevelConfigPanel extends JPanel {

    private BadIceCreamGUI parent;
    private int levelNumber;

    /**
     * Builds the level configuration panel for the given level.
     * @param parent      Reference to the main game window.
     * @param levelNumber Selected level number (1, 2 or 3).
     */
    public LevelConfigPanel(BadIceCreamGUI parent, int levelNumber) {
        this.parent = parent;
        this.levelNumber = levelNumber;

        setLayout(null);
        setPreferredSize(new Dimension(640, 640));
        ImageIcon bgIcon = new ImageIcon("resources/fondo.gif");
        Image bgImage = bgIcon.getImage().getScaledInstance(640, 640, Image.SCALE_DEFAULT);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setLayout(null);
        backgroundLabel.setBounds(0, 0, 640, 640);
        add(backgroundLabel);

        // titulo con defaultMap.png
        ImageIcon defaultMapIcon = new ImageIcon("resources/defaultMap.png");
        Image defaultMapImg = defaultMapIcon.getImage().getScaledInstance(420, 80, Image.SCALE_SMOOTH);
        JLabel defaultMapLabel = new JLabel(new ImageIcon(defaultMapImg));
        defaultMapLabel.setBounds((640 - 420) / 2, 40, 420, 80);
        backgroundLabel.add(defaultMapLabel);

        // panel central con la descripcion del nivel: levelXConfiguration.png
        ImageIcon cuadroIcon = new ImageIcon("resources/boton3.png");
        Image cuadroImg = cuadroIcon.getImage().getScaledInstance(560, 320, Image.SCALE_SMOOTH);
        JLabel centerPanel = new JLabel(new ImageIcon(cuadroImg));
        centerPanel.setLayout(null);
        centerPanel.setBounds(40, 130, 560, 320);
        backgroundLabel.add(centerPanel);

        // imagen de configuracion segun el nivel
        String levelConfigPath;
        if (levelNumber == 1) {
            levelConfigPath = "resources/level1Configuration.png";
        } else if (levelNumber == 2) {
            levelConfigPath = "resources/level2Configuration.png";
        } else {
            levelConfigPath = "resources/level3Configuration.png";
        }

        ImageIcon levelCfgIcon = new ImageIcon(levelConfigPath);
        Image levelCfgImg = levelCfgIcon.getImage().getScaledInstance(520, 260, Image.SCALE_SMOOTH);
        JLabel levelCfgLabel = new JLabel(new ImageIcon(levelCfgImg));
        levelCfgLabel.setBounds(20, 30, 520, 260);
        centerPanel.add(levelCfgLabel);

        // boton play (boton2.png) para seguir con esa configuracion
        ImageIcon playIcon = new ImageIcon("resources/boton2.png");
        Image playImg = playIcon.getImage().getScaledInstance(200, 80, Image.SCALE_SMOOTH);
        JButton playButton = new JButton(new ImageIcon(playImg));
        playButton.setBorderPainted(false);
        playButton.setContentAreaFilled(false);
        playButton.setFocusPainted(false);
        playButton.setBounds(80, 470, 200, 80);
        playButton.addActionListener(e -> {
            // seguir con el flujo normal: escoger modo de juego
            parent.showGameModeSelection(parent.getNumberOfPlayers());
        });
        backgroundLabel.add(playButton);

        // boton changeMap.png para ir al panel de edicion avanzada
        ImageIcon changeMapIcon = new ImageIcon("resources/changeMap.png");
        Image changeMapImg = changeMapIcon.getImage().getScaledInstance(220, 80, Image.SCALE_SMOOTH);
        JButton changeMapButton = new JButton(new ImageIcon(changeMapImg));
        changeMapButton.setBorderPainted(false);
        changeMapButton.setContentAreaFilled(false);
        changeMapButton.setFocusPainted(false);
        changeMapButton.setBounds(340, 470, 220, 80);
        changeMapButton.addActionListener(e -> {
            // abrir el panel donde se escogen frutas, enemigos y obstaculos
            parent.showChangeMapConfig(levelNumber);
        });
        backgroundLabel.add(changeMapButton);

        // boton back para volver a la seleccion de nivel
        ImageIcon backIcon = new ImageIcon("resources/back.png");
        Image backImg = backIcon.getImage().getScaledInstance(80, 40, Image.SCALE_SMOOTH);
        JButton backButton = new JButton(new ImageIcon(backImg));
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setFocusPainted(false);
        backButton.setBounds(20, 20, 80, 40);
        backButton.addActionListener(e -> parent.showLevelSelection(parent.getNumberOfPlayers()));
        backgroundLabel.add(backButton);
    }
}
