package presentation;

import domain.LevelConfig;
import javax.swing.*;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Clean configuration panel: only fondoConfiguration.png, icons, text fields and buttons.
 * Lets user pick how many of each fruit, enemy and obstacle per level visually.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class ChangeMapPanel extends JPanel {

    private static final int MAX_FRUITS = 10;
    private static final int MAX_ENEMIES = 8;
    private static final int MAX_OBSTACLES = 6;

    private BadIceCreamGUI parent;
    private int levelNumber;
    private Map<String, JTextField> fruitFields;
    private Map<String, JTextField> enemyFields;
    private Map<String, JTextField> obstacleFields;

    /**
     * builds the visual config screen for one level.
     * here we layout the background, sections, icons, textfields and buttons.
     */
    public ChangeMapPanel(BadIceCreamGUI parent, int levelNumber) {
        this.parent = parent;
        this.levelNumber = levelNumber;

        fruitFields = new LinkedHashMap<>();
        enemyFields = new LinkedHashMap<>();
        obstacleFields = new LinkedHashMap<>();

        Map<String, Integer> defaultValues = getDefaultLevelValues(levelNumber);

        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(640, 640));

        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(640, 640));

        ImageIcon bgIcon = new ImageIcon("resources/fondoConfiguration.png");
        Image bgImage = bgIcon.getImage().getScaledInstance(640, 640, Image.SCALE_SMOOTH);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setBounds(0, 0, 640, 640);
        layeredPane.add(backgroundLabel, JLayeredPane.DEFAULT_LAYER);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(null);
        contentPanel.setBounds(0, 0, 640, 640);
        contentPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("Level " + levelNumber + " configuration", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 27));
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setBounds(0, 20, 640, 36);
        contentPanel.add(titleLabel);

        int iconSize = 56;
        int startX = 60, stepX = 110;
        int ySection = 80, yIcons = 112;
        contentPanel.add(createSectionLabel("Fruits (MAX 10)", 30, ySection));
        addIconWithField(contentPanel, "Cactus", "resources/cactus.png", startX + 0 * stepX, yIcons, fruitFields, iconSize, false, defaultValues.get("Cactus"));
        addIconWithField(contentPanel, "Cherry", "resources/cherry.png", startX + 1 * stepX, yIcons, fruitFields, iconSize, false, defaultValues.get("Cherry"));
        addIconWithField(contentPanel, "Banana", "resources/banana.png", startX + 2 * stepX, yIcons, fruitFields, iconSize, false, defaultValues.get("Banana"));
        addIconWithField(contentPanel, "Grape", "resources/grapes.png", startX + 3 * stepX, yIcons, fruitFields, iconSize, false, defaultValues.get("Grape"));
        addIconWithField(contentPanel, "Pineapple", "resources/pineapple.png", startX + 4 * stepX - 6, yIcons, fruitFields, iconSize, false, defaultValues.get("Pineapple"));

        ySection = 208; yIcons = 242;
        contentPanel.add(createSectionLabel("Enemies (MAX 8)", 30, ySection));
        addIconWithField(contentPanel, "Troll", "resources/troll.png", startX + 0 * stepX, yIcons, enemyFields, iconSize, false, defaultValues.get("Troll"));
        addIconWithField(contentPanel, "Calamar", "resources/calamar.png", startX + 1 * stepX, yIcons, enemyFields, iconSize, false, defaultValues.get("Calamar"));
        addIconWithField(contentPanel, "Maceta", "resources/maceta.png", startX + 2 * stepX, yIcons, enemyFields, iconSize, false, defaultValues.get("Maceta"));
        addIconWithField(contentPanel, "Narval", "resources/narval.png", startX + 3 * stepX, yIcons, enemyFields, iconSize, false, defaultValues.get("Narval"));

        ySection = 340; yIcons = 372;
        contentPanel.add(createSectionLabel("Obstacles (MAX 6)", 30, ySection));
        addIconWithField(contentPanel, "Fogata", "resources/fogata.png", startX + 0 * stepX + 42, yIcons, obstacleFields, 56, false, defaultValues.get("Fogata"));
        addIconWithField(contentPanel, "Baldosa", "resources/baldosaCaliente.png", startX + 2 * stepX - 30, yIcons, obstacleFields, 90, true, defaultValues.get("Baldosa"));

        ImageIcon saveIcon = new ImageIcon("resources/boton2.png");
        Image saveImg = saveIcon.getImage().getScaledInstance(170, 54, Image.SCALE_SMOOTH);
        JButton saveButton = new JButton(new ImageIcon(saveImg));
        saveButton.setBorderPainted(false);
        saveButton.setContentAreaFilled(false);
        saveButton.setFocusPainted(false);
        saveButton.setBounds(460, 510, 170, 54);
        saveButton.addActionListener(e -> onSaveAndContinue());
        contentPanel.add(saveButton);

        ImageIcon backIcon = new ImageIcon("resources/back.png");
        Image backImg = backIcon.getImage().getScaledInstance(60, 28, Image.SCALE_SMOOTH);
        JButton backButton = new JButton(new ImageIcon(backImg));
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setFocusPainted(false);
        backButton.setBounds(22, 24, 60, 28);
        backButton.addActionListener(e -> parent.showLevelConfig());
        contentPanel.add(backButton);

        layeredPane.add(contentPanel, JLayeredPane.PALETTE_LAYER);
        add(layeredPane, BorderLayout.CENTER);
    }

    /**
     * Loads the default level and counts all its elements.
     * Returns a map with the count of each type of fruit, enemy and obstacle.
     */
    private Map<String, Integer> getDefaultLevelValues(int levelNumber) {
        Map<String, Integer> values = new LinkedHashMap<>();

        try {
            // Cargar nivel por defecto
            domain.Level defaultLevel = domain.Levels.load(levelNumber);

            // Inicializar todos en 0
            values.put("Banana", 0);
            values.put("Grape", 0);
            values.put("Cherry", 0);
            values.put("Pineapple", 0);
            values.put("Cactus", 0);
            values.put("Troll", 0);
            values.put("Calamar", 0);
            values.put("Maceta", 0);
            values.put("Narval", 0);
            values.put("Fogata", 0);
            values.put("Baldosa", 0);

            // Contar frutas
            for (domain.Fruit fruit : defaultLevel.getFruits()) {
                if (fruit.isBanana()) {
                    values.put("Banana", values.get("Banana") + 1);
                } else if (fruit.isGrape()) {
                    values.put("Grape", values.get("Grape") + 1);
                } else if (fruit.isCherry()) {
                    values.put("Cherry", values.get("Cherry") + 1);
                } else if (fruit.isPineapple()) {
                    values.put("Pineapple", values.get("Pineapple") + 1);
                } else if (fruit.isCactus()) {
                    values.put("Cactus", values.get("Cactus") + 1);
                }
            }

            // Contar enemigos por tipo
            for (domain.Enemy enemy : defaultLevel.getEnemies()) {
                String enemyType = enemy.getClass().getSimpleName();

                if (enemyType.equals("Troll")) {
                    values.put("Troll", values.get("Troll") + 1);
                } else if (enemyType.equals("Calamar")) {
                    values.put("Calamar", values.get("Calamar") + 1);
                } else if (enemyType.equals("Maceta")) {
                    values.put("Maceta", values.get("Maceta") + 1);
                } else if (enemyType.equals("Narval")) {
                    values.put("Narval", values.get("Narval") + 1);
                }
            }

            // Contar obstáculos
            values.put("Fogata", defaultLevel.getMap().getFogatas().size());
            values.put("Baldosa", defaultLevel.getMap().getBaldosasCalientes().size());

        } catch (Exception e) {
            System.err.println("Error loading default level values: " + e.getMessage());
            // Si falla, devolver todo en 0 (ya inicializados)
        }

        return values;
    }

    /**
     * creates a simple text label used as section header
     * (fruits / enemies / obstacles) inside the config panel.
     */
    private JLabel createSectionLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 20));
        label.setForeground(Color.BLACK);
        label.setBounds(x, y, 280, 26);
        return label;
    }

    /**
     * adds one icon + numeric text field pair to the given panel.
     * also registers the text field in the target map under the given name,
     * so later we can read all the quantities by key.
     */
    private void addIconWithField(JPanel parentPanel, String name, String imagePath,
                                  int x, int y,
                                  Map<String, JTextField> targetMap,
                                  int customIconSize, boolean centerTextField,
                                  int defaultValue) {

        ImageIcon icon = new ImageIcon(imagePath);
        if (icon.getIconWidth() <= 0 || icon.getIconHeight() <= 0) {
            // fallback when the image is missing or cannot be loaded
            JPanel placeholder = new JPanel();
            placeholder.setBackground(Color.RED);
            placeholder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
            placeholder.setBounds(x, y, customIconSize, customIconSize);
            parentPanel.add(placeholder);

            JLabel nameLabel = new JLabel(name.substring(0, Math.min(3, name.length())), SwingConstants.CENTER);
            nameLabel.setFont(new Font("Arial", Font.BOLD, 10));
            nameLabel.setBounds(x, y + 20, customIconSize, 15);
            parentPanel.add(nameLabel);
        } else {
            Image img = icon.getImage().getScaledInstance(customIconSize, customIconSize, Image.SCALE_SMOOTH);
            JLabel imgLabel = new JLabel(new ImageIcon(img));
            imgLabel.setBounds(x, y, customIconSize, customIconSize);
            parentPanel.add(imgLabel);
        }

        // create the numeric field just below (or centered on) the icon
        JTextField field = new JTextField(String.valueOf(defaultValue));
        field.setHorizontalAlignment(JTextField.CENTER);
        field.setFont(new Font("Arial", Font.BOLD, 15));
        int fieldX = centerTextField ? x + (customIconSize - 48) / 2 : x;
        int fieldY = centerTextField ? y + customIconSize - 15 : y + customIconSize + 5;
        field.setBounds(fieldX, fieldY, 48, 21);
        parentPanel.add(field);

        targetMap.put(name, field);
    }

    /**
     * reads all text fields, valida que sean números válidos,
     * verifica los máximos y, si todo está bien, construye un LevelConfig
     * y se lo pasa al frame principal para continuar al modo de juego.
     */
    private void onSaveAndContinue() {
        if (!validateFields(fruitFields) ||
                !validateFields(enemyFields) ||
                !validateFields(obstacleFields)) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter whole numbers (0 or positive) for all quantities.",
                    "Invalid values",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int totalFruits = sumMap(fruitFields);
        int totalEnemies = sumMap(enemyFields);
        int totalObstacles = sumMap(obstacleFields);

        if (totalFruits > MAX_FRUITS) {
            JOptionPane.showMessageDialog(
                    this,
                    "You can set up to " + MAX_FRUITS + " fruits in total.",
                    "Too many fruits",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        if (totalEnemies > MAX_ENEMIES) {
            JOptionPane.showMessageDialog(
                    this,
                    "You can set up to " + MAX_ENEMIES + " enemies in total.",
                    "Too many enemies",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        if (totalObstacles > MAX_OBSTACLES) {
            JOptionPane.showMessageDialog(
                    this,
                    "You can set up to " + MAX_OBSTACLES + " obstacles in total.",
                    "Too many obstacles",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        LevelConfig config = new LevelConfig();
        config.bananas = getInt(fruitFields.get("Banana"));
        config.grapes = getInt(fruitFields.get("Grape"));
        config.cherries = getInt(fruitFields.get("Cherry"));
        config.pineapples = getInt(fruitFields.get("Pineapple"));
        config.cactus = getInt(fruitFields.get("Cactus"));
        config.trolls = getInt(enemyFields.get("Troll"));
        config.calamares = getInt(enemyFields.get("Calamar"));
        config.macetas = getInt(enemyFields.get("Maceta"));
        config.narvales = getInt(enemyFields.get("Narval"));
        config.fogatas = getInt(obstacleFields.get("Fogata"));
        config.baldosasCalientes = getInt(obstacleFields.get("Baldosa"));

        parent.setCurrentLevelConfig(config);
        parent.showGameModeSelection(parent.getNumberOfPlayers());
    }

    /**
     * checks that every text field in the given map
     * contains an integer number >= 0.
     */
    private boolean validateFields(Map<String, JTextField> map) {
        for (JTextField tf : map.values()) {
            String text = tf.getText();
            try {
                int value = Integer.parseInt(text.trim());
                if (value < 0) return false;
            } catch (NumberFormatException ex) {
                return false;
            }
        }
        return true;
    }

    /**
     * safely parses a JTextField value to int.
     * if the field is null, empty or invalid, returns 0 by default.
     */
    private int getInt(JTextField field) {
        if (field == null) return 0;
        String text = field.getText().trim();
        if (text.isEmpty()) return 0;
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /**
     * sums all the integer values stored in the text fields of the map.
     * this is used to check against the global max of fruits/enemies/obstacles.
     */
    private int sumMap(Map<String, JTextField> map) {
        int sum = 0;
        for (JTextField tf : map.values()) {
            sum += getInt(tf);
        }
        return sum;
    }
}
