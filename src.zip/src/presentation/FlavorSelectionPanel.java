package presentation;

import javax.swing.*;
import java.awt.*;

/**
 * Panel that allows the player to select their ice cream flavor.
 * Shows machine sprites when the player is controlled by AI (PvM for player 2, MvM for both).
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class FlavorSelectionPanel extends JPanel {

    private BadIceCreamGUI parent;
    private int playerNumber;
    private String gameMode;

    /**
     * Constructs the flavor selection panel for a player.
     * @param parent       Reference to the main application window.
     * @param playerNumber The player number (1 or 2).
     * @param gameMode     The current game mode (PvP, PvM, MvM).
     */
    public FlavorSelectionPanel(BadIceCreamGUI parent, int playerNumber, String gameMode) {
        this.parent = parent;
        this.playerNumber = playerNumber;
        this.gameMode = gameMode;
        setLayout(null);
        setPreferredSize(new Dimension(640, 640));

        ImageIcon bgIcon = new ImageIcon("resources/elegir.gif");
        Image bgImage = bgIcon.getImage().getScaledInstance(640, 640, Image.SCALE_DEFAULT);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setLayout(null);
        backgroundLabel.setBounds(0, 0, 640, 640);
        add(backgroundLabel);

        ImageIcon cuadroIcon = new ImageIcon("resources/boton3.png");
        Image cuadroImg = cuadroIcon.getImage().getScaledInstance(560, 260, Image.SCALE_SMOOTH);
        JLabel centerPanel = new JLabel(new ImageIcon(cuadroImg));
        centerPanel.setLayout(null);
        centerPanel.setBounds(40, 150, 560, 260);
        backgroundLabel.add(centerPanel);

        ImageIcon titleIcon = new ImageIcon("resources/chooseFlavour.png");
        Image titleImg = titleIcon.getImage().getScaledInstance(360, 70, Image.SCALE_SMOOTH);
        JLabel titleImgLabel = new JLabel(new ImageIcon(titleImg));
        titleImgLabel.setBounds(100, 10, 360, 70);
        centerPanel.add(titleImgLabel);

        ImageIcon p1Icon = new ImageIcon("resources/player1.2.png");
        ImageIcon p2Icon = new ImageIcon("resources/player2.2.png");
        Image playerImg = (playerNumber == 1) ? p1Icon.getImage() : p2Icon.getImage();
        playerImg = playerImg.getScaledInstance(160, 40, Image.SCALE_SMOOTH);
        JLabel playerImgLabel = new JLabel(new ImageIcon(playerImg));
        playerImgLabel.setBounds((560 - 160) / 2, 80, 160, 40);
        centerPanel.add(playerImgLabel);

        // verificar si es machine
        boolean showMachineSprites = false;
        if ("MvM".equals(gameMode)) {
            showMachineSprites = true;
        } else if ("PvM".equals(gameMode) && playerNumber == 2) {
            showMachineSprites = true;
        }

        String vanillaPath = showMachineSprites ? "resources/vainillaM_front.png" : "resources/vanilla_front.png";
        String strawberryPath = showMachineSprites ? "resources/straberryM_front.png" : "resources/straberry_front.png";
        String chocolatePath = showMachineSprites ? "resources/chocolateM_front.png" : "resources/chocolate_front.png";

        int iceCreamSize = 80;
        int strawberrySize = 70;

        // vanilla
        ImageIcon vanillaIcon = new ImageIcon(vanillaPath);
        Image vanillaScaled = vanillaIcon.getImage().getScaledInstance(iceCreamSize, iceCreamSize, Image.SCALE_SMOOTH);
        JLabel vanillaFront = new JLabel(new ImageIcon(vanillaScaled));
        vanillaFront.setBounds(80, 130, iceCreamSize, iceCreamSize);
        vanillaFront.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        vanillaFront.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selectFlavor("vanilla");
            }
        });
        centerPanel.add(vanillaFront);

        // Strawberry
        ImageIcon strawberryIcon = new ImageIcon(strawberryPath);
        Image strawberryScaled = strawberryIcon.getImage().getScaledInstance(strawberrySize, strawberrySize, Image.SCALE_SMOOTH);
        JLabel strawberryFront = new JLabel(new ImageIcon(strawberryScaled));
        // para centrarlo porque la foto estaba diferente de porporción
        int strawberryX = 230 + ((iceCreamSize - strawberrySize) / 2);
        int strawberryY = 130 + ((iceCreamSize - strawberrySize) / 2);
        strawberryFront.setBounds(strawberryX, strawberryY, strawberrySize, strawberrySize);
        strawberryFront.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        strawberryFront.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selectFlavor("strawberry");
            }
        });
        centerPanel.add(strawberryFront);

        // chocolate
        ImageIcon chocolateIcon = new ImageIcon(chocolatePath);
        Image chocolateScaled = chocolateIcon.getImage().getScaledInstance(iceCreamSize, iceCreamSize, Image.SCALE_SMOOTH);
        JLabel chocolateFront = new JLabel(new ImageIcon(chocolateScaled));
        chocolateFront.setBounds(380, 130, iceCreamSize, iceCreamSize);
        chocolateFront.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        chocolateFront.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                selectFlavor("chocolate");
            }
        });
        centerPanel.add(chocolateFront);

        ImageIcon backIcon = new ImageIcon("resources/back.png");
        Image backImg = backIcon.getImage().getScaledInstance(80, 40, Image.SCALE_SMOOTH);
        JButton backButton = new JButton(new ImageIcon(backImg));
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setFocusPainted(false);
        backButton.setBounds(20, 20, 80, 40);
        backButton.addActionListener(e -> {
            if (playerNumber == 1) {
                parent.showPlayerCountSelection();
            } else {
                parent.showGameModeSelection(2);
            }
        });
        backgroundLabel.add(backButton);
    }

    /**
     * Processes the selected flavor and moves to the next step.
     * @param flavor The selected flavor string.
     */
    private void selectFlavor(String flavor) {
        if (playerNumber == 1) {
            parent.setPlayer1Flavor(flavor);
        } else {
            // guardar el sabor de player 2
            parent.setPlayer2Flavor(flavor);

            // para player 2, verificar si es máquina
            if ("PvM".equals(gameMode) || "MvM".equals(gameMode)) {
                // player 2 es máquina, pedir tipo
                parent.showMachineTypeSelection(2, flavor);
            } else {
                // player 2 es humano, iniciar juego
                parent.startGame(parent.getPlayer1Flavor(), flavor);
            }
        }
    }
}
