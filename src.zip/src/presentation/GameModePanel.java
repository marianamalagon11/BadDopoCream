package presentation;

import javax.swing.*;
import java.awt.*;

/**
 * Presentation panel that allows the user to choose the game mode
 * after selecting two players.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class GameModePanel extends JPanel {

    private BadIceCreamGUI parent;

    /**
     * Builds the game mode selection panel.
     * @param parent main application window that controls screen changes.
     */
    public GameModePanel(BadIceCreamGUI parent) {
        this.parent = parent;
        setLayout(null);
        setPreferredSize(new Dimension(640, 640));

        ImageIcon bgIcon = new ImageIcon("resources/elegir.gif");
        Image bgImage = bgIcon.getImage().getScaledInstance(640, 640, Image.SCALE_DEFAULT);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setLayout(null);
        backgroundLabel.setBounds(0, 0, 640, 640);
        add(backgroundLabel);

        ImageIcon modeTitleIcon = new ImageIcon("resources/changemode.png");
        Image modeTitleImg = modeTitleIcon.getImage().getScaledInstance(360, 70, Image.SCALE_SMOOTH);
        JLabel modeTitleLabel = new JLabel(new ImageIcon(modeTitleImg));
        modeTitleLabel.setBounds((640 - 360) / 2, 80, 360, 70);
        backgroundLabel.add(modeTitleLabel);

        // PvP: player vs player (dos humanos pedir nombre a los dos)
        ImageIcon pvspIcon = new ImageIcon("resources/pvsp.png");
        Image pvspImg = pvspIcon.getImage().getScaledInstance(320, 70, Image.SCALE_SMOOTH);
        JLabel pvspLabel = new JLabel(new ImageIcon(pvspImg));
        pvspLabel.setBounds((640 - 320) / 2, 190, 320, 70);
        pvspLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        pvspLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                // Primero pedir nombre de Player 1, luego sabor
                parent.showNameSelection("PvP", 1);
            }
        });
        backgroundLabel.add(pvspLabel);

        // PvM: player vs machine (solo Player 1 es humano)
        ImageIcon pvsmIcon = new ImageIcon("resources/pvsm.png");
        Image pvsmImg = pvsmIcon.getImage().getScaledInstance(320, 70, Image.SCALE_SMOOTH);
        JLabel pvsmLabel = new JLabel(new ImageIcon(pvsmImg));
        pvsmLabel.setBounds((640 - 320) / 2, 270, 320, 70);
        pvsmLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        pvsmLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                // Player 1 humano pedir nombre y luego sabor
                parent.showNameSelection("PvM", 1);
            }
        });
        backgroundLabel.add(pvsmLabel);

        // MvM: machine vs machine (ningún jugador humano, no se pide nombre)
        ImageIcon mvsmIcon = new ImageIcon("resources/mvsm.png");
        Image mvsmImg = mvsmIcon.getImage().getScaledInstance(320, 70, Image.SCALE_SMOOTH);
        JLabel mvsmLabel = new JLabel(new ImageIcon(mvsmImg));
        mvsmLabel.setBounds((640 - 320) / 2, 350, 320, 70);
        mvsmLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        mvsmLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                // En MvM ambos son máquinas, se puede ir directo a sabor para P1 (máquina)
                parent.showFlavorSelection("MvM", 1);
            }
        });
        backgroundLabel.add(mvsmLabel);

        ImageIcon backIcon = new ImageIcon("resources/back.png");
        Image backImg = backIcon.getImage().getScaledInstance(80, 40, Image.SCALE_SMOOTH);
        JButton backButton = new JButton(new ImageIcon(backImg));
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setFocusPainted(false);
        backButton.setBounds(20, 20, 80, 40);
        backButton.addActionListener(e -> parent.showPlayerCountSelection());
        backgroundLabel.add(backButton);
    }
}
