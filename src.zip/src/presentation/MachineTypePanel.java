package presentation;

import javax.swing.*;
import java.awt.*;

/**
 * Panel that allows the user to choose the machine AI profile.
 * Displays options for Hungry, Fearful, and Expert profiles.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class MachineTypePanel extends JPanel {

    private BadIceCreamGUI parent;
    private int playerNumber;
    private String flavor;

    /**
     * Constructs the machine type selection panel.
     * @param parent       Reference to the main application window.
     * @param playerNumber The player number (1 or 2).
     * @param flavor       The flavor already selected for this machine.
     */
    public MachineTypePanel(BadIceCreamGUI parent, int playerNumber, String flavor) {
        this.parent = parent;
        this.playerNumber = playerNumber;
        this.flavor = flavor;
        setLayout(null);
        setPreferredSize(new Dimension(640, 640));

        // Fondo
        ImageIcon bgIcon = new ImageIcon("resources/fondo.gif");
        Image bgImage = bgIcon.getImage().getScaledInstance(640, 640, Image.SCALE_DEFAULT);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setLayout(null);
        backgroundLabel.setBounds(0, 0, 640, 640);
        add(backgroundLabel);

        // Título
        ImageIcon titleIcon = new ImageIcon("resources/chooseMachineType.png");
        Image titleImg = titleIcon.getImage().getScaledInstance(520, 100, Image.SCALE_SMOOTH);
        JLabel titleLabel = new JLabel(new ImageIcon(titleImg));
        titleLabel.setBounds((640 - 520) / 2, 80, 520, 100);
        backgroundLabel.add(titleLabel);
        int btnWidth = 380;
        int btnHeight = 70;
        int centerX = (640 - btnWidth) / 2;
        int startY = 240;
        int spacing = 85;

        // Hungry button
        ImageIcon hungryIcon = new ImageIcon("resources/hungry.png");
        Image hungryImg = hungryIcon.getImage().getScaledInstance(btnWidth, btnHeight, Image.SCALE_SMOOTH);
        JLabel hungryLabel = new JLabel(new ImageIcon(hungryImg));
        hungryLabel.setBounds(centerX, startY, btnWidth, btnHeight);
        hungryLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        hungryLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                selectMachineType("hungry");
            }
        });
        backgroundLabel.add(hungryLabel);

        // Fearful button
        ImageIcon fearfulIcon = new ImageIcon("resources/fearful.png");
        Image fearfulImg = fearfulIcon.getImage().getScaledInstance(btnWidth, btnHeight, Image.SCALE_SMOOTH);
        JLabel fearfulLabel = new JLabel(new ImageIcon(fearfulImg));
        fearfulLabel.setBounds(centerX, startY + spacing, btnWidth, btnHeight);
        fearfulLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        fearfulLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                selectMachineType("fearful");
            }
        });
        backgroundLabel.add(fearfulLabel);

        // Expert button
        ImageIcon expertIcon = new ImageIcon("resources/expert.png");
        Image expertImg = expertIcon.getImage().getScaledInstance(btnWidth, btnHeight, Image.SCALE_SMOOTH);
        JLabel expertLabel = new JLabel(new ImageIcon(expertImg));
        expertLabel.setBounds(centerX, startY + spacing * 2, btnWidth, btnHeight);
        expertLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        expertLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                selectMachineType("expert");
            }
        });
        backgroundLabel.add(expertLabel);

        // Back button
        ImageIcon backIcon = new ImageIcon("resources/back.png");
        Image backImg = backIcon.getImage().getScaledInstance(80, 40, Image.SCALE_SMOOTH);
        JButton backButton = new JButton(new ImageIcon(backImg));
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setFocusPainted(false);
        backButton.setBounds(20, 20, 80, 40);
        backButton.addActionListener(e -> {
            parent.showFlavorSelection(parent.getGameMode(), playerNumber);
        });
        backgroundLabel.add(backButton);
    }

    /**
     * Processes the selected machine type and continues to next step.
     * @param machineType The selected AI profile type.
     */
    private void selectMachineType(String machineType) {
        if (playerNumber == 1) {
            parent.setPlayer1MachineType(machineType);
        } else {
            parent.setPlayer2MachineType(machineType);
        }
    }
}
