package presentation;

import domain.*;
import javax.swing.*;
import java.awt.*;

/**
 * Main application window for the Bad Ice Cream game.
 * Manages the different screens (menu, player count, level selection,
 * game mode, name selection, flavor selection, machine type selection and gameplay panel).
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class BadIceCreamGUI extends JFrame {

    private CardLayout cardLayout;
    private JPanel mainPanel;
    private Player player1;
    private Player player2;
    private int numberOfPlayers;
    private String gameMode;
    private String player1Flavor;
    private String player2Flavor;
    private String player1MachineType;
    private String player2MachineType;
    private int selectedLevel;
    private GameLogger logger;
    private LevelConfig currentLevelConfig;
    private GamePanel gamePanel;
    //para que pongan su nombre
    private String player1Name;
    private String player2Name;

    /**
     * Builds the main window and shows the initial menu screen.
     */
    public BadIceCreamGUI() {
        setTitle("Bad Ice Cream");
        setSize(640, 640);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        // inicia logger
        logger = GameLogger.getInstance();
        logger.logInfo("Application started");

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // panels
        mainPanel.add(new MenuPanel(this), "MENU");
        mainPanel.add(new PlayerCountPanel(this), "PLAYERS");

        selectedLevel = 1; // default level

        add(mainPanel);

        // cierra logs
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                logger.logInfo("Application closing");
                logger.close();
                System.exit(0);
            }
        });

        setVisible(true);
        logger.logInfo("Main window displayed");
    }

    /**
     * Application entry point. Creates and shows the main game window.
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(BadIceCreamGUI::new);
    }

    /**
     * Switches to the main menu screen.
     */
    public void showMenu() {
        try {
            cardLayout.show(mainPanel, "MENU");
            currentLevelConfig = null; // limpiar config al volver al menu
            logger.logInfo("Showing main menu");
        } catch (Exception e) {
            logger.logError("Error showing menu", e);
        }
    }


    /**
     * Switches to the player count selection screen.
     */
    public void showPlayerCountSelection() {
        try {
            cardLayout.show(mainPanel, "PLAYERS");
            logger.logInfo("Showing player count selection");
        } catch (Exception e) {
            logger.logError("Error showing player count selection", e);
        }
    }

    /**
     * Shows the level selection screen.
     * @param playerCount Number of players selected.
     */
    public void showLevelSelection(int playerCount) {
        try {
            this.numberOfPlayers = playerCount;
            logger.logInfo("Player count set to: " + playerCount);

            // crea panel
            Component[] components = mainPanel.getComponents();
            boolean exists = false;

            for (Component c : components) {
                if (c.getClass().equals(LevelSelectionPanel.class)) {
                    exists = true;
                    break;
                }
            }

            if (!exists) {
                mainPanel.add(new LevelSelectionPanel(this), "LEVEL");
            }
            cardLayout.show(mainPanel, "LEVEL");
            logger.logInfo("Showing level selection");
        } catch (Exception e) {
            logger.logError("Error showing level selection", e);
        }
    }

    /**
     * Shows the level configuration screen for the currently selected level.
     * Displays the default map image, the level description image and
     * lets the user continue or open the advanced map configuration.
     */
    public void showLevelConfig() {
        try {
            LevelConfigPanel panel = new LevelConfigPanel(this, selectedLevel);
            mainPanel.add(panel, "LEVEL_CONFIG");
            cardLayout.show(mainPanel, "LEVEL_CONFIG");
            logger.logInfo("Showing level configuration for level: " + selectedLevel);
        } catch (Exception e) {
            logger.logError("Error showing level configuration", e);
        }
    }

    /**
     * Shows the advanced map configuration screen for a level.
     * Allows choosing which fruits, enemies and obstacles appear and how many.
     * @param levelNumber The level that will use this configuration.
     */
    public void showChangeMapConfig(int levelNumber) {
        try {
            ChangeMapPanel panel = new ChangeMapPanel(this, levelNumber);
            mainPanel.add(panel, "CHANGE_MAP");
            cardLayout.show(mainPanel, "CHANGE_MAP");
            logger.logInfo("Showing change map configuration for level: " + levelNumber);
        } catch (Exception e) {
            logger.logError("Error showing change map configuration", e);
        }
    }



    /**
     * Shows the game mode selection screen for two players,
     * or goes directly to name/flavor selection in single-player.
     * @param playerCount Number of players selected.
     */
    public void showGameModeSelection(int playerCount) {
        try {
            this.numberOfPlayers = playerCount;
            logger.logInfo("Game mode selection for " + playerCount + " player(s)");

            if (playerCount == 2) {
                mainPanel.add(new GameModePanel(this), "MODE");
                cardLayout.show(mainPanel, "MODE");
                logger.logInfo("Showing game mode selection panel");
            } else {
                logger.logInfo("Single player mode, going to name selection for Player 1");
                showNameSelection("PvM", 1);
            }
        } catch (Exception e) {
            logger.logError("Error showing game mode selection", e);
        }
    }


    /**
     * Shows the name selection screen for a given player.
     * @param mode         Selected game mode (PvP, PvM, MvM).
     * @param playerNumber Player number (1 or 2).
     */
    public void showNameSelection(String mode, int playerNumber) {
        try {
            this.gameMode = mode;
            logger.logInfo("Showing name selection for Player " + playerNumber + " in mode: " + mode);

            NameSelectionPanel panel = new NameSelectionPanel(this, playerNumber, mode);
            mainPanel.add(panel, "NAME" + playerNumber);
            cardLayout.show(mainPanel, "NAME" + playerNumber);
        } catch (Exception e) {
            logger.logError("Error showing name selection for player " + playerNumber, e);
        }
    }

    /**
     * Shows the flavor selection screen for a given player.
     * @param mode         Selected game mode (PvP, PvM, MvM).
     * @param playerNumber The player number (1 or 2).
     */
    public void showFlavorSelection(String mode, int playerNumber) {
        try {
            this.gameMode = mode;
            logger.logInfo("Showing flavor selection for Player " + playerNumber + " in mode: " + mode);

            FlavorSelectionPanel panel = new FlavorSelectionPanel(this, playerNumber, mode);
            mainPanel.add(panel, "FLAVOR" + playerNumber);
            cardLayout.show(mainPanel, "FLAVOR" + playerNumber);
        } catch (Exception e) {
            logger.logError("Error showing flavor selection for player " + playerNumber, e);
        }
    }

    /**
     * Shows the machine type selection panel for a machine-controlled player.
     * @param playerNumber The player number (1 or 2).
     * @param flavor       The flavor already selected.
     */
    public void showMachineTypeSelection(int playerNumber, String flavor) {
        try {
            logger.logInfo("Showing machine type selection for Player " + playerNumber + " with flavor: " + flavor);

            MachineTypePanel panel = new MachineTypePanel(this, playerNumber, flavor);
            mainPanel.add(panel, "MACHINE_TYPE" + playerNumber);
            cardLayout.show(mainPanel, "MACHINE_TYPE" + playerNumber);
        } catch (Exception e) {
            logger.logError("Error showing machine type selection for player " + playerNumber, e);
        }
    }

    /**
     * Sets the flavor for player 1, then advances to machine type selection if needed,
     * or to player 2 name/flavor if necessary, or starts single-player game.
     * @param flavor Selected flavor.
     */
    public void setPlayer1Flavor(String flavor) {
        try {
            this.player1Flavor = flavor;
            logger.logInfo("Player 1 flavor set to: " + flavor);

            if ("MvM".equals(gameMode)) {
                // Player 1 es máquina: escoger tipo de máquina
                showMachineTypeSelection(1, flavor);
            } else {
                // Player 1 es humano (PvP o PvM)
                if (numberOfPlayers == 2) {
                    // Dos jugadores
                    if ("PvP".equals(gameMode)) {
                        // Player 2 también es humano  pedir nombre de P2
                        showNameSelection(gameMode, 2);
                    } else {
                        // PvM: Player 2 es máquina ir directo a sabor de P2 o tipo de máquina
                        showFlavorSelection(gameMode, 2);
                    }
                } else {
                    // Un solo jugador (PvM 1 player) empezar juego
                    startGame(flavor, "vanilla");
                }
            }
        } catch (Exception e) {
            logger.logError("Error setting player 1 flavor", e);
        }
    }



    /**
     * Sets the flavor for player 2.
     * @param flavor Selected flavor.
     */
    public void setPlayer2Flavor(String flavor) {
        this.player2Flavor = flavor;
        logger.logInfo("Player 2 flavor set to: " + flavor);
    }

    /**
     * Sets the machine type for player 1 and continues to next step.
     * @param machineType The selected machine type.
     */
    public void setPlayer1MachineType(String machineType) {
        try {
            this.player1MachineType = machineType;
            logger.logInfo("Player 1 machine type set to: " + machineType);

            if (numberOfPlayers == 2) {
                // En MvM o PvM, player 2 es máquina ir a sabor de P2
                showFlavorSelection(gameMode, 2);
            } else {
                startGame(player1Flavor, "vanilla");
            }
        } catch (Exception e) {
            logger.logError("Error setting player 1 machine type", e);
        }
    }



    /**
     * Sets the machine type for player 2 and starts the game.
     * @param machineType The selected machine type.
     */
    public void setPlayer2MachineType(String machineType) {
        try {
            this.player2MachineType = machineType;
            logger.logInfo("Player 2 machine type set to: " + machineType);
            startGame(player1Flavor, player2Flavor);
        } catch (Exception e) {
            logger.logError("Error setting player 2 machine type", e);
        }
    }

    /**
     * Sets the name for player 1 (stored before creating the Player object).
     * @param name Name chosen by player 1.
     */
    public void setPlayer1Name(String name) {
        this.player1Name = name;
        logger.logInfo("Player 1 name set to: " + name);
    }

    /**
     * Sets the name for player 2 (stored before creating the Player object).
     * @param name Name chosen by player 2.
     */
    public void setPlayer2Name(String name) {
        this.player2Name = name;
        logger.logInfo("Player 2 name set to: " + name);
    }

    /**
     * Returns the player 1 instance.
     * @return player1
     */
    public Player getPlayer() {
        return player1;
    }
    /**
     * Returns the player 1 flavor selection.
     * @return Flavor string ("vanilla", "strawberry", or "chocolate").
     */
    public String getPlayer1Flavor() {
        return player1Flavor;
    }
    /**
     * Returns the current game mode.
     * @return Game mode string ("PvP", "PvM", or "MvM").
     */
    public String getGameMode() {
        return gameMode;
    }
    /**
     * Returns the number of players in the current game.
     * @return 1 for single player, 2 for multiplayer.
     */
    public int getNumberOfPlayers() {
        return numberOfPlayers;
    }
    /**
     * Sets the selected level number for the next game session.
     * @param level Level number to select (1, 2, 3, etc.).
     */
    public void setSelectedLevel(int level) {
        this.selectedLevel = level;
        logger.logInfo("Selected level set to: " + level);
    }

    /**
     * Creates the level, players, and game panel, then shows the gameplay screen.
     * @param flavor1 Flavor for player 1.
     * @param flavor2 Flavor for player 2.
     */
    public void startGame(String flavor1, String flavor2) {
        try {
            logger.logInfo("Starting Game");
            logger.logInfo("Level: " + selectedLevel);
            logger.logInfo("Game Mode: " + gameMode);
            logger.logInfo("Number of Players: " + numberOfPlayers);
            logger.logInfo("Player 1 Flavor: " + flavor1);
            if (numberOfPlayers == 2) {
                logger.logInfo("Player 2 Flavor: " + flavor2);
            }

            Level level = setupLevel(selectedLevel, flavor1, flavor2);
            GamePanel gamePanel = new GamePanel(this, player1, player2,
                    level, numberOfPlayers, gameMode);
            mainPanel.add(gamePanel, "GAME");
            cardLayout.show(mainPanel, "GAME");
            gamePanel.requestFocus();

            logger.logInfo("Game started successfully");
        } catch (Exception e) {
            logger.logError("Critical error starting game", e);
            JOptionPane.showMessageDialog(this,
                    "Error starting game: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Restarts the current level with the same mode and flavors.
     */
    public void restartGame() {
        try {
            logger.logInfo("Restarting Game");

            Level level = setupLevel(selectedLevel, player1Flavor,
                    (numberOfPlayers == 2 && player2 != null) ? player2.getFlavor() : "vanilla");
            GamePanel gamePanel = new GamePanel(this, player1, player2,
                    level, numberOfPlayers, gameMode);
            mainPanel.add(gamePanel, "GAME");
            cardLayout.show(mainPanel, "GAME");
            gamePanel.requestFocus();

            logger.logInfo("Game restarted successfully");
        } catch (Exception e) {
            logger.logError("Error restarting game", e);
        }
    }

    /**
     * Sets up the specified level and creates players based on flavors and game mode.
     * Player 1 is human in PvP and PvM; machine in MvM.
     * Player 2 is human in PvP and machine in PvM/MvM.
     * Also assigns the previously chosen names to the Player objects.
     * @param levelNumber The level to create (1, 2, 3, etc.).
     * @param flavor1     Flavor for player 1.
     * @param flavor2     Flavor for player 2 (if any).
     * @return configured Level object.
     */
    private Level setupLevel(int levelNumber, String flavor1, String flavor2) {
        try {
            Level level;
            Position p1Start;
            Position p2Start;

            logger.logInfo("Setting up level " + levelNumber);

            level = Levels.load(levelNumber);

            // obtener posiciones desde Levels (métodos estáticos)
            p1Start = Levels.getPlayer1Start(levelNumber);
            p2Start = Levels.getPlayer2Start(levelNumber);

            // aplicar configuracion personalizada si existe
            if (currentLevelConfig != null && currentLevelConfig.hasCustomValues()) {
                logger.logInfo("Applying custom level configuration");
                applyCustomConfig(level, currentLevelConfig, p1Start, p2Start);
            }

            // crear players
            boolean p1IsMachine = "MvM".equals(gameMode);

            if ("vanilla".equals(flavor1)) {
                player1 = new VanillaIceCream(p1Start, p1IsMachine);
            } else if ("strawberry".equals(flavor1)) {
                player1 = new StrawberryIceCream(p1Start, p1IsMachine);
            } else {
                player1 = new ChocolateIceCream(p1Start, p1IsMachine);
            }

            // nombre para p1 si es humano
            if (!player1.isMachine()) {
                if (player1Name != null) {
                    String trimmed = player1Name.trim();
                    if (!trimmed.isEmpty()) {
                        player1.setName(trimmed);
                    }
                }
            }

            logger.logInfo("Player 1 created: " + flavor1 +
                    ", Machine: " + p1IsMachine +
                    ", Name: " + player1.getName());

            if (p1IsMachine && player1MachineType != null) {
                assignMachineProfile(player1, player1MachineType);
            }

            if (numberOfPlayers == 2) {
                boolean p2IsMachine = "PvM".equals(gameMode) || "MvM".equals(gameMode);

                if ("vanilla".equals(flavor2)) {
                    player2 = new VanillaIceCream(p2Start, p2IsMachine);
                } else if ("strawberry".equals(flavor2)) {
                    player2 = new StrawberryIceCream(p2Start, p2IsMachine);
                } else {
                    player2 = new ChocolateIceCream(p2Start, p2IsMachine);
                }

                // nombre para p2 si es humano
                if (!p2IsMachine) {
                    if (player2Name != null) {
                        String trimmed2 = player2Name.trim();
                        if (!trimmed2.isEmpty()) {
                            player2.setName(trimmed2);
                        }
                    }
                }

                if (player2 != null) {
                    logger.logInfo("Player 2 created: " + flavor2 +
                            ", Machine: " + p2IsMachine +
                            ", Name: " + player2.getName());
                }

                if (p2IsMachine && player2MachineType != null) {
                    assignMachineProfile(player2, player2MachineType);
                }
            } else {
                player2 = null;
            }

            logger.logInfo("Level setup completed successfully");
            return level;

        } catch (Exception e) {
            logger.logError("Error setting up level", e);
            throw e;
        }
    }

    /**
     * Assigns the appropriate machine profile to a player.
     * @param player      The player to assign profile to.
     * @param machineType The type of machine profile.
     */
    private void assignMachineProfile(Player player, String machineType) {
        try {
            Machine profile = null;

            switch (machineType) {
                case "hungry":
                    profile = new HungryMachine();
                    break;
                case "fearful":
                    profile = new FearfulMachine();
                    break;
                case "expert":
                    profile = new ExpertMachine();
                    break;
                default:
                    logger.logWarning("Unknown machine type: " + machineType);
            }

            if (profile != null) {
                player.setMachineProfile(profile);
                logger.logInfo("Machine profile assigned: " + machineType +
                        " to player with flavor " + player.getFlavor());
            } else {
                logger.logError("Failed to create machine profile: " + machineType);
            }
        } catch (Exception e) {
            logger.logError("Error assigning machine profile: " + machineType, e);
        }
    }

    /**
     * Sets the current level configuration chosen by the player.
     * @param config LevelConfig instance or null for default behavior.
     */
    public void setCurrentLevelConfig(LevelConfig config) {
        this.currentLevelConfig = config;
    }

    /**
     * Returns the current level configuration or null.
     * @return LevelConfig or null if none.
     */
    public LevelConfig getCurrentLevelConfig() {
        return currentLevelConfig;
    }

    /**
     * Applies a custom configuration to a level by adjusting the number
     * of fruits, enemies and obstacles, using predefined position slots.
     * Does not change the base map layout.
     * @param level  Level instance to modify.
     * @param config Configuration chosen by the player.
     */
    private void applyCustomConfig(Level level, LevelConfig config,
                                   Position p1Start, Position p2Start) {
        try {
            if (level.getLevelNumber() == 1) {
                LevelConfigHelper.configureLevel1(level, config, p1Start, p2Start);
            } else if (level.getLevelNumber() == 2) {
                LevelConfigHelper.configureLevel2(level, config, p1Start, p2Start);
            } else if (level.getLevelNumber() == 3) {
                LevelConfigHelper.configureLevel3(level, config, p1Start, p2Start);
            }
            logger.logInfo("Custom configuration applied successfully");
        } catch (Exception e) {
            logger.logError("Error applying custom level configuration", e);
        }
    }

    /**
     * Loads the next level with the same players and game mode.
     * @param levelNumber the level number to load (1, 2, or 3)
     */
    /**
     * Loads the next level with the same players and game mode.
     * @param levelNumber the level number to load (1, 2, or 3)
     */
    public void loadNextLevel(int levelNumber) {
        try {
            logger.logInfo("Loading next level: " + levelNumber);

            // Actualizar el nivel seleccionado
            this.selectedLevel = levelNumber;

            // Reposicionar jugadores a las posiciones iniciales del nuevo nivel
            Position p1Start = Levels.getPlayer1Start(levelNumber);
            player1.setPosition(p1Start);
            player1.setState(PlayerState.NORMAL);

            if (player2 != null) {
                Position p2Start = Levels.getPlayer2Start(levelNumber);
                player2.setPosition(p2Start);
                player2.setState(PlayerState.NORMAL);
            }

            // Usar el mismo método setupLevel que ya tienes
            Level nextLevel = setupLevel(levelNumber, player1Flavor,
                    numberOfPlayers == 2 ? player2Flavor : "vanilla");

            // Crear nuevo GamePanel con el siguiente nivel
            gamePanel = new GamePanel(this, player1, player2, nextLevel, numberOfPlayers, gameMode);
            mainPanel.add(gamePanel, "GAME");
            cardLayout.show(mainPanel, "GAME");
            gamePanel.requestFocusInWindow();

            logger.logInfo("Level " + levelNumber + " loaded successfully");

        } catch (Exception e) {
            logger.logError("Error loading next level", e);
            JOptionPane.showMessageDialog(this,
                    "Error al cargar el nivel: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            showMenu();
        }
    }

}
