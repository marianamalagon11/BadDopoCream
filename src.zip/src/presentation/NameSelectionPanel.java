package presentation;

import javax.swing.*;
import java.awt.*;

/**
 * Panel that allows a player to enter their name before selecting flavor.
 * Uses the same background style as the flavor selection panel,
 * but with a specific title image (writeName.png).
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class NameSelectionPanel extends JPanel {

    private BadIceCreamGUI parent;
    private int playerNumber;
    private String gameMode;

    private JTextField nameField;

    /**
     * Builds the name selection panel for a player.
     * @param parent       Reference to the main application window.
     * @param playerNumber Player number (1 or 2).
     * @param gameMode     Current game mode (PvP, PvM, MvM).
     */
    public NameSelectionPanel(BadIceCreamGUI parent, int playerNumber, String gameMode) {
        this.parent = parent;
        this.playerNumber = playerNumber;
        this.gameMode = gameMode;

        setLayout(null);
        setPreferredSize(new Dimension(640, 640));

        // Background image
        ImageIcon bgIcon = new ImageIcon("resources/elegir.gif");
        Image bgImage = bgIcon.getImage().getScaledInstance(640, 640, Image.SCALE_DEFAULT);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setLayout(null);
        backgroundLabel.setBounds(0, 0, 640, 640);
        add(backgroundLabel);

        // Central panel using boton3.png
        ImageIcon cuadroIcon = new ImageIcon("resources/boton3.png");
        Image cuadroImg = cuadroIcon.getImage().getScaledInstance(560, 260, Image.SCALE_SMOOTH);
        JLabel centerPanel = new JLabel(new ImageIcon(cuadroImg));
        centerPanel.setLayout(null);
        centerPanel.setBounds(40, 150, 560, 260);
        backgroundLabel.add(centerPanel);

        // Title image: writeName.png
        ImageIcon titleIcon = new ImageIcon("resources/writeName.png");
        Image titleImg = titleIcon.getImage().getScaledInstance(360, 70, Image.SCALE_SMOOTH);
        JLabel titleImgLabel = new JLabel(new ImageIcon(titleImg));
        titleImgLabel.setBounds(100, 10, 360, 70);
        centerPanel.add(titleImgLabel);

        // Player 1 / Player 2 label image (same as flavor panel)
        ImageIcon p1Icon = new ImageIcon("resources/player1.2.png");
        ImageIcon p2Icon = new ImageIcon("resources/player2.2.png");
        Image playerImg = (playerNumber == 1) ? p1Icon.getImage() : p2Icon.getImage();
        playerImg = playerImg.getScaledInstance(160, 40, Image.SCALE_SMOOTH);
        JLabel playerImgLabel = new JLabel(new ImageIcon(playerImg));
        playerImgLabel.setBounds((560 - 160) / 2, 80, 160, 40);
        centerPanel.add(playerImgLabel);

        // Text field to enter the name
        nameField = new JTextField();
        nameField.setBounds(130, 150, 300, 40);
        nameField.setFont(new Font("Arial", Font.BOLD, 18));
        centerPanel.add(nameField);

        // Continue button
        JButton continueButton = new JButton("Continuar");
        continueButton.setBounds(220, 210, 120, 35);
        continueButton.setFocusPainted(false);
        continueButton.addActionListener(e -> confirmName());
        centerPanel.add(continueButton);

        // Back button (same style as other panels)
        ImageIcon backIcon = new ImageIcon("resources/back.png");
        Image backImg = backIcon.getImage().getScaledInstance(80, 40, Image.SCALE_SMOOTH);
        JButton backButton = new JButton(new ImageIcon(backImg));
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setFocusPainted(false);
        backButton.setBounds(20, 20, 80, 40);
        backButton.addActionListener(e -> {
            if (playerNumber == 1) {
                parent.showPlayerCountSelection();
            } else {
                parent.showGameModeSelection(2);
            }
        });
        backgroundLabel.add(backButton);
    }

    /**
     * Reads the entered name, stores it in the GUI, and moves to flavor selection.
     * If the field is empty, a default name is used.
     */
    private void confirmName() {
        String name = nameField.getText();
        if (name == null || name.trim().isEmpty()) {
            name = (playerNumber == 1) ? "Player 1" : "Player 2";
        }

        if (playerNumber == 1) {
            parent.setPlayer1Name(name);
            parent.showFlavorSelection(gameMode, 1);
        } else {
            parent.setPlayer2Name(name);
            parent.showFlavorSelection(gameMode, 2);
        }
    }
}
