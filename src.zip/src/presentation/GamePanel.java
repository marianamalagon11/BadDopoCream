package presentation;

import domain.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Main gameplay panel.
 * Draws the level and HUD, runs the main loop
 * and shows pause / victory / game-over overlays.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class GamePanel extends JPanel implements KeyListener, MouseListener {

    private BadIceCreamGUI parent;
    private Player player1;
    private Player player2;
    private Level level;
    private GameManager manager;
    private GameLogger logger;

    // Game logic handler
    private BadIceCream gameLogic;

    private Timer gameTimer;
    private Timer secondTimer;
    private Timer aiTimer1;
    private Timer aiTimer2;

    private boolean paused = false;
    private boolean gameOver = false;
    private boolean victory = false;
    private boolean showSaveMenu = false;

    private int numberOfPlayers;
    private String gameMode;
    private List<Position> iceOnCampfires = new ArrayList<>();

    // Grid
    private final int TILE_SIZE = 32;
    private final int GRID_WIDTH = 15;
    private final int GRID_HEIGHT = 14;
    private final int GRID_START_X = 80;
    private final int GRID_START_Y = 130;

    private Image borderBlockImg = new ImageIcon("resources/border.png").getImage();

    // Frutas
    private boolean bananasPhase = true;
    private boolean grapesPhase = false;
    private boolean pineapplesPhase = false;
    private int totalBananas;
    private int bananasCollected;
    private int totalPineapples;
    private int pineapplesCollected;

    // info del ganador
    private int winnerPlayerIndex;
    private Player winnerPlayer;

    // ilustraciones para cuando gana
    private Image victoryGif;
    private Image p1WinImg;
    private Image p2WinImg;
    private Image vanillaWinGif;
    private Image strawberryWinGif;
    private Image chocolateWinGif;

    private Image vanillaMWinGif;
    private Image strawberryMWinGif;
    private Image chocolateMWinGif;

    // que el hielo rompa bien y se vea
    private boolean showingBreaking = false;
    private List<Position> breakingLine = new ArrayList<>();
    private Image iceBreakingImg = new ImageIcon("resources/ice_breaking.png").getImage();
    private List<Position> meltingIce = new ArrayList<>();

    // Sprites/gifs de frutas como en el juego original
    private Image bananaImg    = new ImageIcon("resources/banana.gif").getImage();
    private Image grapeImg     = new ImageIcon("resources/grape.gif").getImage();
    private Image cherryImg    = new ImageIcon("resources/cherry.gif").getImage();
    private Image pineappleImg = new ImageIcon("resources/pineapple.gif").getImage();
    private Image cactusImg    = new ImageIcon("resources/cactus.gif").getImage();

    // Coordenadas del botón de "tresp" (guardar/abrir)
    private int trespX, trespY, trespW = 80, trespH = 30;
    private int menuX, menuY, menuW = 200, menuH = 120;

    private int nextLevelX, nextLevelY, nextLevelW = 140, nextLevelH = 60;

    /**
     * Builds the main gameplay panel with players, level and game mode.
     * @param parent          reference to the main window.
     * @param player1         player 1 instance.
     * @param player2         player 2 instance (can be null).
     * @param level           level to be played.
     * @param numberOfPlayers number of active players (1 or 2).
     * @param gameMode        game mode string ("PvP", "PvM", "MvM").
     */
    public GamePanel(BadIceCreamGUI parent, Player player1, Player player2,
                     Level level, int numberOfPlayers, String gameMode) {
        this.parent = parent;
        this.player1 = player1;
        this.player2 = player2;
        this.level = level;
        this.numberOfPlayers = numberOfPlayers;
        this.gameMode = gameMode;
        this.logger = GameLogger.getInstance();

        try {
            logger.logInfo("Game Panel Initialized");
            logger.logInfo("Number of players: " + numberOfPlayers);
            logger.logInfo("Game mode: " + gameMode);

            if (player1.isMachine()) {
                logger.logInfo("Player 1: Machine (" + player1.getMachineProfile().getProfileType() + "), Flavor: " + player1.getFlavor());
            } else {
                logger.logInfo("Player 1: Human, Flavor: " + player1.getFlavor());
            }

            if (player2 != null) {
                if (player2.isMachine()) {
                    logger.logInfo("Player 2: Machine (" + player2.getMachineProfile().getProfileType() + "), Flavor: " + player2.getFlavor());
                } else {
                    logger.logInfo("Player 2: Human, Flavor: " + player2.getFlavor());
                }
            }

            // Inicializar BadIceCream
            this.gameLogic = new BadIceCream(player1, player2, numberOfPlayers, level);

            // Usar el GameManager de BadIceCream
            this.manager = gameLogic.getGameManager();

            // Sincronizar variables de fase con gameLogic
            this.bananasPhase = gameLogic.isBananasPhase();
            this.grapesPhase = gameLogic.isGrapesPhase();
            this.pineapplesPhase = gameLogic.isPineapplesPhase();

            // total de frutas según si el nivel está configurado o no
            if (level.isCustomConfigured()) {
                this.totalBananas = level.getFruits().size();
            } else {
                this.totalBananas = gameLogic.getTotalBananas();
            }
            this.bananasCollected = 0;
            this.pineapplesCollected = 0;

            logger.logInfo("Total fruits in level (HUD): " + totalBananas);

            // cargar lo de victoria
            victoryGif = new ImageIcon("resources/victory.gif").getImage();
            p1WinImg = new ImageIcon("resources/p1win.png").getImage();
            p2WinImg = new ImageIcon("resources/p2win.png").getImage();
            vanillaWinGif = new ImageIcon("resources/vainillawin.gif").getImage();
            strawberryWinGif = new ImageIcon("resources/straberrywin.gif").getImage();
            chocolateWinGif = new ImageIcon("resources/chocolatewin.gif").getImage();

            vanillaMWinGif = new ImageIcon("resources/vainillaMwin.gif").getImage();
            strawberryMWinGif = new ImageIcon("resources/straberryMwin.gif").getImage();
            chocolateMWinGif = new ImageIcon("resources/chocolateMwin.gif").getImage();

            winnerPlayerIndex = 0;
            winnerPlayer = null;

            setFocusable(true);
            addKeyListener(this);
            addMouseListener(this);
            setPreferredSize(new Dimension(640, 720));

            // controla tiempo y tics del juego
            gameTimer = new Timer(100, e -> {
                if (!paused && !gameOver) {
                    updateGame();
                    repaint();
                }
            });
            gameTimer.start();
            logger.logInfo("Game timer started");

            // ir disminuyendo el tiempo
            secondTimer = new Timer(1000, e -> {
                if (!paused && !gameOver) {
                    manager.decreaseTime();
                    repaint();
                }
            });
            secondTimer.start();
            logger.logInfo("Second timer started");

            // timer para cada modo de juego
            if ("MvM".equals(gameMode)) {
                aiTimer1 = new Timer(400, e -> {
                    if (!paused && !gameOver) moveAI(player1);
                });
                aiTimer1.start();
                logger.logInfo("AI timer 1 started (Player 1)");
            }
            if (("MvM".equals(gameMode) || "PvM".equals(gameMode)) && numberOfPlayers == 2) {
                aiTimer2 = new Timer(400, e -> {
                    if (!paused && !gameOver) moveAI(player2);
                });
                aiTimer2.start();
                logger.logInfo("AI timer 2 started (Player 2)");
            }

            logger.logInfo("Game panel initialization completed successfully");

        } catch (Exception e) {
            logger.logError("Error initializing game panel", e);
            JOptionPane.showMessageDialog(this,
                    "Error initializing game: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Draws the HUD with scores, time and fruit counter.
     * @param g2d Graphics2D object to draw with.
     */
    private void drawImprovedHUD(Graphics2D g2d) {
        try {
            g2d.setColor(new Color(20, 30, 50, 200));
            g2d.fillRoundRect(10, 10, 600, 80, 15, 15);

            g2d.setColor(new Color(100, 150, 200));
            g2d.setStroke(new BasicStroke(2));
            g2d.drawRoundRect(10, 10, 600, 80, 15, 15);

            g2d.setFont(new Font("Arial", Font.BOLD, 16));

            int leftX = 30;
            int topY = 35;

            g2d.setColor(Color.WHITE);
            g2d.drawString("SCORE", leftX, topY);

            // Player 1 name and score
            g2d.setFont(new Font("Arial", Font.BOLD, 20));
            g2d.setColor(new Color(255, 215, 0));

            String p1Name = (player1 != null && player1.getName() != null)
                    ? player1.getName()
                    : "P1";
            g2d.drawString(p1Name + ": " + manager.getScorePlayer1(), leftX, topY + 25);

            // Player 2 name and score
            if (numberOfPlayers == 2 && player2 != null) {
                g2d.setColor(new Color(100, 200, 255));
                String p2Name = (player2.getName() != null) ? player2.getName() : "P2";
                g2d.drawString(p2Name + ": " + manager.getScorePlayer2(), leftX, topY + 50);
            }

            int centerX = 280;
            drawFruitTutorialImproved(g2d, centerX, 35);

            int rightX = 480;

            g2d.setFont(new Font("Arial", Font.BOLD, 16));

            int seconds = manager.getTimeRemaining();
            int minutes = seconds / 60;
            int secs = seconds % 60;
            String timeText = String.format("%02d:%02d", minutes, secs);

            if (seconds < 60) {
                g2d.setColor(new Color(255, 100, 100));
            } else {
                g2d.setColor(Color.BLACK);
            }

            g2d.setFont(new Font("Arial", Font.BOLD, 24));
            g2d.drawString("Time: " + timeText, rightX, topY + 5);

            g2d.setFont(new Font("Arial", Font.BOLD, 16));
            g2d.setColor(Color.WHITE);
            g2d.drawString("Fruits: " + manager.getFruitsCollected() + "/" +
                    level.getFruits().size(), rightX, topY + 40);

        } catch (Exception e) {
            logger.logError("Error drawing HUD", e);
        }
    }
    /**
     * Draws the fruit collection phase indicator in the HUD.
     * Shows which fruits are currently collectible with visual indicators.
     * Displays different fruit icons and arrows based on level and current phase.
     * @param g2d Graphics2D object for rendering.
     * @param centerX Horizontal center position for the indicator.
     * @param centerY Vertical center position for the indicator.
     */
    private void drawFruitTutorialImproved(Graphics2D g2d, int centerX, int centerY) {
        try {
            g2d.setColor(new Color(50, 70, 100, 180));
            g2d.fillRoundRect(centerX - 60, centerY - 5, 120, 60, 10, 10);

            g2d.setColor(new Color(150, 200, 255));
            g2d.drawRoundRect(centerX - 60, centerY - 5, 120, 60, 10, 10);

            if (level.getLevelNumber() == 3) {
                // Level 3: Cherries primero, luego Cactus
                if (bananasPhase) { // Usamos bananasPhase para cherries
                    Image cherrySel = new ImageIcon("resources/cherrySelected.png").getImage();
                    Image cactusImg = new ImageIcon("resources/cactus.png").getImage();
                    Image arrow = new ImageIcon("resources/flechaAbajo.gif").getImage();

                    g2d.drawImage(cherrySel, centerX - 40, centerY + 5, 40, 40, null);
                    g2d.drawImage(cactusImg, centerX + 10, centerY + 10, 30, 30, null);
                    g2d.drawImage(arrow, centerX - 30, centerY - 20, 25, 25, null);

                } else if (grapesPhase) { // Usamos grapesPhase para cactus
                    Image cherryImg = new ImageIcon("resources/cherry.png").getImage();
                    Image cactusSel = new ImageIcon("resources/cactusSelected.png").getImage();
                    Image arrow = new ImageIcon("resources/flechaAbajo.gif").getImage();

                    g2d.drawImage(cherryImg, centerX - 40, centerY + 5, 40, 40, null);
                    g2d.drawImage(cactusSel, centerX + 10, centerY + 10, 40, 40, null);
                    g2d.drawImage(arrow, centerX + 15, centerY - 20, 25, 25, null);
                }
            } else if (level.getLevelNumber() == 2) {
                // Level 2: Bananas primero, luego Piñas
                if (bananasPhase) {
                    Image bananaSel = new ImageIcon("resources/bananaSelected.png").getImage();
                    Image pineappleImg = new ImageIcon("resources/pineapple.png").getImage();
                    Image arrow = new ImageIcon("resources/flechaAbajo.gif").getImage();

                    g2d.drawImage(bananaSel, centerX - 40, centerY + 5, 40, 40, null);
                    g2d.drawImage(pineappleImg, centerX + 10, centerY + 10, 30, 30, null);
                    g2d.drawImage(arrow, centerX - 30, centerY - 20, 25, 25, null);

                } else if (pineapplesPhase) {
                    Image bananaImg = new ImageIcon("resources/banana.png").getImage();
                    Image pineappleSel = new ImageIcon("resources/pineappleSelected.png").getImage();
                    Image arrow = new ImageIcon("resources/flechaAbajo.gif").getImage();

                    g2d.drawImage(bananaImg, centerX - 40, centerY + 5, 40, 40, null);
                    g2d.drawImage(pineappleSel, centerX + 10, centerY + 10, 40, 40, null);
                    g2d.drawImage(arrow, centerX + 15, centerY - 20, 25, 25, null);
                }
            } else {
                // Level 1: Bananas primero, luego Uvas
                if (bananasPhase) {
                    Image bananaSel = new ImageIcon("resources/bananaSelected.png").getImage();
                    Image grapesImg = new ImageIcon("resources/grapes.png").getImage();
                    Image arrow = new ImageIcon("resources/flechaAbajo.gif").getImage();

                    g2d.drawImage(bananaSel, centerX - 40, centerY + 5, 40, 40, null);
                    g2d.drawImage(grapesImg, centerX + 10, centerY + 10, 30, 30, null);
                    g2d.drawImage(arrow, centerX - 30, centerY - 20, 25, 25, null);

                } else if (grapesPhase) {
                    Image bananaImg = new ImageIcon("resources/banana.png").getImage();
                    Image grapeSelImg = new ImageIcon("resources/grapeSelected.png").getImage();
                    Image arrow = new ImageIcon("resources/flechaAbajo.gif").getImage();

                    g2d.drawImage(bananaImg, centerX - 40, centerY + 5, 40, 40, null);
                    g2d.drawImage(grapeSelImg, centerX + 10, centerY + 10, 40, 40, null);
                    g2d.drawImage(arrow, centerX + 15, centerY - 20, 25, 25, null);
                }
            }
        } catch (Exception e) {
            logger.logError("Error drawing fruit tutorial", e);
        }
    }

    /**
     * Draws decorative border blocks around the playable grid.
     * @param g Graphics context.
     */
    private void drawBorderBlocks(Graphics g) {
        try {
            for (int x = -1; x <= GRID_WIDTH; x++) {
                g.drawImage(borderBlockImg, GRID_START_X + x * TILE_SIZE,
                        GRID_START_Y - TILE_SIZE, TILE_SIZE, TILE_SIZE, null);
                g.drawImage(borderBlockImg, GRID_START_X + x * TILE_SIZE,
                        GRID_START_Y + GRID_HEIGHT * TILE_SIZE, TILE_SIZE, TILE_SIZE, null);
            }
            for (int y = 0; y < GRID_HEIGHT; y++) {
                g.drawImage(borderBlockImg, GRID_START_X - TILE_SIZE,
                        GRID_START_Y + y * TILE_SIZE, TILE_SIZE, TILE_SIZE, null);
                g.drawImage(borderBlockImg, GRID_START_X + GRID_WIDTH * TILE_SIZE,
                        GRID_START_Y + y * TILE_SIZE, TILE_SIZE, TILE_SIZE, null);
            }
        } catch (Exception e) {
            logger.logError("Error drawing border blocks", e);
        }
    }

    /**
     * Draws the ice blocks contained in the level map.
     * @param g Graphics context.
     */
    private void drawMapBlocks(Graphics g) {
        try {
            for (int x = 0; x < GRID_WIDTH; x++) {
                for (int y = 0; y < GRID_HEIGHT; y++) {
                    Block block = level.getMap().getBlock(x, y);
                    if (block != null && block.isIce()) {
                        Image iceImg = new ImageIcon("resources/ice.png").getImage();
                        int iceSize = TILE_SIZE + 8;
                        int offset = (TILE_SIZE - iceSize) / 2;

                        g.drawImage(iceImg,
                                GRID_START_X + x * TILE_SIZE + offset,
                                GRID_START_Y + y * TILE_SIZE + offset - 1,
                                iceSize, iceSize, null);
                    }
                }
            }

            // Dibujar hielo sobre fogatas
            Image iceImg = new ImageIcon("resources/ice.png").getImage();
            int iceSize = TILE_SIZE + 8;
            int offset = (TILE_SIZE - iceSize) / 2;

            for (Position icePos : iceOnCampfires) {
                g.drawImage(iceImg,
                        GRID_START_X + icePos.getX() * TILE_SIZE + offset,
                        GRID_START_Y + icePos.getY() * TILE_SIZE + offset - 1,
                        iceSize, iceSize, null);
            }

        } catch (Exception e) {
            logger.logError("Error drawing map blocks", e);
        }
    }


    /**
     * Paints background, HUD, map, entities and overlays.
     * @param g Graphics context.
     */
    @Override
    protected void paintComponent(Graphics g) {
        try {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            Image bgImg = new ImageIcon("resources/gamebackground.png").getImage();
            g.drawImage(bgImg, 0, 0, 640, 720, null);

            drawImprovedHUD(g2d);
            drawBorderBlocks(g);
            drawHotTiles(g);
            drawObstacles(g);
            drawMapBlocks(g);

            if (showingBreaking) {
                for (Position pos : breakingLine) {
                    g.drawImage(iceBreakingImg,
                            GRID_START_X + pos.getX() * TILE_SIZE,
                            GRID_START_Y + pos.getY() * TILE_SIZE,
                            TILE_SIZE, TILE_SIZE, this);
                }
            }

            drawIglu(g);
            drawFruits(g);
            drawEnemies(g);
            drawPlayers(g);

            if (paused) drawPauseOverlay(g2d);
            if (gameOver) drawGameOverOverlay(g2d);

        } catch (Exception e) {
            logger.logError("Error in paintComponent", e);
        }
        if (paused) {
            if (showSaveMenu) {
                showFileMenu(g);
            }
        }

    }

    /**
     * Draws hot tiles BEFORE other elements so they're visible.
     * @param g Graphics context.
     */
    private void drawHotTiles(Graphics g) {
        try {
            for (BaldosaCaliente baldosa : level.getMap().getBaldosasCalientes()) {
                Position pos = baldosa.getPosition();
                Image baldosaImg = new ImageIcon(baldosa.getImagePath()).getImage();

                int baldosaSize = TILE_SIZE * 2;
                int offsetX = -TILE_SIZE / 2;
                int offsetY = 0;

                g.drawImage(baldosaImg,
                        GRID_START_X + pos.getX() * TILE_SIZE + offsetX,
                        GRID_START_Y + pos.getY() * TILE_SIZE + offsetY,
                        baldosaSize, baldosaSize, this);
            }
        } catch (Exception e) {
            logger.logError("Error drawing hot tiles", e);
        }
    }

    /**
     * Draws obstacles (campfires only).
     * Campfires are drawn UNDER ice, so they're visible when ice is removed.
     * @param g Graphics context.
     */
    private void drawObstacles(Graphics g) {
        try {
            // Dibujar fogatas
            for (Fogata fogata : level.getMap().getFogatas()) {
                Position pos = fogata.getPosition();

                // No dibujar fogata si tiene hielo encima
                boolean hasIce = false;
                for (Position icePos : iceOnCampfires) {
                    if (icePos.equals(pos)) {
                        hasIce = true;
                        break;
                    }
                }

                // Solo dibujar si no tiene hielo
                if (!hasIce) {
                    Image fogataImg = new ImageIcon(fogata.getImagePath()).getImage();
                    int fogataSize = (int)(TILE_SIZE * 1.5);
                    int offsetX = (TILE_SIZE - fogataSize) / 2;
                    int offsetY = (TILE_SIZE - fogataSize) / 2;

                    g.drawImage(fogataImg,
                            GRID_START_X + pos.getX() * TILE_SIZE + offsetX,
                            GRID_START_Y + pos.getY() * TILE_SIZE + offsetY,
                            fogataSize, fogataSize, this);
                }
            }
        } catch (Exception e) {
            logger.logError("Error drawing obstacles", e);
        }
    }


    /**
     * Draws the igloo centered on the grid.
     * @param g Graphics context.
     */
    private void drawIglu(Graphics g) {
        try {
            Image igluImg = new ImageIcon("resources/iglu.png").getImage();
            int igluSize = 96;

            int igluX = GRID_START_X + 7 * TILE_SIZE - igluSize / 2 + TILE_SIZE / 2;
            int igluY = GRID_START_Y + 7 * TILE_SIZE - igluSize / 2 + TILE_SIZE / 2;

            g.drawImage(igluImg, igluX, igluY, igluSize, igluSize, null);
        } catch (Exception e) {
            logger.logError("Error drawing igloo", e);
        }
    }

    /**
     * draws all fruits.
     * for custom levels it shows every fruit from the start,
     * for default levels it keeps the original phase logic.
     */
    private void drawFruits(Graphics g) {
        try {
            for (Fruit fruit : level.getFruits()) {
                if (fruit.isCollected()) continue;

                // en configurados todo de una vez
                if (level.isCustomConfigured()) {
                    drawFruitDefaultStyle(g, fruit);
                    continue;
                }

                int lvl = level.getLevelNumber();

                if (lvl == 1) {
                    // level 1
                    if (bananasPhase && fruit.isBanana()) {
                        drawFruitDefaultStyle(g, fruit);
                    } else if (grapesPhase && fruit.isGrape()) {
                        drawFruitDefaultStyle(g, fruit);
                    }
                } else if (lvl == 2) {
                    // level 2
                    if (bananasPhase && fruit.isBanana()) {
                        drawFruitDefaultStyle(g, fruit);
                    } else if (pineapplesPhase && fruit.isPineapple()) {
                        drawFruitDefaultStyle(g, fruit);
                    }
                } else if (lvl == 3) {
                    // level 3
                    if (bananasPhase && fruit.isCherry()) {
                        drawFruitDefaultStyle(g, fruit);
                    } else if (grapesPhase && fruit.isCactus()) {
                        drawFruitDefaultStyle(g, fruit);
                    }
                }
            }
        } catch (Exception e) {
            logger.logError("Error drawing fruits", e);
        }
    }

    /**
     * draws one fruit with the same scale rules as the old version.
     * bananas, grapes, pineapples and cactus are drawn bigger.
     * cherries stay at normal tile size.
     */
    private void drawFruitDefaultStyle(Graphics g, Fruit fruit) {
        Position pos = fruit.getPosition();

        int bananaFactor = 3;
        int grapeFactor  = 2;

        int w, h;

        if (fruit.isCherry()) {
            w = TILE_SIZE;
            h = TILE_SIZE;
        } else if (fruit.isBanana()) {
            w = TILE_SIZE * bananaFactor;
            h = TILE_SIZE * bananaFactor;
        } else if (fruit.isGrape()) {
            w = TILE_SIZE * grapeFactor;
            h = TILE_SIZE * grapeFactor;
        } else if (fruit.isPineapple() || fruit.isCactus()) {
            w = TILE_SIZE * 2;
            h = TILE_SIZE * 2;
        } else {
            w = TILE_SIZE * 2;
            h = TILE_SIZE * 2;
        }
        Image img;
        if (fruit.isBanana())       img = bananaImg;
        else if (fruit.isGrape())   img = grapeImg;
        else if (fruit.isCherry())  img = cherryImg;
        else if (fruit.isPineapple()) img = pineappleImg;
        else if (fruit.isCactus())  img = cactusImg;
        else                        img = new ImageIcon(fruit.getImagePath()).getImage();

        int drawX = GRID_START_X + pos.getX() * TILE_SIZE - (w - TILE_SIZE) / 2;
        int drawY = GRID_START_Y + pos.getY() * TILE_SIZE - (h - TILE_SIZE) / 2;

        g.drawImage(img, drawX, drawY, w, h, this);
    }

    /**
     * Draws all enemies at their current positions.
     * @param g Graphics context.
     */
    private void drawEnemies(Graphics g) {
        try {
            for (Enemy enemy : level.getEnemies()) {
                Position pos = enemy.getPosition();
                if (pos != null) {
                    Image enemyImg = new ImageIcon(enemy.getImagePath()).getImage();

                    int trollWidth, trollHeight;
                    int offsetX, offsetY;

                    if (enemy.getDirection() == Direction.LEFT || enemy.getDirection() == Direction.RIGHT) {
                        trollWidth = TILE_SIZE + 40;
                        trollHeight = TILE_SIZE + 16;
                    } else if (enemy.getDirection() == Direction.UP || enemy.getDirection() == Direction.DOWN) {
                        trollWidth = TILE_SIZE + 10;
                        trollHeight = TILE_SIZE + 16;
                    } else {
                        trollWidth = TILE_SIZE;
                        trollHeight = TILE_SIZE;
                    }

                    offsetX = (TILE_SIZE - trollWidth) / 2;
                    offsetY = (TILE_SIZE - trollHeight) / 2;

                    g.drawImage(enemyImg,
                            GRID_START_X + pos.getX() * TILE_SIZE + offsetX,
                            GRID_START_Y + pos.getY() * TILE_SIZE + offsetY,
                            trollWidth, trollHeight, null);
                }
            }
        } catch (Exception e) {
            logger.logError("Error drawing enemies", e);
        }
    }

    /**
     * Draws player sprites for player 1 and player 2 (if present).
     * @param g Graphics context.
     */
    private void drawPlayers(Graphics g) {
        try {
            Position p1 = player1.getPosition();
            Image p1Img = new ImageIcon(player1.getImagePath()).getImage();
            g.drawImage(p1Img, GRID_START_X + p1.getX() * TILE_SIZE,
                    GRID_START_Y + p1.getY() * TILE_SIZE, TILE_SIZE, TILE_SIZE, null);

            if (numberOfPlayers == 2 && player2 != null) {
                Position p2 = player2.getPosition();
                Image p2Img = new ImageIcon(player2.getImagePath()).getImage();
                g.drawImage(p2Img, GRID_START_X + p2.getX() * TILE_SIZE,
                        GRID_START_Y + p2.getY() * TILE_SIZE, TILE_SIZE, TILE_SIZE, null);
            }
        } catch (Exception e) {
            logger.logError("Error drawing players", e);
        }
    }

    /**
     * Draws the semi-transparent pause overlay and its buttons.
     * @param g2d Graphics2D context.
     */
    private void drawPauseOverlay(Graphics2D g2d) {
        try {
            g2d.setColor(new Color(0, 0, 0, 180));
            g2d.fillRect(0, 0, 640, 720);

            int centerX = getWidth() / 2;

            Image pausedImg = new ImageIcon("resources/paused.png").getImage();
            int pausedW = 320;
            int pausedH = (int) (pausedImg.getHeight(this)
                    * (pausedW / (double) pausedImg.getWidth(this)));
            int pausedX = centerX - pausedW / 2;
            int pausedY = 120;
            g2d.drawImage(pausedImg, pausedX, pausedY, pausedW, pausedH, this);

            int btnW = 240;
            int btnH = 70;
            int contX = centerX - btnW / 2;

            Image continueImg = new ImageIcon("resources/continue.png").getImage();
            int contY = pausedY + pausedH + 20;
            g2d.drawImage(continueImg, contX, contY, btnW, btnH, this);

            Image restartPauseImg = new ImageIcon("resources/restart2.png").getImage();
            int restY = contY + btnH + 10;
            g2d.drawImage(restartPauseImg, contX, restY, btnW, btnH, this);

            Image exitPauseImg = new ImageIcon("resources/exit2.png").getImage();
            int exitY = restY + btnH + 10;
            g2d.drawImage(exitPauseImg, contX, exitY, btnW, btnH, this);

            Image trespImg = new ImageIcon("resources/tresp.png").getImage();
            trespW = 80;   // <-- aquí pones el ancho
            trespH = 30;   // <-- aquí pones el alto

            trespX = centerX - trespW / 2;
            trespY = exitY + btnH + 20;
            g2d.drawImage(trespImg, trespX, trespY, trespW, trespH, this);

        } catch (Exception e) {
            logger.logError("Error drawing pause overlay", e);
        }
    }

    /**
     * Draws the game-over or victory overlay, scores and winner flavor gif.
     * Shows the human winner's name, or tie, always with images not raw text.
     * @param g2d Graphics2D context.
     */
    private void drawGameOverOverlay(Graphics2D g2d) {
        try {
            g2d.setColor(new Color(0, 0, 0, 220));
            g2d.fillRect(0, 0, 640, 720);

            int centerX = getWidth() / 2;
            int bannerY = 70;

            // 1 jugador
            if (numberOfPlayers == 1) {
                if (victory && victoryGif != null) {
                    int targetW = 420;
                    int targetH = (int) (victoryGif.getHeight(this)
                            * (targetW / (double) victoryGif.getWidth(this)));
                    int drawX = centerX - targetW / 2;
                    g2d.drawImage(victoryGif, drawX, bannerY, targetW, targetH, this);

                    // Mostrar nombre del jugador humano ganador
                    if (winnerPlayer != null) {
                        String winnerName = winnerPlayer.getName();
                        g2d.setColor(Color.WHITE);
                        g2d.setFont(new Font("Arial", Font.BOLD, 32));
                        int stringWidth = g2d.getFontMetrics().stringWidth(winnerName);
                        g2d.drawString(winnerName, centerX - stringWidth / 2, bannerY + targetH + 40);
                    }
                } else {
                    Image gameOverImg = new ImageIcon("resources/gameover.png").getImage();
                    int targetW = 420;
                    int targetH = (int) (gameOverImg.getHeight(this)
                            * (targetW / (double) gameOverImg.getWidth(this)));
                    int drawX = centerX - targetW / 2;
                    g2d.drawImage(gameOverImg, drawX, bannerY, targetW, targetH, this);
                }
            }
            // 2 jugadores
            else {
                Image winImg = null;
                if (winnerPlayerIndex == 1 && p1WinImg != null) winImg = p1WinImg;
                else if (winnerPlayerIndex == 2 && p2WinImg != null) winImg = p2WinImg;

                if (winImg != null) {
                    int targetW = 380;
                    int targetH = (int) (winImg.getHeight(this)
                            * (targetW / (double) winImg.getWidth(this)));
                    int drawX = centerX - targetW / 2;
                    g2d.drawImage(winImg, drawX, bannerY, targetW, targetH, this);

                    // Mostrar el nombre del jugador humano ganador debajo de la imagen
                    if (winnerPlayer != null && winnerPlayer.getName() != null) {
                        String winnerName = winnerPlayer.getName();
                        g2d.setColor(Color.WHITE);
                        g2d.setFont(new Font("Arial", Font.BOLD, 32));
                        int stringWidth = g2d.getFontMetrics().stringWidth(winnerName);
                        g2d.drawString(winnerName, centerX - stringWidth / 2, bannerY + targetH + 40);
                    }
                } else {
                    // Imagen de empate siempre que no haya winImg
                    Image tieImg = new ImageIcon("resources/tie.png").getImage();
                    if (tieImg != null) {
                        int targetW = 380;
                        int targetH = (int) (tieImg.getHeight(this)
                                * (targetW / (double) tieImg.getWidth(this)));
                        int drawX = centerX - targetW / 2;
                        g2d.drawImage(tieImg, drawX, bannerY, targetW, targetH, this);
                    }
                }
            }

            int scoreY = 320;
            int scoreBoxW = 220;
            int scoreBoxH = 40;
            int scoreBoxX = centerX - scoreBoxW / 2;
            int scoreBoxY = scoreY - scoreBoxH + 5;

            g2d.setColor(new Color(40, 90, 180));
            g2d.fillRoundRect(scoreBoxX, scoreBoxY, scoreBoxW, scoreBoxH, 15, 15);
            g2d.setColor(Color.BLACK);
            g2d.drawRoundRect(scoreBoxX, scoreBoxY, scoreBoxW, scoreBoxH, 15, 15);

            g2d.setFont(new Font("Arial", Font.BOLD, 20));
            g2d.setColor(Color.BLACK);
            if (numberOfPlayers == 1) {
                String txt = "Score: " + manager.getScorePlayer1();
                int txtW = g2d.getFontMetrics().stringWidth(txt);
                g2d.drawString(txt, centerX - txtW / 2, scoreY);
            } else {
                String txt1 = player1 != null && player1.getName() != null
                        ? player1.getName() + ": " + manager.getScorePlayer1()
                        : "P1: " + manager.getScorePlayer1();
                String txt2 = player2 != null && player2.getName() != null
                        ? player2.getName() + ": " + manager.getScorePlayer2()
                        : "P2: " + manager.getScorePlayer2();
                int txt1W = g2d.getFontMetrics().stringWidth(txt1);
                int txt2W = g2d.getFontMetrics().stringWidth(txt2);
                g2d.drawString(txt1, centerX - txt1W - 10, scoreY);
                g2d.drawString(txt2, centerX + 10, scoreY);
            }

            int buttonsY = 370;
            int buttonW = 120;
            int buttonH = 50;

            Image restartBtnImg = new ImageIcon("resources/restart.png").getImage();
            g2d.drawImage(restartBtnImg, 180, buttonsY, buttonW, buttonH, this);

            Image exitBtnImg = new ImageIcon("resources/exit.png").getImage();
            g2d.drawImage(exitBtnImg, 340, buttonsY, buttonW, buttonH, this);

            // NUEVO: Botón Next Level (solo si hay victoria)
            if (victory) {
                try {
                    Image nextLevelImg = new ImageIcon("resources/nextlevel.png").getImage();
                    nextLevelW = 140;
                    nextLevelH = 60;
                    nextLevelX = getWidth() - nextLevelW - 20; // Esquina inferior derecha
                    nextLevelY = getHeight() - nextLevelH - 20;
                    g2d.drawImage(nextLevelImg, nextLevelX, nextLevelY, nextLevelW, nextLevelH, this);
                } catch (Exception e) {
                    logger.logError("Error drawing next level button", e);
                }
            }

            // Gif del sabor ganador
            if (winnerPlayer != null) {
                Image flavorGif = null;
                String fl = winnerPlayer.getFlavor();
                boolean isMachine = winnerPlayer.isMachine();

                if ("vanilla".equals(fl)) {
                    flavorGif = isMachine ? vanillaMWinGif : vanillaWinGif;
                } else if ("strawberry".equals(fl)) {
                    flavorGif = isMachine ? strawberryMWinGif : strawberryWinGif;
                } else if ("chocolate".equals(fl)) {
                    flavorGif = isMachine ? chocolateMWinGif : chocolateWinGif;
                }

                if (flavorGif != null) {
                    int targetH = 120;
                    int drawY = 440;
                    if ("chocolate".equals(fl)) {
                        targetH = 200;
                        drawY = 410;
                    }
                    int targetW = (int) (flavorGif.getWidth(this)
                            * (targetH / (double) flavorGif.getHeight(this)));
                    int drawX = centerX - targetW / 2;
                    g2d.drawImage(flavorGif, drawX, drawY, targetW, targetH, this);
                }
            }
        } catch (Exception e) {
            logger.logError("Error drawing game over overlay", e);
        }
    }

    /**
     * Main update cycle: delegates to BadIceCream (domain logic) and handles results.
     * Called on every game tick by {@link #gameTimer}.
     */
    private void updateGame() {
        try {
            // Delegar toda la lógica a BadIceCream de dominio
            gameLogic.update();

            // Sincronizar variables de fase para el HUD
            this.bananasPhase = gameLogic.isBananasPhase();
            this.grapesPhase = gameLogic.isGrapesPhase();
            this.pineapplesPhase = gameLogic.isPineapplesPhase();

            // Verificar si el juego terminó
            if (gameLogic.isGameOver()) {
                this.gameOver = true;
                this.winnerPlayerIndex = gameLogic.getWinnerPlayerIndex();
                this.winnerPlayer = gameLogic.getWinnerPlayer();
                this.victory = gameLogic.isVictory();
                endGame(victory);
            }

        } catch (Exception e) {
            logger.logError("Error in updateGame", e);
        }
    }

    /**
     * Checks if the given position is inside bounds, not inside igloo area
     * and not occupied by a block.
     * @param pos grid position to check.
     * @return true if the cell can be occupied; false otherwise.
     */
    private boolean canMoveToPosition(Position pos) {
        try {
            if (pos.getX() < 0 || pos.getX() >= GRID_WIDTH || pos.getY() < 0 || pos.getY() >= GRID_HEIGHT)
                return false;
            if (isIgluPosition(pos)) return false;

            Block block = level.getMap().getBlock(pos.getX(), pos.getY());

            // Permitir moverse sobre fogatas
            if (block != null && block.isFogata()) {
                return true;
            }

            // Verificar si hay hielo sobre fogata
            for (Position icePos : iceOnCampfires) {
                if (icePos.equals(pos)) {
                    return false;
                }
            }

            return block == null;
        } catch (Exception e) {
            logger.logError("Error checking if can move to position", e);
            return false;
        }
    }

    /**
     * Finishes the game, stops timers and marks victory or defeat.
     * @param won true if the player(s) won, false otherwise.
     */
    private void endGame(boolean won) {
        try {
            if (!gameOver) {
                gameOver = true;
                victory = won;
                gameTimer.stop();
                secondTimer.stop();
                if (aiTimer1 != null) aiTimer1.stop();
                if (aiTimer2 != null) aiTimer2.stop();

                logger.logInfo("Game Ended");
                logger.logInfo("Victory: " + won);
                logger.logInfo("P1 Score: " + manager.getScorePlayer1());
                if (numberOfPlayers == 2) {
                    logger.logInfo("P2 Score: " + manager.getScorePlayer2());
                }
                logger.logInfo("Winner: Player " + winnerPlayerIndex);

                repaint();
            }
        } catch (Exception e) {
            logger.logError("Error ending game", e);
        }
    }

    /**
     * Checks if the position is inside the igloo's 3x3 blocked area.
     * @param pos position to test.
     * @return true if the igloo should block this cell.
     */
    private boolean isIgluPosition(Position pos) {
        int dx = Math.abs(pos.getX() - 7);
        int dy = Math.abs(pos.getY() - 7);
        return dx <= 1 && dy <= 1;
    }

    /**
     * Moves an AI-controlled player using its machine profile strategy.
     * @param aiPlayer AI player to move.
     */
    private void moveAI(Player aiPlayer) {
        try {
            if (aiPlayer == null || aiPlayer.getMachineProfile() == null) {
                logger.logWarning("AI player or machine profile is null");
                return;
            }

            Machine profile = aiPlayer.getMachineProfile();
            Direction bestDir = profile.getNextMove(aiPlayer, level);

            aiPlayer.setDirection(bestDir);
            Position from = new Position(aiPlayer.getPosition().getX(), aiPlayer.getPosition().getY());
            Position next = aiPlayer.getPosition().getNextPosition(bestDir);

            if (canMoveToPosition(next)) {
                aiPlayer.move(bestDir);

                int playerNum = (aiPlayer == player1) ? 1 : 2;
                logger.logGameEvent("AI Player " + playerNum + " (" + profile.getProfileType() +
                        ") moved from (" + from.getX() + "," + from.getY() +
                        ") to (" + next.getX() + "," + next.getY() + ")");
            }

            if (profile.shouldPerformAction(aiPlayer, level)) {
                handleAction(aiPlayer);
            }

        } catch (BadIceCreamException e) {
            logger.logError("Error in AI movement (BadIceCreamException)", e);
        } catch (Exception e) {
            logger.logError("Unexpected error in AI movement", e);
        }

        repaint();
    }

    /**
     * Handles the action key for blowing or breaking ice depending on the next cell.
     * @param player player performing the action.
     */
    private void handleAction(Player player) {
        try {
            Position next = player.getPosition().getNextPosition(player.getDirection());
            Block block = level.getMap().getBlock(next.getX(), next.getY());

            int playerNum = (player == player1) ? 1 : 2;

            if (block != null && block.isIce()) {
                player.setState(PlayerState.ANGRY);
                breakIceLine(player);
                logger.logGameEvent("Player " + playerNum + " broke ice line starting at (" +
                        next.getX() + "," + next.getY() + ")");
            } else {
                player.setState(PlayerState.BLOWING);
                createIceLine(player);
                logger.logGameEvent("Player " + playerNum + " created ice line starting at (" +
                        next.getX() + "," + next.getY() + ")");
            }

            Timer resetTimer = new Timer(300, e -> player.setState(PlayerState.NORMAL));
            resetTimer.setRepeats(false);
            resetTimer.start();

        } catch (Exception e) {
            logger.logError("Error handling player action", e);
        }
    }

    /**
     * Creates a line of ice blocks from the player forward until an obstacle.
     * Ice blocks melt after 2 seconds on hot tiles.
     * @param player player that blows ice.
     */
    private void createIceLine(Player player) {
        try {
            Position current = player.getPosition().getNextPosition(player.getDirection());
            int blocksCreated = 0;

            while (level.getMap().isValidPosition(current)) {
                Block existing = level.getMap().getBlock(current.getX(), current.getY());

                // Si es fogata, poner hielo encima (capa separada)
                if (existing != null && existing.isFogata()) {
                    if (!iceOnCampfires.contains(current)) {
                        iceOnCampfires.add(new Position(current.getX(), current.getY()));
                        blocksCreated++;
                    }
                    current = current.getNextPosition(player.getDirection());
                    continue;
                }

                // Si hay otro bloque (que no sea fogata), parar
                if (existing != null || isIgluPosition(current)) {
                    break;
                }

                // Crear el hielo
                level.getMap().addIceBlock(current);
                blocksCreated++;

                // Verificar si hay baldosa caliente debajo
                if (level.getMap().hasBaldosaCaliente(current)) {
                    final Position icePos = new Position(current.getX(), current.getY());

                    // Programar derretimiento después de 2 segundos
                    Timer meltTimer = new Timer(2000, new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            try {
                                level.getMap().removeBlock(icePos);
                                repaint();
                                logger.logDebug("Ice melted on hot tile at (" + icePos.getX() + "," + icePos.getY() + ")");
                            } catch (Exception ex) {
                                logger.logError("Error melting ice", ex);
                            }
                        }
                    });
                    meltTimer.setRepeats(false);
                    meltTimer.start();

                    logger.logDebug("Ice will melt in 2 seconds at (" + icePos.getX() + "," + icePos.getY() + ")");
                }

                current = current.getNextPosition(player.getDirection());
            }

            if (blocksCreated > 0) {
                logger.logDebug("Created " + blocksCreated + " ice blocks");
            }

        } catch (BadIceCreamException e) {
            logger.logError("Error creating ice line", e);
        } catch (Exception e) {
            logger.logError("Unexpected error creating ice line", e);
        }
    }

    /**
     * Shows a short breaking animation and removes a line of ice blocks.
     * Extinguishes campfires when ice on them is broken.
     * @param player player that breaks the ice line.
     */
    private void breakIceLine(Player player) {
        try {
            if (showingBreaking) return;

            breakingLine.clear();
            Position current = player.getPosition().getNextPosition(player.getDirection());

            while (level.getMap().isValidPosition(current)) {
                // Verificar si hay hielo sobre fogata
                boolean hasIceOnCampfire = false;
                for (Position icePos : iceOnCampfires) {
                    if (icePos.equals(current)) {
                        breakingLine.add(new Position(current.getX(), current.getY()));
                        hasIceOnCampfire = true;
                        break;
                    }
                }

                if (hasIceOnCampfire) {
                    current = current.getNextPosition(player.getDirection());
                    continue;
                }

                // Verificar hielo normal
                Block existing = level.getMap().getBlock(current.getX(), current.getY());
                if (existing != null && existing.isIce()) {
                    breakingLine.add(new Position(current.getX(), current.getY()));
                    current = current.getNextPosition(player.getDirection());
                } else {
                    break;
                }
            }

            if (breakingLine.isEmpty()) return;

            showingBreaking = true;

            Timer animTimer = new Timer(200, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    for (Position pos : breakingLine) {
                        // Remover hielo sobre fogata
                        boolean removed = false;
                        for (int i = 0; i < iceOnCampfires.size(); i++) {
                            if (iceOnCampfires.get(i).equals(pos)) {
                                iceOnCampfires.remove(i);
                                removed = true;

                                // Apagar fogata
                                for (Fogata fogata : level.getMap().getFogatas()) {
                                    if (fogata.getPosition().equals(pos)) {
                                        fogata.extinguish();
                                        logger.logDebug("Campfire extinguished at (" + pos.getX() + "," + pos.getY() + ")");
                                    }
                                }
                                break;
                            }
                        }

                        // Si no era hielo sobre fogata, remover hielo normal
                        if (!removed) {
                            try {
                                level.getMap().removeBlock(pos);
                            } catch (BadIceCreamException ex) {
                                logger.logError("Error removing ice block", ex);
                            }
                        }
                    }
                    breakingLine.clear();
                    showingBreaking = false;
                    repaint();
                }
            });
            animTimer.setRepeats(false);
            animTimer.start();

        } catch (Exception e) {
            logger.logError("Error breaking ice line", e);
            showingBreaking = false;
        }
    }

    /**
     * Attempts to move the given player one cell in the specified direction.
     * @param player player to move.
     * @param dir    direction to move.
     */
    private void movePlayer(Player player, Direction dir) {
        try {
            player.setDirection(dir);
            Position from = new Position(player.getPosition().getX(), player.getPosition().getY());
            Position next = player.getPosition().getNextPosition(dir);

            if (canMoveToPosition(next)) {
                player.move(dir);

                int playerNum;
                if (player == player1) {
                    playerNum = 1;
                } else {
                    playerNum = 2;
                }

                logger.logGameEvent("Player " + playerNum + " moved from (" + from.getX() + "," +
                        from.getY() + ") to (" + next.getX() + "," + next.getY() + ")");

                // Mover piñas aleatoriamente cuando el jugador se mueve
                for (Fruit fruit : level.getFruits()) {
                    if (fruit.isPineapple() && !fruit.isCollected()) {
                        Pineapple pineapple = (Pineapple) fruit;
                        try {
                            pineapple.moveRandomly(level.getMap());
                        } catch (BadIceCreamException e) {
                            logger.logError("Error moving pineapple", e);
                        }
                    }
                }
            }
        } catch (BadIceCreamException ex) {
            logger.logError("Error moving player", ex);
        } catch (Exception ex) {
            logger.logError("Unexpected error moving player", ex);
        }
    }


    /**
     * Stops all game timers.
     */
    private void stopTimers() {
        if (gameTimer != null) {
            gameTimer.stop();
        }
        if (secondTimer != null) {
            secondTimer.stop();
        }
        if (aiTimer1 != null) {
            aiTimer1.stop();
        }
        if (aiTimer2 != null) {
            aiTimer2.stop();
        }
    }

    /**
     * Handles keyboard input for both players and pause commands.
     * @param e key event.
     */
    @Override
    public void keyPressed(KeyEvent e) {
        try {
            if (gameOver) return;

            if (e.getKeyCode() == KeyEvent.VK_P) {
                paused = !paused;
                logger.logInfo("Game " + (paused ? "paused" : "resumed"));
                repaint();
                return;
            }

            if (paused && e.getKeyCode() == KeyEvent.VK_SPACE) {
                paused = false;
                logger.logInfo("Game resumed via SPACE");
                repaint();
                return;
            }
            if (paused && e.getKeyCode() == KeyEvent.VK_R) {
                logger.logInfo("Restart requested from pause menu");
                paused = false;
                gameTimer.stop();
                secondTimer.stop();
                if (aiTimer1 != null) aiTimer1.stop();
                if (aiTimer2 != null) aiTimer2.stop();
                parent.restartGame();
                return;
            }
            if (paused && e.getKeyCode() == KeyEvent.VK_E) {
                logger.logInfo("Exit to menu requested from pause");
                paused = false;
                gameTimer.stop();
                secondTimer.stop();
                if (aiTimer1 != null) aiTimer1.stop();
                if (aiTimer2 != null) aiTimer2.stop();
                parent.showMenu();
                return;
            }

            if (paused) return;

            switch (e.getKeyCode()) {
                case KeyEvent.VK_UP:
                    movePlayer(player1, Direction.UP);
                    break;
                case KeyEvent.VK_DOWN:
                    movePlayer(player1, Direction.DOWN);
                    break;
                case KeyEvent.VK_LEFT:
                    movePlayer(player1, Direction.LEFT);
                    break;
                case KeyEvent.VK_RIGHT:
                    movePlayer(player1, Direction.RIGHT);
                    break;
                case KeyEvent.VK_SPACE:
                    handleAction(player1);
                    repaint();
                    return;
            }

            if (numberOfPlayers == 2 && "PvP".equals(gameMode) && player2 != null) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_W:
                        movePlayer(player2, Direction.UP);
                        break;
                    case KeyEvent.VK_S:
                        movePlayer(player2, Direction.DOWN);
                        break;
                    case KeyEvent.VK_A:
                        movePlayer(player2, Direction.LEFT);
                        break;
                    case KeyEvent.VK_D:
                        movePlayer(player2, Direction.RIGHT);
                        break;
                    case KeyEvent.VK_SHIFT:
                        handleAction(player2);
                        repaint();
                        return;
                }
            }

            repaint();

        } catch (Exception ex) {
            logger.logError("Error handling key press", ex);
        }
    }

    /**
     * Not used; required by KeyListener.
     */
    @Override
    public void keyReleased(KeyEvent e) {
    }

    /**
     * Not used; required by KeyListener.
     */
    @Override
    public void keyTyped(KeyEvent e) {
    }

    /**
     * Handles mouse clicks on pause and game-over overlays (continue, restart, exit).
     * @param e mouse click event.
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        try {
            int x = e.getX();
            int y = e.getY();

            if (paused) {

               if (x >= trespX && x <= trespX + trespW &&
                        y >= trespY && y <= trespY + trespH) {

                    showSaveMenu = !showSaveMenu;  // abrir/cerrar el menú
                    repaint();
                    return;
                }

                if (showSaveMenu) {
                    menuX = trespX - 60;  // Centrado respecto al botón tresp
                    menuY = trespY + trespH + 10;  // Debajo del botón tresp
                    menuW = 200;
                    menuH = 120;

                    // opción Abrir
                    if (x >= menuX && x <= menuX + menuW &&
                            y >= menuY && y <= menuY + 60) {

                        logger.logInfo("Abrir partida clicked");
                        showSaveMenu = false;  // Cerrar el menú
                        abrirPartida();
                        repaint();
                        return;
                    }

                    // opción Salvar
                    if (x >= menuX && x <= menuX + menuW &&
                            y >= menuY + 60 && y <= menuY + 120) {

                        logger.logInfo("Salvar partida clicked");
                        showSaveMenu = false;  // Cerrar el menú
                        salvarPartida();
                        repaint();
                        return;
                    }
                    // Dentro de mouseClicked
                    if (showSaveMenu) {
                        menuW = 200;
                        menuH = 120;
                        menuX = trespX - 60;
                        menuY = trespY - menuH - 10;   // igual que en showFileMenu

                        // Abrir
                        if (x >= menuX && x <= menuX + menuW &&
                                y >= menuY && y <= menuY + 60) {
                            logger.logInfo("Abrir partida clicked");
                            showSaveMenu = false;
                            abrirPartida();
                            repaint();
                            return;
                        }

                        // Salvar
                        if (x >= menuX && x <= menuX + menuW &&
                                y >= menuY + 60 && y <= menuY + 120) {
                            logger.logInfo("Salvar partida clicked");
                            showSaveMenu = false;
                            salvarPartida();
                            repaint();
                            return;
                        }
                    }


                }


                if (x >= 200 && x <= 440 && y >= 220 && y <= 290) {
                    paused = false;
                    logger.logInfo("Continue clicked from pause menu");
                    repaint();
                    return;
                }
                if (x >= 200 && x <= 440 && y >= 300 && y <= 370) {
                    logger.logInfo("Restart clicked from pause menu");
                    paused = false;
                    gameTimer.stop();
                    secondTimer.stop();
                    if (aiTimer1 != null) aiTimer1.stop();
                    if (aiTimer2 != null) aiTimer2.stop();
                    parent.restartGame();
                    return;
                }
                if (x >= 200 && x <= 440 && y >= 380 && y <= 450) {
                    logger.logInfo("Exit clicked from pause menu");
                    paused = false;
                    gameTimer.stop();
                    secondTimer.stop();
                    if (aiTimer1 != null) aiTimer1.stop();
                    if (aiTimer2 != null) aiTimer2.stop();
                    parent.showMenu();
                    return;
                }
            }

            if (gameOver) {
                if (x >= 180 && x <= 300 && y >= 370 && y <= 420) {
                    logger.logInfo("Restart clicked from game over screen");
                    parent.restartGame();
                    return;
                }
                if (x >= 340 && x <= 460 && y >= 370 && y <= 420) {
                    logger.logInfo("Exit clicked from game over screen");
                    gameTimer.stop();
                    secondTimer.stop();
                    if (aiTimer1 != null) aiTimer1.stop();
                    if (aiTimer2 != null) aiTimer2.stop();
                    parent.showMenu();
                    return;
                }

                if (victory && x >= nextLevelX && x <= nextLevelX + nextLevelW &&
                        y >= nextLevelY && y <= nextLevelY + nextLevelH) {
                        logger.logInfo("Next Level clicked from victory screen");
                        goToNextLevel();
                        return;
                }

            }

        } catch (Exception ex) {
            logger.logError("Error handling mouse click", ex);
        }
    }

    /**
     * Advances to the next level if available, otherwise shows a message.
     */
    private void goToNextLevel() {
        try {
            int currentLevel = level.getLevelNumber();
            int nextLevel = currentLevel + 1;

            // Verificar si existe el siguiente nivel (asumiendo que hay 3 niveles)
            if (nextLevel > 3) {
                logger.logInfo("No next level available");
                JOptionPane.showMessageDialog(this,
                        "¡Felicidades! Has completado todos los niveles.",
                        "Juego Completado",
                        JOptionPane.INFORMATION_MESSAGE);

                // Volver al menú principal
                stopTimers();
                parent.showMenu();
                return;
            }

            // Detener timers actuales
            stopTimers();

            logger.logInfo("Advancing to level " + nextLevel);

            // Llamar al método del parent para cargar el siguiente nivel
            parent.loadNextLevel(nextLevel);

        } catch (Exception e) {
            logger.logError("Error advancing to next level", e);
            JOptionPane.showMessageDialog(this,
                    "Error al cargar el siguiente nivel: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Opens a previously saved level file and loads it into the game.
     * Lets the user choose a file with a file chooser, restores the level,
     * repositions the players to the correct start positions for that level,
     * resets game state flags, and restarts the game logic with the loaded level.
     */
    private void abrirPartida() {
        try {
            JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Abrir nivel");
            if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                java.io.File file = fc.getSelectedFile();

                Level loaded = SaveSystem.openLevel(file);
                this.level = loaded;

                try {
                    Position p1start = Levels.getPlayer1Start(loaded.getLevelNumber());
                    player1.setPosition(p1start);

                    if (numberOfPlayers == 2 && player2 != null) {
                        Position p2start = Levels.getPlayer2Start(loaded.getLevelNumber());
                        player2.setPosition(p2start);
                    }
                } catch (Exception ex) {
                    logger.logWarning("Could not reposition players: " + ex.getMessage());
                }

                if (aiTimer1 != null) aiTimer1.stop();
                if (aiTimer2 != null) aiTimer2.stop();

                this.gameLogic = new BadIceCream(player1, player2, numberOfPlayers, loaded);
                this.manager = gameLogic.getGameManager();

                this.bananasPhase = gameLogic.isBananasPhase();
                this.grapesPhase = gameLogic.isGrapesPhase();
                this.pineapplesPhase = gameLogic.isPineapplesPhase();

                loaded.setCustomConfigured(true);

                this.gameOver = false;
                this.victory = false;
                this.paused = false;
                this.showSaveMenu = false;

                repaint();
                logger.logInfo("Nivel cargado desde: " + file.getAbsolutePath());
            }
        } catch (Exception ex) {
            logger.logError("Error al abrir el nivel", ex);
            JOptionPane.showMessageDialog(this,
                    "Error al abrir el nivel: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }


    /**
     * Saves the current level configuration to a text file.
     * Opens a save dialog, ensures the file has a .txt extension,
     * and delegates the serialization of the level to the SaveSystem utility.
     */
    private void salvarPartida() {
        try {
            JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Guardar nivel");
            if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                java.io.File file = fc.getSelectedFile();
                if (!file.getName().toLowerCase().endsWith(".txt")) {
                    file = new java.io.File(file.getAbsolutePath() + ".txt");
                }

                SaveSystem.saveLevel(this.level, file);
                System.out.println("Nivel guardado en: " + file.getAbsolutePath());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.err.println("Error al guardar el nivel: " + ex.getMessage());
        }
    }

    /**
     * Draws the file menu overlay (Open/Save options) on top of the game screen.
     * Only renders the menu when the flag showSaveMenu is true, positions it
     * above the three-dots button, and draws two options: "Abrir" and "Salvar".
     */
    private void showFileMenu(Graphics g) {
        if (!showSaveMenu) return;

        menuW = 200;
        menuH = 120;

        // Mueve el menú hacia ARRIBA del botón tresp
        menuX = trespX - 60;
        menuY = trespY - menuH - 10;

        g.setColor(new Color(0, 0, 0, 200));
        g.fillRoundRect(menuX, menuY, menuW, menuH, 15, 15);

        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 22));
        g.drawString("Abrir",  menuX + 70, menuY + 40);
        g.drawString("Salvar", menuX + 70, menuY + 100);
    }


    /**
     * Not used; required by MouseListener.
     */
    @Override
    public void mousePressed(MouseEvent e) {
    }

    /**
     * Not used; required by MouseListener.
     */
    @Override
    public void mouseReleased(MouseEvent e) {
    }

    /**
     * Not used; required by MouseListener.
     */
    @Override
    public void mouseEntered(MouseEvent e) {
    }

    /**
     * Not used; required by MouseListener.
     */
    @Override
    public void mouseExited(MouseEvent e) {
    }

}
