package presentation;

import javax.swing.*;
import java.awt.*;

/**
 * Panel for selecting the number of players (1 or 2).
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class PlayerCountPanel extends JPanel {

    private BadIceCreamGUI parent;

    /**
     * Constructs the player count selection panel with UI elements,
     * player icons, and buttons for 1-player, 2-player, and Back actions.
     * @param parent Reference to the main game window to control screen changes.
     */
    public PlayerCountPanel(BadIceCreamGUI parent) {
        this.parent = parent;
        setLayout(null);
        setPreferredSize(new Dimension(640, 640));

        ImageIcon bgIcon = new ImageIcon("resources/fondo.gif");
        Image bgImage = bgIcon.getImage().getScaledInstance(640, 640, Image.SCALE_DEFAULT);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setLayout(null);
        backgroundLabel.setBounds(0, 0, 640, 640);
        add(backgroundLabel);

        ImageIcon cuadroIcon1 = new ImageIcon("resources/boton3.png");
        Image cuadroImg1 = cuadroIcon1.getImage().getScaledInstance(640, 300, Image.SCALE_SMOOTH);
        JLabel topPanel = new JLabel(new ImageIcon(cuadroImg1));
        topPanel.setLayout(null);
        topPanel.setBounds(0, 80, 640, 300);
        backgroundLabel.add(topPanel);

        ImageIcon titleIcon = new ImageIcon("resources/howmany.png");
        Image titleImg = titleIcon.getImage().getScaledInstance(300, 45, Image.SCALE_SMOOTH);
        JLabel titleLabel = new JLabel(new ImageIcon(titleImg));
        titleLabel.setBounds((640 - 300) / 2, 35, 300, 45);
        topPanel.add(titleLabel);

        ImageIcon iceIcon1 = new ImageIcon("resources/heladovainilla.png");
        Image iceImg1 = iceIcon1.getImage().getScaledInstance(130, 130, Image.SCALE_SMOOTH);
        JLabel iceLabel1 = new JLabel(new ImageIcon(iceImg1));
        iceLabel1.setBounds(110, 80, 130, 130);
        topPanel.add(iceLabel1);

        ImageIcon p1Icon = new ImageIcon("resources/player1.png");
        Image p1Img = p1Icon.getImage().getScaledInstance(110, 40, Image.SCALE_SMOOTH);
        JLabel p1Label = new JLabel(new ImageIcon(p1Img));
        p1Label.setBounds(110, 215, 110, 40);
        topPanel.add(p1Label);

        // 1 jugador
        JButton onePlayerBtn = new JButton();
        onePlayerBtn.setBounds(110, 80, 130, 175);
        onePlayerBtn.setOpaque(false);
        onePlayerBtn.setContentAreaFilled(false);
        onePlayerBtn.setBorderPainted(false);
        onePlayerBtn.addActionListener(e -> parent.showLevelSelection(1));
        topPanel.add(onePlayerBtn);

        ImageIcon iceIcon2 = new ImageIcon("resources/doshelados.png");
        Image iceImg2 = iceIcon2.getImage().getScaledInstance(130, 130, Image.SCALE_SMOOTH);
        JLabel iceLabel2 = new JLabel(new ImageIcon(iceImg2));
        iceLabel2.setBounds(400, 80, 130, 130);
        topPanel.add(iceLabel2);

        ImageIcon p2Icon = new ImageIcon("resources/player2.png");
        Image p2Img = p2Icon.getImage().getScaledInstance(110, 40, Image.SCALE_SMOOTH);
        JLabel p2Label = new JLabel(new ImageIcon(p2Img));
        p2Label.setBounds(400, 215, 110, 40);
        topPanel.add(p2Label);

        // 2 jugadores
        JButton twoPlayersBtn = new JButton();
        twoPlayersBtn.setBounds(400, 80, 130, 175);
        twoPlayersBtn.setOpaque(false);
        twoPlayersBtn.setContentAreaFilled(false);
        twoPlayersBtn.setBorderPainted(false);
        twoPlayersBtn.addActionListener(e -> parent.showLevelSelection(2));
        topPanel.add(twoPlayersBtn);

        // devolverse
        ImageIcon backIcon = new ImageIcon("resources/back.png");
        Image backImg = backIcon.getImage().getScaledInstance(80, 40, Image.SCALE_SMOOTH);
        JButton backButton = new JButton(new ImageIcon(backImg));
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setFocusPainted(false);
        backButton.setBounds(20, 20, 80, 40);
        backButton.addActionListener(e -> parent.showMenu());
        backgroundLabel.add(backButton);
    }
}
