package presentation;

import javax.swing.*;
import java.awt.*;

/**
 * Panel that allows the user to choose the game level.
 * Displays options for Level 1, Level 2, Level 3, and More Levels.
 * Levels 1, 2, and 3 are functional; More Levels shows "under construction" message.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class LevelSelectionPanel extends JPanel {

    private BadIceCreamGUI parent;

    /**
     * Builds the level selection panel.
     * @param parent main application window that controls screen changes.
     */
    public LevelSelectionPanel(BadIceCreamGUI parent) {
        this.parent = parent;
        setLayout(null);
        setPreferredSize(new Dimension(640, 640));

        // fondo
        ImageIcon bgIcon = new ImageIcon("resources/fondo.gif");
        Image bgImage = bgIcon.getImage().getScaledInstance(640, 640, Image.SCALE_DEFAULT);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setLayout(null);
        backgroundLabel.setBounds(0, 0, 640, 640);
        add(backgroundLabel);

        // titulo "Choose Level"
        ImageIcon titleIcon = new ImageIcon("resources/chooseLevel.png");
        Image titleImg = titleIcon.getImage().getScaledInstance(420, 80, Image.SCALE_SMOOTH);
        JLabel titleLabel = new JLabel(new ImageIcon(titleImg));
        titleLabel.setBounds((640 - 420) / 2, 50, 420, 80);
        backgroundLabel.add(titleLabel);

        // tamano fijo para Level 1, 2 y 3
        int levelWidth = 320;
        int levelHeight = 65;
        int centerX = (640 - levelWidth) / 2;

        // Level 1 - clickeable
        ImageIcon level1Icon = new ImageIcon("resources/level1.png");
        Image level1Img = level1Icon.getImage().getScaledInstance(levelWidth, levelHeight, Image.SCALE_SMOOTH);
        JLabel level1Label = new JLabel(new ImageIcon(level1Img));
        level1Label.setBounds(centerX, 160, levelWidth, levelHeight);
        level1Label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        level1Label.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                // guardar el nivel y mostrar la configuracion visual de ese mapa
                parent.setSelectedLevel(1);
                parent.showLevelConfig();
            }
        });
        backgroundLabel.add(level1Label);

        // Level 2 - clickeable
        ImageIcon level2Icon = new ImageIcon("resources/level2.png");
        Image level2Img = level2Icon.getImage().getScaledInstance(levelWidth, levelHeight, Image.SCALE_SMOOTH);
        JLabel level2Label = new JLabel(new ImageIcon(level2Img));
        level2Label.setBounds(centerX, 240, levelWidth, levelHeight);
        level2Label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        level2Label.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                // guardar el nivel y mostrar la configuracion visual de ese mapa
                parent.setSelectedLevel(2);
                parent.showLevelConfig();
            }
        });
        backgroundLabel.add(level2Label);

        // Level 3 - clickeable
        ImageIcon level3Icon = new ImageIcon("resources/level3.png");
        Image level3Img = level3Icon.getImage().getScaledInstance(levelWidth, levelHeight, Image.SCALE_SMOOTH);
        JLabel level3Label = new JLabel(new ImageIcon(level3Img));
        level3Label.setBounds(centerX, 320, levelWidth, levelHeight);
        level3Label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        level3Label.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                // guardar el nivel y mostrar la configuracion visual de ese mapa
                parent.setSelectedLevel(3);
                parent.showLevelConfig();
            }
        });
        backgroundLabel.add(level3Label);

        // More Levels - en construccion siempre
        ImageIcon level4Icon = new ImageIcon("resources/level4.png");
        Image level4Img = level4Icon.getImage().getScaledInstance(levelWidth, levelHeight, Image.SCALE_SMOOTH);
        JLabel level4Label = new JLabel(new ImageIcon(level4Img));
        level4Label.setBounds(centerX, 420, levelWidth, levelHeight);
        level4Label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        level4Label.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                showUnderConstruction();
            }
        });
        backgroundLabel.add(level4Label);

        // boton Back
        ImageIcon backIcon = new ImageIcon("resources/back.png");
        Image backImg = backIcon.getImage().getScaledInstance(80, 40, Image.SCALE_SMOOTH);
        JButton backButton = new JButton(new ImageIcon(backImg));
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setFocusPainted(false);
        backButton.setBounds(20, 20, 80, 40);
        backButton.addActionListener(e -> parent.showPlayerCountSelection());
        backgroundLabel.add(backButton);
    }

    /**
     * Shows a dialog with the "under construction" image when a level is not yet available.
     */
    private void showUnderConstruction() {
        ImageIcon constructionIcon = new ImageIcon("resources/construccion.png");
        Image scaledImage = constructionIcon.getImage().getScaledInstance(400, 300, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel imageLabel = new JLabel(scaledIcon);
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JOptionPane.showMessageDialog(
                this,
                imageLabel,
                "Nivel en Construcción",
                JOptionPane.PLAIN_MESSAGE
        );
    }
}
