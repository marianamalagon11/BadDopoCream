package presentation;

import javax.swing.*;
import java.awt.*;

/**
 * Main menu panel for the Bad Ice Cream game.
 * Displays the game logo, and manages animated menu buttons
 * for starting the game and entering player count selection.
 * Laura Castillo, Mariana Malagon
 * PROYECTO FINAL DOPO
 */
public class MenuPanel extends JPanel {

    private BadIceCreamGUI parent;

    /**
     * Constructs the menu panel with logo and interactive blinking buttons.
     * Handles transitions to player count selection when the start button is used.
     * @param parent Reference to the main application window.
     */
    public MenuPanel(BadIceCreamGUI parent) {
        this.parent = parent;
        setLayout(null);
        setPreferredSize(new Dimension(640, 640));

        // fondo
        ImageIcon bgIcon = new ImageIcon("resources/fondo.gif");
        Image bgImage = bgIcon.getImage().getScaledInstance(640, 640, Image.SCALE_DEFAULT);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setLayout(null);
        backgroundLabel.setBounds(0, 0, 640, 640);

        // logo
        ImageIcon logoIcon = new ImageIcon("resources/logo.gif");

        double scaleFactor = 1.2;
        int logoW = (int)(logoIcon.getIconWidth() * scaleFactor);
        int logoH = (int)(logoIcon.getIconHeight() * scaleFactor);

        Image scaledImage = logoIcon.getImage().getScaledInstance(logoW, logoH, Image.SCALE_DEFAULT);
        ImageIcon scaledLogoIcon = new ImageIcon(scaledImage);

        JLabel logoLabel = new JLabel(scaledLogoIcon);
        logoLabel.setBounds((640 - logoW) / 2, 50, logoW, logoH);
        backgroundLabel.add(logoLabel);



        ImageIcon btnIcon1 = new ImageIcon("resources/boton1.png");
        Image btnImage1 = btnIcon1.getImage().getScaledInstance(220, 140, Image.SCALE_SMOOTH);

        JButton boton1 = new JButton(new ImageIcon(btnImage1));
        boton1.setBorderPainted(false);
        boton1.setContentAreaFilled(false);
        boton1.setFocusPainted(false);

        int bx = (640 - 220) / 2;
        int by = 470;

        boton1.setBounds(bx, by, 220, 140);

        ImageIcon btnIcon2 = new ImageIcon("resources/boton2.png");
        Image btnImage2 = btnIcon2.getImage().getScaledInstance(200, 95, Image.SCALE_SMOOTH);

        JButton boton2 = new JButton(new ImageIcon(btnImage2));
        boton2.setBorderPainted(false);
        boton2.setContentAreaFilled(false);
        boton2.setFocusPainted(false);

        boton2.setBounds((640 - 200) / 2, 480, 200, 95);
        boton2.setVisible(false);

        // para q parpadee
        final int[] count = {0};
        Timer blinkTimer = new Timer(90, ev -> {
            boton2.setVisible(!boton2.isVisible());
            count[0]++;

            if (count[0] >= 12) {
                ((Timer) ev.getSource()).stop();
                boton2.setVisible(true);
            }
        });

        boton1.addActionListener(e -> {
            boton1.setVisible(false);
            boton2.setVisible(true);
            count[0] = 0;
            blinkTimer.start();
        });

        boton2.addActionListener(e -> {
            System.out.println("Botón 2 presionado");
            parent.showPlayerCountSelection();
        });

        backgroundLabel.add(boton1);
        backgroundLabel.add(boton2);
        add(backgroundLabel);
    }
}
